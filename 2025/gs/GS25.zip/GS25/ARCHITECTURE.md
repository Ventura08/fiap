# NeuroLink / Bem-Estar – Arquitetura Simplificada

## Visão Geral
- **backend/**: Java 17, JAX-RS (Jersey) + Grizzly, JSON com Jackson, JDBC direto no Oracle (sem Spring).
- **frontend/**: HTML/CSS/JS estático consumindo a API REST.
- **database/**: scripts Oracle (`schema.sql`, `data.sql`) e `application.properties` para configurar credenciais.

## Fluxo de Requisição
1. **HTTP** → `api/*Resource` (camada de exposição REST).
2. **Service** aplica validações simples e regras de negócio.
3. **Repository/DAO** conversa com Oracle via JDBC (try-with-resources, SQL explícito).
4. Objetos de domínio (`model`) são serializados em JSON para o frontend.

## Pacotes do Backend
- `config`: bootstrap do servidor, CORS, Jackson (Java Time), fábrica de conexões Oracle.
- `api`: recursos REST (`UsuarioResource`, `QuestionarioResource`, `DesabafoResource`, `ResumoExecutivoResource`).
- `service`: orquestração/validação e geração de resumo executivo.
- `repository`: consultas SQL/CRUD para `usuarios`, `questionarios`, `desabafos`, `resumos_executivos`.
- `model`: entidades e enums do domínio.
- `dto`: payloads específicos de requisição/resposta quando não queremos expor a entidade completa.
- `exception`: exceções de negócio e mapeadores HTTP com `{ "error": "mensagem" }`.

## Geração de Resumo Executivo
- Coleta **questionários** e **desabafos** do período solicitado.
- Identifica top 3 focos de estresse por frequência e intensidade.
- Monta métricas agregadas (totais, médias, participação).
- Sugere “soluções estruturais” com base nos focos e métricas.
- Opcionalmente persiste o resumo em `resumos_executivos` (JSON em colunas CLOB) ou apenas retorna on-the-fly.

## Frontend
- Configuração única de `API_BASE_URL`.
- Página de colaborador: identifica usuário simples, envia **questionário mensal** e **desabafo anônimo**.
- Página de gestão: busca métricas, gráficos simples e o **Resumo Executivo** para o período selecionado.
