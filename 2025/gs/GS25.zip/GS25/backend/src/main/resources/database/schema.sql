-- Limpeza rápida (ignora erros se não existir)
BEGIN EXECUTE IMMEDIATE 'DROP TABLE resumos_executivos'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE desabafos'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE questionarios'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE usuarios'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE usuarios_seq'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE resumos_seq'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- Usuários (colaborador, gestor, RH)
CREATE TABLE usuarios (
  id              NUMBER PRIMARY KEY,
  nome            VARCHAR2(120) NOT NULL,
  email           VARCHAR2(120) UNIQUE NOT NULL,
  senha           VARCHAR2(120),
  telefone        VARCHAR2(30),
  departamento    VARCHAR2(80),
  faixa_etaria    VARCHAR2(40),
  perfil          VARCHAR2(20) DEFAULT 'USUARIO',
  data_cadastro   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  ativo           NUMBER(1) DEFAULT 1
);

CREATE SEQUENCE usuarios_seq START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER usuarios_bi
BEFORE INSERT ON usuarios
FOR EACH ROW
WHEN (NEW.id IS NULL)
BEGIN
  SELECT usuarios_seq.NEXTVAL INTO :NEW.id FROM dual;
END;
/

-- Questionários mensais
CREATE TABLE questionarios (
  id                          VARCHAR2(36) PRIMARY KEY,
  usuario_id                  NUMBER NULL,
  mes_ano                     VARCHAR2(7) NOT NULL,
  data_resposta               DATE DEFAULT CURRENT_DATE,
  carga_trabalho              NUMBER(2),
  reconhecimento              NUMBER(2),
  relacionamento_interpessoal NUMBER(2),
  equilibrio_trabalho_vida    NUMBER(2),
  comunicacao                 NUMBER(2),
  autonomia                   NUMBER(2),
  desenvolvimento             NUMBER(2),
  ambiente_trabalho           NUMBER(2),
  suporte_lideranca           NUMBER(2),
  satisfacao_geral            NUMBER(2),
  departamento                VARCHAR2(80),
  faixa_etaria                VARCHAR2(40),
  session_hash                VARCHAR2(64),
  data_criacao                TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_questionario_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Desabafos anônimos
CREATE TABLE desabafos (
  id                    VARCHAR2(36) PRIMARY KEY,
  usuario_id            NUMBER NULL,
  data_processamento    DATE DEFAULT CURRENT_DATE,
  sentimento_principal  VARCHAR2(40),
  topico_recorrente     VARCHAR2(60),
  intensidade_sentimento NUMBER(2),
  mensagem              CLOB,
  departamento          VARCHAR2(80),
  faixa_etaria          VARCHAR2(40),
  session_hash          VARCHAR2(64),
  data_criacao          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_desabafo_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Resumos Executivos (guarda JSON em CLOB)
CREATE TABLE resumos_executivos (
  id                NUMBER PRIMARY KEY,
  periodo_inicio    DATE NOT NULL,
  periodo_fim       DATE NOT NULL,
  data_geracao      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  top3_focos        CLOB,
  solucoes          CLOB,
  metricas          CLOB,
  resumo_texto      CLOB,
  status_resumo     VARCHAR2(30) DEFAULT 'GERADO'
);

CREATE SEQUENCE resumos_seq START WITH 1 INCREMENT BY 1 NOCACHE;

CREATE OR REPLACE TRIGGER resumos_bi
BEFORE INSERT ON resumos_executivos
FOR EACH ROW
WHEN (NEW.id IS NULL)
BEGIN
  SELECT resumos_seq.NEXTVAL INTO :NEW.id FROM dual;
END;
/
