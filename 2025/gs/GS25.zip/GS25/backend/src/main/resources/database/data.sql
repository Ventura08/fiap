-- Usuários fictícios
INSERT INTO usuarios (nome, email, senha, telefone, departamento, faixa_etaria, perfil) VALUES
('Ana Costa', 'ana@empresa.com', '123', '(11)90000-0000', 'Tecnologia', '25-34', 'USUARIO');
INSERT INTO usuarios (nome, email, senha, telefone, departamento, faixa_etaria, perfil) VALUES
('Carlos Lima', 'carlos@empresa.com', '123', '(11)91111-1111', 'Operações', '35-44', 'USUARIO');
INSERT INTO usuarios (nome, email, senha, telefone, departamento, faixa_etaria, perfil) VALUES
('Marina Souza', 'marina@empresa.com', '123', '(11)92222-2222', 'RH', '25-34', 'GESTOR');

-- Questionários (YYYY-MM no mes_ano)
INSERT INTO questionarios (id, usuario_id, mes_ano, carga_trabalho, reconhecimento, relacionamento_interpessoal,
  equilibrio_trabalho_vida, comunicacao, autonomia, desenvolvimento, ambiente_trabalho, suporte_lideranca,
  satisfacao_geral, departamento, faixa_etaria, session_hash)
VALUES ('q-1', 1, '2024-05', 7, 6, 8, 6, 7, 7, 8, 7, 6, 7, 'Tecnologia', '25-34', 'sess-ana');

INSERT INTO questionarios (id, usuario_id, mes_ano, carga_trabalho, reconhecimento, relacionamento_interpessoal,
  equilibrio_trabalho_vida, comunicacao, autonomia, desenvolvimento, ambiente_trabalho, suporte_lideranca,
  satisfacao_geral, departamento, faixa_etaria, session_hash)
VALUES ('q-2', 2, '2024-05', 8, 5, 6, 5, 6, 7, 6, 6, 5, 6, 'Operações', '35-44', 'sess-carlos');

-- Desabafos
INSERT INTO desabafos (id, usuario_id, sentimento_principal, topico_recorrente, intensidade_sentimento, mensagem, departamento, faixa_etaria, session_hash)
VALUES ('d-1', NULL, 'Estresse', 'Carga_TRABALHO', 8, 'Prazos apertados e equipe reduzida', 'Tecnologia', '25-34', 'sess-anon');

INSERT INTO desabafos (id, usuario_id, sentimento_principal, topico_recorrente, intensidade_sentimento, mensagem, departamento, faixa_etaria, session_hash)
VALUES ('d-2', 2, 'Frustracao', 'Lideranca', 6, 'Falta de alinhamento com liderança imediata', 'Operações', '35-44', 'sess-carlos');
