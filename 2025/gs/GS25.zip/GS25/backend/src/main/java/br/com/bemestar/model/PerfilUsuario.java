package br.com.bemestar.model;

public enum PerfilUsuario {
    USUARIO,
    GESTOR,
    RH
}
