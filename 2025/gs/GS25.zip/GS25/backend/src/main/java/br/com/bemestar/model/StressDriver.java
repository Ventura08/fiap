package br.com.bemestar.model;

public class StressDriver {
    private TopicoRecorrente topico;
    private SentimentoPrincipal sentimentoDominante;
    private long ocorrencias;
    private double frequenciaPercentual;
    private double intensidadeMedia;

    public TopicoRecorrente getTopico() {
        return topico;
    }

    public void setTopico(TopicoRecorrente topico) {
        this.topico = topico;
    }

    public SentimentoPrincipal getSentimentoDominante() {
        return sentimentoDominante;
    }

    public void setSentimentoDominante(SentimentoPrincipal sentimentoDominante) {
        this.sentimentoDominante = sentimentoDominante;
    }

    public long getOcorrencias() {
        return ocorrencias;
    }

    public void setOcorrencias(long ocorrencias) {
        this.ocorrencias = ocorrencias;
    }

    public double getFrequenciaPercentual() {
        return frequenciaPercentual;
    }

    public void setFrequenciaPercentual(double frequenciaPercentual) {
        this.frequenciaPercentual = frequenciaPercentual;
    }

    public double getIntensidadeMedia() {
        return intensidadeMedia;
    }

    public void setIntensidadeMedia(double intensidadeMedia) {
        this.intensidadeMedia = intensidadeMedia;
    }
}
