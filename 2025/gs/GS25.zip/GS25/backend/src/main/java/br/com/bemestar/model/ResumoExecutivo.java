package br.com.bemestar.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ResumoExecutivo {
    private Long id;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate periodoInicio;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate periodoFim;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime dataGeracao = LocalDateTime.now();
    private List<StressDriver> top3Focos = new ArrayList<>();
    private List<SolucaoEstrutural> solucoesEstruturais = new ArrayList<>();
    private MetricasResumo metricasAgregadas;
    private String resumoTexto;
    private StatusResumo status = StatusResumo.GERADO;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getPeriodoInicio() {
        return periodoInicio;
    }

    public void setPeriodoInicio(LocalDate periodoInicio) {
        this.periodoInicio = periodoInicio;
    }

    public LocalDate getPeriodoFim() {
        return periodoFim;
    }

    public void setPeriodoFim(LocalDate periodoFim) {
        this.periodoFim = periodoFim;
    }

    public LocalDateTime getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(LocalDateTime dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public List<StressDriver> getTop3Focos() {
        return top3Focos;
    }

    public void setTop3Focos(List<StressDriver> top3Focos) {
        this.top3Focos = top3Focos;
    }

    public List<SolucaoEstrutural> getSolucoesEstruturais() {
        return solucoesEstruturais;
    }

    public void setSolucoesEstruturais(List<SolucaoEstrutural> solucoesEstruturais) {
        this.solucoesEstruturais = solucoesEstruturais;
    }

    public MetricasResumo getMetricasAgregadas() {
        return metricasAgregadas;
    }

    public void setMetricasAgregadas(MetricasResumo metricasAgregadas) {
        this.metricasAgregadas = metricasAgregadas;
    }

    public String getResumoTexto() {
        return resumoTexto;
    }

    public void setResumoTexto(String resumoTexto) {
        this.resumoTexto = resumoTexto;
    }

    public StatusResumo getStatus() {
        return status;
    }

    public void setStatus(StatusResumo status) {
        this.status = status;
    }
}
