package br.com.bemestar.service;

import br.com.bemestar.dto.UsuarioRequest;
import br.com.bemestar.exception.ValidationException;
import br.com.bemestar.model.Usuario;
import br.com.bemestar.repository.UsuarioRepository;

import java.sql.SQLException;
import java.util.List;

public class UsuarioService {

    private final UsuarioRepository repository;

    public UsuarioService() {
        this.repository = new UsuarioRepository();
    }

    public Usuario criar(UsuarioRequest request) {
        validar(request);
        Usuario usuario = new Usuario();
        usuario.setNome(request.getNome());
        usuario.setEmail(request.getEmail());
        usuario.setTelefone(request.getTelefone());
        usuario.setDepartamento(request.getDepartamento());
        usuario.setFaixaEtaria(request.getFaixaEtaria());
        usuario.setPerfil(request.getPerfil());
        try {
            return repository.salvar(usuario);
        } catch (SQLException e) {
            throw new ValidationException("Erro ao salvar usuário: " + e.getMessage());
        }
    }

    public List<Usuario> listar() {
        try {
            return repository.listarTodos();
        } catch (SQLException e) {
            throw new ValidationException("Erro ao listar usuários: " + e.getMessage());
        }
    }

    private void validar(UsuarioRequest request) {
        if (request.getNome() == null || request.getNome().isBlank()) {
            throw new ValidationException("Nome é obrigatório");
        }
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new ValidationException("Email é obrigatório");
        }
    }
}
