package br.com.bemestar.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;

/**
 * Carrega propriedades de application.properties com override por variáveis de ambiente.
 */
public final class AppProperties {

    private static final Properties PROPS = load();

    private AppProperties() {}

    private static Properties load() {
        Properties props = new Properties();
        try (InputStream in = AppProperties.class.getClassLoader().getResourceAsStream("application.properties")) {
            if (in != null) {
                props.load(in);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Não foi possível carregar application.properties", e);
        }
        return props;
    }

    public static String get(String key, String defaultValue) {
        String envKey = key.toUpperCase(Locale.ROOT).replace('.', '_');
        String envValue = System.getenv(envKey);
        if (envValue != null && !envValue.isBlank()) {
            return envValue;
        }
        return PROPS.getProperty(key, defaultValue);
    }

    public static int serverPort() {
        return Integer.parseInt(get("server.port", "8080"));
    }
}
