package br.com.bemestar.repository;

import br.com.bemestar.config.DatabaseConfig;
import br.com.bemestar.model.Desabafo;
import br.com.bemestar.model.SentimentoPrincipal;
import br.com.bemestar.model.TopicoRecorrente;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DesabafoRepository {

    public Desabafo salvar(Desabafo d) throws SQLException {
        if (d.getId() == null) {
            d.setId(UUID.randomUUID().toString());
        }
        String sql = "INSERT INTO desabafos (id, usuario_id, data_processamento, sentimento_principal, topico_recorrente, " +
                "intensidade_sentimento, mensagem, departamento, faixa_etaria, session_hash, data_criacao) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSTIMESTAMP)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, d.getId());
            if (d.getUsuarioId() != null) stmt.setLong(2, d.getUsuarioId()); else stmt.setNull(2, Types.NUMERIC);
            stmt.setDate(3, Date.valueOf(d.getDataProcessamento() != null ? d.getDataProcessamento() : LocalDate.now()));
            stmt.setString(4, d.getSentimentoPrincipal() != null ? d.getSentimentoPrincipal().name() : SentimentoPrincipal.OUTRO.name());
            stmt.setString(5, d.getTopicoRecorrente() != null ? d.getTopicoRecorrente().name() : TopicoRecorrente.OUTRO.name());
            setInteger(stmt, 6, d.getIntensidadeSentimento());
            stmt.setString(7, d.getMensagem());
            stmt.setString(8, d.getDepartamento());
            stmt.setString(9, d.getFaixaEtaria());
            stmt.setString(10, d.getSessionHash());
            stmt.executeUpdate();
            return d;
        }
    }

    public List<Desabafo> buscarPorMesAno(String mesAno) throws SQLException {
        // mesAno = yyyy-MM
        String sql = "SELECT * FROM desabafos WHERE TO_CHAR(data_processamento, 'YYYY-MM') = ? ORDER BY data_processamento DESC";
        List<Desabafo> list = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, mesAno);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public List<Desabafo> listarTodos() throws SQLException {
        String sql = "SELECT * FROM desabafos ORDER BY data_processamento DESC";
        List<Desabafo> list = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    private Desabafo map(ResultSet rs) throws SQLException {
        Desabafo d = new Desabafo();
        d.setId(rs.getString("id"));
        long userId = rs.getLong("usuario_id");
        if (!rs.wasNull()) d.setUsuarioId(userId);
        Date data = rs.getDate("data_processamento");
        if (data != null) d.setDataProcessamento(data.toLocalDate());
        String sentimento = rs.getString("sentimento_principal");
        if (sentimento != null) d.setSentimentoPrincipal(SentimentoPrincipal.valueOf(sentimento));
        String topico = rs.getString("topico_recorrente");
        if (topico != null) d.setTopicoRecorrente(TopicoRecorrente.valueOf(topico));
        d.setIntensidadeSentimento(getInteger(rs, "intensidade_sentimento"));
        d.setMensagem(rs.getString("mensagem"));
        d.setDepartamento(rs.getString("departamento"));
        d.setFaixaEtaria(rs.getString("faixa_etaria"));
        d.setSessionHash(rs.getString("session_hash"));
        Timestamp ts = rs.getTimestamp("data_criacao");
        if (ts != null) d.setDataCriacao(ts.toLocalDateTime());
        return d;
    }

    private Integer getInteger(ResultSet rs, String column) throws SQLException {
        int v = rs.getInt(column);
        return rs.wasNull() ? null : v;
    }

    private void setInteger(PreparedStatement stmt, int idx, Integer value) throws SQLException {
        if (value == null) stmt.setNull(idx, Types.INTEGER); else stmt.setInt(idx, value);
    }
}
