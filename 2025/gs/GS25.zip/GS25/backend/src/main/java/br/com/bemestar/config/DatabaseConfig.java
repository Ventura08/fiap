package br.com.bemestar.config;

import oracle.jdbc.pool.OracleDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Fábrica simples de conexões Oracle.
 */
public final class DatabaseConfig {

    private static final DataSource DATA_SOURCE = buildDataSource();

    private DatabaseConfig() {}

    private static DataSource buildDataSource() {
        try {
            OracleDataSource ods = new OracleDataSource();
            ods.setURL(AppProperties.get("db.url", ""));
            ods.setUser(AppProperties.get("db.user", ""));
            ods.setPassword(AppProperties.get("db.password", ""));
            ods.setImplicitCachingEnabled(true);
            return ods;
        } catch (SQLException e) {
            throw new IllegalStateException("Erro ao configurar OracleDataSource", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DATA_SOURCE.getConnection();
    }

    public static DataSource dataSource() {
        return DATA_SOURCE;
    }
}
