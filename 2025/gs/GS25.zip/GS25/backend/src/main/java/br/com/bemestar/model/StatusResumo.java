package br.com.bemestar.model;

public enum StatusResumo {
    GERADO,
    EM_REVISAO,
    APROVADO,
    IMPLEMENTADO
}
