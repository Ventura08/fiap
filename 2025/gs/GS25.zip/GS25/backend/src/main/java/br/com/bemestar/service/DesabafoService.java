package br.com.bemestar.service;

import br.com.bemestar.dto.DesabafoRequest;
import br.com.bemestar.exception.ValidationException;
import br.com.bemestar.model.Desabafo;
import br.com.bemestar.model.SentimentoPrincipal;
import br.com.bemestar.model.TopicoRecorrente;
import br.com.bemestar.repository.DesabafoRepository;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DesabafoService {

    private final DesabafoRepository repository;

    public DesabafoService() {
        this.repository = new DesabafoRepository();
    }

    public Desabafo salvar(DesabafoRequest request) {
        validar(request);
        Desabafo d = new Desabafo();
        d.setUsuarioId(request.getUsuarioId());
        d.setDataProcessamento(request.getDataProcessamento() != null ? request.getDataProcessamento() : LocalDate.now());
        d.setSentimentoPrincipal(request.getSentimentoPrincipal() != null ? request.getSentimentoPrincipal() : SentimentoPrincipal.OUTRO);
        d.setTopicoRecorrente(request.getTopicoRecorrente() != null ? request.getTopicoRecorrente() : TopicoRecorrente.OUTRO);
        d.setIntensidadeSentimento(request.getIntensidadeSentimento());
        d.setMensagem(request.getMensagem());
        d.setDepartamento(request.getDepartamento());
        d.setFaixaEtaria(request.getFaixaEtaria());
        d.setSessionHash(request.getSessionHash());
        try {
            return repository.salvar(d);
        } catch (SQLException e) {
            throw new ValidationException("Erro ao salvar desabafo: " + e.getMessage());
        }
    }

    public List<Desabafo> listar(String mesAno) {
        try {
            if (mesAno == null || mesAno.isBlank()) {
                return repository.listarTodos();
            }
            return repository.buscarPorMesAno(mesAno);
        } catch (SQLException e) {
            throw new ValidationException("Erro ao buscar desabafos: " + e.getMessage());
        }
    }

    private void validar(DesabafoRequest request) {
        if (request.getIntensidadeSentimento() == null) {
            throw new ValidationException("Intensidade é obrigatória");
        }
        if (request.getMensagem() == null || request.getMensagem().isBlank()) {
            throw new ValidationException("Mensagem do desabafo é obrigatória");
        }
    }
}
