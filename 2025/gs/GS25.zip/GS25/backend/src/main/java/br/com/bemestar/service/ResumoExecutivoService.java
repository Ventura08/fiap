package br.com.bemestar.service;

import br.com.bemestar.exception.ValidationException;
import br.com.bemestar.model.*;
import br.com.bemestar.repository.DesabafoRepository;
import br.com.bemestar.repository.QuestionarioRepository;
import br.com.bemestar.repository.ResumoExecutivoRepository;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ResumoExecutivoService {

    private final QuestionarioRepository questionarioRepository;
    private final DesabafoRepository desabafoRepository;
    private final ResumoExecutivoRepository resumoRepository;

    public ResumoExecutivoService() {
        this.questionarioRepository = new QuestionarioRepository();
        this.desabafoRepository = new DesabafoRepository();
        this.resumoRepository = new ResumoExecutivoRepository();
    }

    public ResumoExecutivo gerar(LocalDate inicio, LocalDate fim, boolean persistir) {
        if (inicio == null || fim == null) {
            YearMonth ym = YearMonth.now();
            inicio = ym.atDay(1);
            fim = ym.atEndOfMonth();
        }
        if (fim.isBefore(inicio)) {
            throw new ValidationException("Data fim não pode ser anterior à data início");
        }
        String mesAno = YearMonth.from(inicio).toString(); // yyyy-MM
        try {
            List<Questionario> questionarios = questionarioRepository.buscarPorMesAno(mesAno);
            List<Desabafo> desabafos = desabafoRepository.buscarPorMesAno(mesAno);

            ResumoExecutivo resumo = new ResumoExecutivo();
            resumo.setPeriodoInicio(inicio);
            resumo.setPeriodoFim(fim);
            resumo.setTop3Focos(calcularTop3(desabafos));
            resumo.setMetricasAgregadas(calcularMetricas(desabafos, questionarios));
            resumo.setSolucoesEstruturais(sugerirSolucoes(resumo.getTop3Focos()));
            resumo.setResumoTexto(montarTexto(resumo));

            if (persistir) {
                resumoRepository.salvar(resumo);
            }
            return resumo;
        } catch (SQLException e) {
            throw new ValidationException("Erro ao gerar resumo: " + e.getMessage());
        }
    }

    public List<ResumoExecutivo> listarPersistidos() {
        try {
            return resumoRepository.listar();
        } catch (SQLException e) {
            throw new ValidationException("Erro ao listar resumos: " + e.getMessage());
        }
    }

    private List<StressDriver> calcularTop3(List<Desabafo> desabafos) {
        if (desabafos.isEmpty()) return List.of();
        Map<TopicoRecorrente, List<Desabafo>> agrupado = desabafos.stream()
                .collect(Collectors.groupingBy(d -> d.getTopicoRecorrente() != null ? d.getTopicoRecorrente() : TopicoRecorrente.OUTRO));

        return agrupado.entrySet().stream()
                .map(e -> {
                    List<Desabafo> lista = e.getValue();
                    StressDriver driver = new StressDriver();
                    driver.setTopico(e.getKey());
                    driver.setOcorrencias(lista.size());
                    driver.setIntensidadeMedia(lista.stream()
                            .filter(d -> d.getIntensidadeSentimento() != null)
                            .mapToInt(Desabafo::getIntensidadeSentimento)
                            .average().orElse(0));
                    driver.setFrequenciaPercentual((lista.size() * 100.0) / desabafos.size());
                    driver.setSentimentoDominante(lista.stream()
                            .collect(Collectors.groupingBy(Desabafo::getSentimentoPrincipal, Collectors.counting()))
                            .entrySet().stream()
                            .max(Map.Entry.comparingByValue())
                            .map(Map.Entry::getKey)
                            .orElse(SentimentoPrincipal.OUTRO));
                    return driver;
                })
                .sorted(Comparator.comparingLong(StressDriver::getOcorrencias).reversed())
                .limit(3)
                .toList();
    }

    private MetricasResumo calcularMetricas(List<Desabafo> desabafos, List<Questionario> questionarios) {
        MetricasResumo m = new MetricasResumo();
        m.setTotalDesabafos(desabafos.size());
        m.setTotalQuestionarios(questionarios.size());
        m.setIntensidadeMediaDesabafos(desabafos.stream()
                .filter(d -> d.getIntensidadeSentimento() != null)
                .mapToInt(Desabafo::getIntensidadeSentimento)
                .average().orElse(0));
        m.setSatisfacaoMedia(questionarios.stream()
                .filter(q -> q.getSatisfacaoGeral() != null)
                .mapToInt(Questionario::getSatisfacaoGeral)
                .average().orElse(0));
        m.setParticipantesEstimados((int) questionarios.stream()
                .map(Questionario::getSessionHash)
                .distinct()
                .count());
        m.setTopicoMaisRecorrente(desabafos.stream()
                .collect(Collectors.groupingBy(Desabafo::getTopicoRecorrente, Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(e -> e.getKey() != null ? e.getKey().name() : null)
                .orElse(null));
        return m;
    }

    private List<SolucaoEstrutural> sugerirSolucoes(List<StressDriver> drivers) {
        if (drivers == null || drivers.isEmpty()) return List.of();
        return drivers.stream().map(driver -> {
            SolucaoEstrutural s = new SolucaoEstrutural();
            s.setTopico(driver.getTopico());
            s.setPrioridade(driver.getIntensidadeMedia() >= 7 ? PrioridadeAcao.ALTA :
                    driver.getIntensidadeMedia() >= 4 ? PrioridadeAcao.MEDIA : PrioridadeAcao.BAIXA);
            switch (driver.getTopico()) {
                case CARGA_TRABALHO -> {
                    s.setTitulo("Rebalancear carga de trabalho");
                    s.setDescricao("Mapear filas, redistribuir tarefas e negociar prazos críticos.");
                }
                case LIDERANCA -> {
                    s.setTitulo("Aprimorar liderança");
                    s.setDescricao("Treinamento de feedback, 1:1 recorrente e clareza de prioridades.");
                }
                case RELACIONAMENTO_INTERPESSOAL -> {
                    s.setTitulo("Mediação e clima");
                    s.setDescricao("Rodas de conversa mediadas e combinados de convivência.");
                }
                case EQUILIBRIO_TRABALHO_VIDA -> {
                    s.setTitulo("Higiene de agenda");
                    s.setDescricao("Respeitar horários, evitar reuniões tardias e incentivar pausas.");
                }
                case COMUNICACAO -> {
                    s.setTitulo("Comunicação clara");
                    s.setDescricao("Rotina de alinhamentos curtos e canais formais para decisões.");
                }
                default -> {
                    s.setTitulo("Ação de bem-estar");
                    s.setDescricao("Iniciativa geral para reduzir estresse e aumentar suporte.");
                }
            }
            return s;
        }).toList();
    }

    private String montarTexto(ResumoExecutivo resumo) {
        MetricasResumo m = resumo.getMetricasAgregadas();
        return String.format(
                "No período %s a %s avaliamos %d desabafos e %d questionários. " +
                        "Intensidade média dos desabafos: %.1f. Satisfação média: %.1f. " +
                        "Principais focos: %s.",
                resumo.getPeriodoInicio(), resumo.getPeriodoFim(),
                m.getTotalDesabafos(), m.getTotalQuestionarios(),
                m.getIntensidadeMediaDesabafos(), m.getSatisfacaoMedia(),
                resumo.getTop3Focos().stream().map(d -> d.getTopico().name()).collect(Collectors.joining(", "))
        );
    }
}
