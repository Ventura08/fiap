package br.com.bemestar.model;

public enum SentimentoPrincipal {
    ESTRESSE,
    ANSIEDADE,
    FRUSTRACAO,
    SOBRECARGA,
    CONFLITO,
    OUTRO
}
