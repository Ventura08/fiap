package br.com.bemestar.repository;

import br.com.bemestar.config.DatabaseConfig;
import br.com.bemestar.model.PerfilUsuario;
import br.com.bemestar.model.Usuario;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioRepository {

    public Usuario salvar(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, email, telefone, departamento, faixa_etaria, perfil, data_cadastro, ativo) " +
                "VALUES (?, ?, ?, ?, ?, ?, SYSTIMESTAMP, ?)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"id"})) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getTelefone());
            stmt.setString(4, usuario.getDepartamento());
            stmt.setString(5, usuario.getFaixaEtaria());
            stmt.setString(6, usuario.getPerfil() != null ? usuario.getPerfil().name() : PerfilUsuario.USUARIO.name());
            stmt.setInt(7, usuario.getAtivo() != null && usuario.getAtivo() ? 1 : 0);
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    usuario.setId(rs.getLong(1));
                }
            }
            return usuario;
        }
    }

    public List<Usuario> listarTodos() throws SQLException {
        String sql = "SELECT id, nome, email, telefone, departamento, faixa_etaria, perfil, data_cadastro, ativo FROM usuarios";
        List<Usuario> usuarios = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                usuarios.add(map(rs));
            }
        }
        return usuarios;
    }

    public Usuario buscarPorEmail(String email) throws SQLException {
        String sql = "SELECT id, nome, email, telefone, departamento, faixa_etaria, perfil, data_cadastro, ativo FROM usuarios WHERE email = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return map(rs);
                }
            }
        }
        return null;
    }

    private Usuario map(ResultSet rs) throws SQLException {
        Usuario u = new Usuario();
        u.setId(rs.getLong("id"));
        u.setNome(rs.getString("nome"));
        u.setEmail(rs.getString("email"));
        u.setTelefone(rs.getString("telefone"));
        u.setDepartamento(rs.getString("departamento"));
        u.setFaixaEtaria(rs.getString("faixa_etaria"));
        String perfil = rs.getString("perfil");
        if (perfil != null) {
            u.setPerfil(PerfilUsuario.valueOf(perfil));
        }
        Timestamp dataCadastro = rs.getTimestamp("data_cadastro");
        if (dataCadastro != null) {
            u.setDataCadastro(dataCadastro.toLocalDateTime());
        }
        u.setAtivo(rs.getInt("ativo") == 1);
        return u;
    }
}
