package br.com.bemestar.model;

public enum PrioridadeAcao {
    ALTA,
    MEDIA,
    BAIXA
}
