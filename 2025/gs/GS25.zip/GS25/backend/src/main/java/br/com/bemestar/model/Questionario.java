package br.com.bemestar.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Questionario {
    private String id;
    private Long usuarioId;
    private String mesAno;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dataResposta = LocalDate.now();
    private Integer cargaTrabalho;
    private Integer reconhecimento;
    private Integer relacionamentoInterpessoal;
    private Integer equilibrioTrabalhoVida;
    private Integer comunicacao;
    private Integer autonomia;
    private Integer desenvolvimento;
    private Integer ambienteTrabalho;
    private Integer suporteLideranca;
    private Integer satisfacaoGeral;
    private String departamento;
    private String faixaEtaria;
    private String sessionHash;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime dataCriacao = LocalDateTime.now();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getMesAno() {
        return mesAno;
    }

    public void setMesAno(String mesAno) {
        this.mesAno = mesAno;
    }

    public LocalDate getDataResposta() {
        return dataResposta;
    }

    public void setDataResposta(LocalDate dataResposta) {
        this.dataResposta = dataResposta;
    }

    public Integer getCargaTrabalho() {
        return cargaTrabalho;
    }

    public void setCargaTrabalho(Integer cargaTrabalho) {
        this.cargaTrabalho = cargaTrabalho;
    }

    public Integer getReconhecimento() {
        return reconhecimento;
    }

    public void setReconhecimento(Integer reconhecimento) {
        this.reconhecimento = reconhecimento;
    }

    public Integer getRelacionamentoInterpessoal() {
        return relacionamentoInterpessoal;
    }

    public void setRelacionamentoInterpessoal(Integer relacionamentoInterpessoal) {
        this.relacionamentoInterpessoal = relacionamentoInterpessoal;
    }

    public Integer getEquilibrioTrabalhoVida() {
        return equilibrioTrabalhoVida;
    }

    public void setEquilibrioTrabalhoVida(Integer equilibrioTrabalhoVida) {
        this.equilibrioTrabalhoVida = equilibrioTrabalhoVida;
    }

    public Integer getComunicacao() {
        return comunicacao;
    }

    public void setComunicacao(Integer comunicacao) {
        this.comunicacao = comunicacao;
    }

    public Integer getAutonomia() {
        return autonomia;
    }

    public void setAutonomia(Integer autonomia) {
        this.autonomia = autonomia;
    }

    public Integer getDesenvolvimento() {
        return desenvolvimento;
    }

    public void setDesenvolvimento(Integer desenvolvimento) {
        this.desenvolvimento = desenvolvimento;
    }

    public Integer getAmbienteTrabalho() {
        return ambienteTrabalho;
    }

    public void setAmbienteTrabalho(Integer ambienteTrabalho) {
        this.ambienteTrabalho = ambienteTrabalho;
    }

    public Integer getSuporteLideranca() {
        return suporteLideranca;
    }

    public void setSuporteLideranca(Integer suporteLideranca) {
        this.suporteLideranca = suporteLideranca;
    }

    public Integer getSatisfacaoGeral() {
        return satisfacaoGeral;
    }

    public void setSatisfacaoGeral(Integer satisfacaoGeral) {
        this.satisfacaoGeral = satisfacaoGeral;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getFaixaEtaria() {
        return faixaEtaria;
    }

    public void setFaixaEtaria(String faixaEtaria) {
        this.faixaEtaria = faixaEtaria;
    }

    public String getSessionHash() {
        return sessionHash;
    }

    public void setSessionHash(String sessionHash) {
        this.sessionHash = sessionHash;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }
}
