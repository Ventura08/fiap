package br.com.bemestar.model;

public class SolucaoEstrutural {
    private TopicoRecorrente topico;
    private String titulo;
    private String descricao;
    private PrioridadeAcao prioridade;

    public TopicoRecorrente getTopico() {
        return topico;
    }

    public void setTopico(TopicoRecorrente topico) {
        this.topico = topico;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public PrioridadeAcao getPrioridade() {
        return prioridade;
    }

    public void setPrioridade(PrioridadeAcao prioridade) {
        this.prioridade = prioridade;
    }
}
