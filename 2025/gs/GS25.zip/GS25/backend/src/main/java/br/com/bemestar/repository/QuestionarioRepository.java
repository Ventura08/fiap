package br.com.bemestar.repository;

import br.com.bemestar.config.DatabaseConfig;
import br.com.bemestar.model.Questionario;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class QuestionarioRepository {

    public Questionario salvar(Questionario q) throws SQLException {
        if (q.getId() == null) {
            q.setId(UUID.randomUUID().toString());
        }
        String sql = "INSERT INTO questionarios (id, usuario_id, mes_ano, data_resposta, carga_trabalho, reconhecimento, " +
                "relacionamento_interpessoal, equilibrio_trabalho_vida, comunicacao, autonomia, desenvolvimento, ambiente_trabalho, " +
                "suporte_lideranca, satisfacao_geral, departamento, faixa_etaria, session_hash, data_criacao) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, SYSTIMESTAMP)";

        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, q.getId());
            if (q.getUsuarioId() != null) stmt.setLong(2, q.getUsuarioId()); else stmt.setNull(2, Types.NUMERIC);
            stmt.setString(3, q.getMesAno());
            stmt.setDate(4, Date.valueOf(q.getDataResposta() != null ? q.getDataResposta() : LocalDate.now()));
            setInteger(stmt, 5, q.getCargaTrabalho());
            setInteger(stmt, 6, q.getReconhecimento());
            setInteger(stmt, 7, q.getRelacionamentoInterpessoal());
            setInteger(stmt, 8, q.getEquilibrioTrabalhoVida());
            setInteger(stmt, 9, q.getComunicacao());
            setInteger(stmt, 10, q.getAutonomia());
            setInteger(stmt, 11, q.getDesenvolvimento());
            setInteger(stmt, 12, q.getAmbienteTrabalho());
            setInteger(stmt, 13, q.getSuporteLideranca());
            setInteger(stmt, 14, q.getSatisfacaoGeral());
            stmt.setString(15, q.getDepartamento());
            stmt.setString(16, q.getFaixaEtaria());
            stmt.setString(17, q.getSessionHash());
            stmt.executeUpdate();
            return q;
        }
    }

    public List<Questionario> buscarPorMesAno(String mesAno) throws SQLException {
        String sql = "SELECT * FROM questionarios WHERE mes_ano = ? ORDER BY data_resposta DESC";
        List<Questionario> list = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, mesAno);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
        }
        return list;
    }

    public List<Questionario> listarTodos() throws SQLException {
        String sql = "SELECT * FROM questionarios ORDER BY data_resposta DESC";
        List<Questionario> list = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    private Questionario map(ResultSet rs) throws SQLException {
        Questionario q = new Questionario();
        q.setId(rs.getString("id"));
        long userId = rs.getLong("usuario_id");
        if (!rs.wasNull()) q.setUsuarioId(userId);
        q.setMesAno(rs.getString("mes_ano"));
        Date dataResp = rs.getDate("data_resposta");
        if (dataResp != null) q.setDataResposta(dataResp.toLocalDate());
        q.setCargaTrabalho(getInteger(rs, "carga_trabalho"));
        q.setReconhecimento(getInteger(rs, "reconhecimento"));
        q.setRelacionamentoInterpessoal(getInteger(rs, "relacionamento_interpessoal"));
        q.setEquilibrioTrabalhoVida(getInteger(rs, "equilibrio_trabalho_vida"));
        q.setComunicacao(getInteger(rs, "comunicacao"));
        q.setAutonomia(getInteger(rs, "autonomia"));
        q.setDesenvolvimento(getInteger(rs, "desenvolvimento"));
        q.setAmbienteTrabalho(getInteger(rs, "ambiente_trabalho"));
        q.setSuporteLideranca(getInteger(rs, "suporte_lideranca"));
        q.setSatisfacaoGeral(getInteger(rs, "satisfacao_geral"));
        q.setDepartamento(rs.getString("departamento"));
        q.setFaixaEtaria(rs.getString("faixa_etaria"));
        q.setSessionHash(rs.getString("session_hash"));
        Timestamp ts = rs.getTimestamp("data_criacao");
        if (ts != null) q.setDataCriacao(ts.toLocalDateTime());
        return q;
    }

    private Integer getInteger(ResultSet rs, String column) throws SQLException {
        int val = rs.getInt(column);
        return rs.wasNull() ? null : val;
    }

    private void setInteger(PreparedStatement stmt, int idx, Integer value) throws SQLException {
        if (value == null) stmt.setNull(idx, Types.INTEGER); else stmt.setInt(idx, value);
    }
}
