package br.com.bemestar.exception;

import jakarta.ws.rs.core.Response;

public class ValidationException extends ApiException {
    public ValidationException(String message) {
        super(Response.Status.BAD_REQUEST, message);
    }
}
