package br.com.bemestar.repository;

import br.com.bemestar.config.DatabaseConfig;
import br.com.bemestar.config.ObjectMapperProvider;
import br.com.bemestar.model.MetricasResumo;
import br.com.bemestar.model.ResumoExecutivo;
import br.com.bemestar.model.SolucaoEstrutural;
import br.com.bemestar.model.StatusResumo;
import br.com.bemestar.model.StressDriver;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResumoExecutivoRepository {

    private final ObjectMapper mapper = ObjectMapperProvider.mapper();

    public ResumoExecutivo salvar(ResumoExecutivo resumo) throws SQLException {
        String sql = "INSERT INTO resumos_executivos (periodo_inicio, periodo_fim, data_geracao, top3_focos, solucoes, metricas, resumo_texto, status_resumo) " +
                "VALUES (?, ?, SYSTIMESTAMP, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, new String[]{"id"})) {

            stmt.setDate(1, Date.valueOf(resumo.getPeriodoInicio()));
            stmt.setDate(2, Date.valueOf(resumo.getPeriodoFim()));
            stmt.setString(3, toJson(resumo.getTop3Focos()));
            stmt.setString(4, toJson(resumo.getSolucoesEstruturais()));
            stmt.setString(5, toJson(resumo.getMetricasAgregadas()));
            stmt.setString(6, resumo.getResumoTexto());
            stmt.setString(7, resumo.getStatus().name());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    resumo.setId(rs.getLong(1));
                }
            }
            return resumo;
        }
    }

    public List<ResumoExecutivo> listar() throws SQLException {
        String sql = "SELECT * FROM resumos_executivos ORDER BY data_geracao DESC";
        List<ResumoExecutivo> list = new ArrayList<>();
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                list.add(map(rs));
            }
        }
        return list;
    }

    private ResumoExecutivo map(ResultSet rs) throws SQLException {
        ResumoExecutivo r = new ResumoExecutivo();
        r.setId(rs.getLong("id"));
        Date inicio = rs.getDate("periodo_inicio");
        Date fim = rs.getDate("periodo_fim");
        if (inicio != null) r.setPeriodoInicio(inicio.toLocalDate());
        if (fim != null) r.setPeriodoFim(fim.toLocalDate());
        Timestamp data = rs.getTimestamp("data_geracao");
        if (data != null) r.setDataGeracao(data.toLocalDateTime());
        r.setTop3Focos(fromJsonList(rs.getString("top3_focos"), StressDriver.class));
        r.setSolucoesEstruturais(fromJsonList(rs.getString("solucoes"), SolucaoEstrutural.class));
        r.setMetricasAgregadas(fromJson(rs.getString("metricas"), MetricasResumo.class));
        r.setResumoTexto(rs.getString("resumo_texto"));
        String status = rs.getString("status_resumo");
        if (status != null) r.setStatus(StatusResumo.valueOf(status));
        return r;
    }

    private String toJson(Object value) {
        try {
            return mapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Erro ao converter JSON", e);
        }
    }

    private <T> T fromJson(String json, Class<T> clazz) {
        if (json == null) return null;
        try {
            return mapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Erro ao ler JSON", e);
        }
    }

    private <T> List<T> fromJsonList(String json, Class<T> clazz) {
        if (json == null) return List.of();
        try {
            return mapper.readerForListOf(clazz).readValue(json);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Erro ao ler lista JSON", e);
        }
    }
}
