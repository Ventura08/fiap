package br.com.bemestar.service;

import br.com.bemestar.dto.QuestionarioRequest;
import br.com.bemestar.exception.ValidationException;
import br.com.bemestar.model.Questionario;
import br.com.bemestar.repository.QuestionarioRepository;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class QuestionarioService {

    private final QuestionarioRepository repository;

    public QuestionarioService() {
        this.repository = new QuestionarioRepository();
    }

    public Questionario salvar(QuestionarioRequest request) {
        validar(request);
        Questionario q = new Questionario();
        q.setUsuarioId(request.getUsuarioId());
        q.setMesAno(normalizarMesAno(request.getMesAno(), request.getDataResposta()));
        q.setDataResposta(request.getDataResposta() != null ? request.getDataResposta() : LocalDate.now());
        q.setCargaTrabalho(request.getCargaTrabalho());
        q.setReconhecimento(request.getReconhecimento());
        q.setRelacionamentoInterpessoal(request.getRelacionamentoInterpessoal());
        q.setEquilibrioTrabalhoVida(request.getEquilibrioTrabalhoVida());
        q.setComunicacao(request.getComunicacao());
        q.setAutonomia(request.getAutonomia());
        q.setDesenvolvimento(request.getDesenvolvimento());
        q.setAmbienteTrabalho(request.getAmbienteTrabalho());
        q.setSuporteLideranca(request.getSuporteLideranca());
        q.setSatisfacaoGeral(request.getSatisfacaoGeral());
        q.setDepartamento(request.getDepartamento());
        q.setFaixaEtaria(request.getFaixaEtaria());
        q.setSessionHash(request.getSessionHash());
        try {
            return repository.salvar(q);
        } catch (SQLException e) {
            throw new ValidationException("Erro ao salvar questionário: " + e.getMessage());
        }
    }

    public List<Questionario> listar(String mesAno) {
        try {
            if (mesAno == null || mesAno.isBlank()) {
                return repository.listarTodos();
            }
            return repository.buscarPorMesAno(mesAno);
        } catch (SQLException e) {
            throw new ValidationException("Erro ao buscar questionários: " + e.getMessage());
        }
    }

    private String normalizarMesAno(String mesAno, LocalDate data) {
        if (mesAno != null && !mesAno.isBlank()) {
            return mesAno;
        }
        LocalDate base = data != null ? data : LocalDate.now();
        return String.format("%04d-%02d", base.getYear(), base.getMonthValue());
    }

    private void validar(QuestionarioRequest request) {
        if (request.getSatisfacaoGeral() == null) {
            throw new ValidationException("Satisfação geral é obrigatória");
        }
        if (request.getMesAno() == null && request.getDataResposta() == null) {
            throw new ValidationException("Informe mesAno ou dataResposta");
        }
    }
}
