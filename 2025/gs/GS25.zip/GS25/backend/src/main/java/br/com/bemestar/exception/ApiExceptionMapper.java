package br.com.bemestar.exception;

import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@Provider
public class ApiExceptionMapper implements ExceptionMapper<Throwable> {

    private static final Logger LOGGER = Logger.getLogger(ApiExceptionMapper.class.getName());

    @Override
    public Response toResponse(Throwable exception) {
        if (exception instanceof ApiException apiEx) {
            return buildResponse(apiEx.getStatus(), apiEx.getMessage());
        }

        LOGGER.log(Level.SEVERE, "Erro inesperado", exception);
        return buildResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro interno. Tente novamente.");
    }

    private Response buildResponse(Response.Status status, String message) {
        Map<String, String> payload = new HashMap<>();
        payload.put("error", message);
        return Response.status(status)
                .type(MediaType.APPLICATION_JSON_TYPE)
                .entity(payload)
                .build();
    }
}
