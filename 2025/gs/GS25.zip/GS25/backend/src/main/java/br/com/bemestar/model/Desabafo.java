package br.com.bemestar.model;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Desabafo {
    private String id;
    private Long usuarioId;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dataProcessamento = LocalDate.now();
    private SentimentoPrincipal sentimentoPrincipal;
    private TopicoRecorrente topicoRecorrente;
    private Integer intensidadeSentimento;
    private String mensagem;
    private String departamento;
    private String faixaEtaria;
    private String sessionHash;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime dataCriacao = LocalDateTime.now();

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public LocalDate getDataProcessamento() {
        return dataProcessamento;
    }

    public void setDataProcessamento(LocalDate dataProcessamento) {
        this.dataProcessamento = dataProcessamento;
    }

    public SentimentoPrincipal getSentimentoPrincipal() {
        return sentimentoPrincipal;
    }

    public void setSentimentoPrincipal(SentimentoPrincipal sentimentoPrincipal) {
        this.sentimentoPrincipal = sentimentoPrincipal;
    }

    public TopicoRecorrente getTopicoRecorrente() {
        return topicoRecorrente;
    }

    public void setTopicoRecorrente(TopicoRecorrente topicoRecorrente) {
        this.topicoRecorrente = topicoRecorrente;
    }

    public Integer getIntensidadeSentimento() {
        return intensidadeSentimento;
    }

    public void setIntensidadeSentimento(Integer intensidadeSentimento) {
        this.intensidadeSentimento = intensidadeSentimento;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getFaixaEtaria() {
        return faixaEtaria;
    }

    public void setFaixaEtaria(String faixaEtaria) {
        this.faixaEtaria = faixaEtaria;
    }

    public String getSessionHash() {
        return sessionHash;
    }

    public void setSessionHash(String sessionHash) {
        this.sessionHash = sessionHash;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }
}
