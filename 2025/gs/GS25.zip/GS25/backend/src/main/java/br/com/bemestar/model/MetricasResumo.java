package br.com.bemestar.model;

public class MetricasResumo {
    private int totalDesabafos;
    private int totalQuestionarios;
    private double intensidadeMediaDesabafos;
    private double satisfacaoMedia;
    private int participantesEstimados;
    private String topicoMaisRecorrente;

    public int getTotalDesabafos() {
        return totalDesabafos;
    }

    public void setTotalDesabafos(int totalDesabafos) {
        this.totalDesabafos = totalDesabafos;
    }

    public int getTotalQuestionarios() {
        return totalQuestionarios;
    }

    public void setTotalQuestionarios(int totalQuestionarios) {
        this.totalQuestionarios = totalQuestionarios;
    }

    public double getIntensidadeMediaDesabafos() {
        return intensidadeMediaDesabafos;
    }

    public void setIntensidadeMediaDesabafos(double intensidadeMediaDesabafos) {
        this.intensidadeMediaDesabafos = intensidadeMediaDesabafos;
    }

    public double getSatisfacaoMedia() {
        return satisfacaoMedia;
    }

    public void setSatisfacaoMedia(double satisfacaoMedia) {
        this.satisfacaoMedia = satisfacaoMedia;
    }

    public int getParticipantesEstimados() {
        return participantesEstimados;
    }

    public void setParticipantesEstimados(int participantesEstimados) {
        this.participantesEstimados = participantesEstimados;
    }

    public String getTopicoMaisRecorrente() {
        return topicoMaisRecorrente;
    }

    public void setTopicoMaisRecorrente(String topicoMaisRecorrente) {
        this.topicoMaisRecorrente = topicoMaisRecorrente;
    }
}
