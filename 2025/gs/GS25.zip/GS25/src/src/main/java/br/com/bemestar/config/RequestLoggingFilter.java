package br.com.bemestar.config;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.ext.Provider;
import java.io.IOException;

/**
 * Filtro para logar todas as requisições recebidas
 */
@Provider
public class RequestLoggingFilter implements ContainerRequestFilter {

    @Override
    public void filter(ContainerRequestContext requestContext) throws IOException {
        String method = requestContext.getMethod();
        String path = requestContext.getUriInfo().getPath();
        String queryParams = requestContext.getUriInfo().getRequestUri().getQuery();
        
        System.out.println("========================================");
        System.out.println("[RequestLoggingFilter] Requisição recebida:");
        System.out.println("  Método: " + method);
        System.out.println("  Path: " + path);
        if (queryParams != null) {
            System.out.println("  Query: " + queryParams);
        }
        System.out.println("========================================");
    }
}

