package br.com.bemestar;

import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.grizzly.http.server.StaticHttpHandler;

import br.com.bemestar.config.CorsFilter;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe principal para iniciar o servidor Grizzly
 */
public class App {

    public static final String BASE_URI = "http://localhost:8080/";
    public static final String API_URI = "http://localhost:8080/api/";

    public static HttpServer startServer() {
        // Escaneia o pacote controller para encontrar recursos JAX-RS
        final ResourceConfig rc = new ResourceConfig()
            .packages("br.com.bemestar.controller")
            .register(CorsFilter.class) // Registrar filtro CORS
            .register(br.com.bemestar.config.RequestLoggingFilter.class) // Registrar filtro de logging
            .register(br.com.bemestar.config.JacksonConfig.class); // Configurar Jackson para Java 8 date/time

        // Cria e inicia o servidor HTTP Grizzly
        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(URI.create(API_URI), rc);
        
        // Configurar servidor de arquivos estáticos (webapp)
        // Tenta diferentes caminhos possíveis baseado no diretório de execução
        File webappDir = null;
        String userDir = System.getProperty("user.dir");
        String[] possiblePaths = {
            userDir + "/src/main/webapp",
            userDir + "/main/webapp",
            userDir + "/../main/webapp",
            "src/main/webapp",
            "main/webapp"
        };
        
        for (String path : possiblePaths) {
            File testDir = new File(path);
            if (testDir.exists() && testDir.isDirectory()) {
                webappDir = testDir;
                break;
            }
        }
        
        if (webappDir != null && webappDir.exists()) {
            StaticHttpHandler staticHandler = new StaticHttpHandler(webappDir.getAbsolutePath());
            server.getServerConfiguration().addHttpHandler(staticHandler, "/");
            System.out.println("Servindo arquivos estáticos de: " + webappDir.getAbsolutePath());
        } else {
            System.out.println("AVISO: Diretório webapp não encontrado. Servindo apenas API.");
            System.out.println("Certifique-se de executar a partir do diretório 'src' do projeto.");
        }
        
        return server;
    }

    public static void main(String[] args) {
        try {
            final HttpServer server = startServer();

            System.out.println("========================================");
            System.out.println("Servidor iniciado com sucesso!");
            System.out.println("========================================");
            System.out.println("API REST: " + API_URI);
            System.out.println("Frontend: " + BASE_URI);
            System.out.println("WADL: " + API_URI + "application.wadl");
            System.out.println("========================================");
            System.out.println("Pressione ENTER para parar o servidor...");
            System.in.read();
            server.shutdownNow();
        } catch (IOException ex) {
            Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

