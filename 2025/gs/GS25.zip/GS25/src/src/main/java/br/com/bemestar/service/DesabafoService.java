package br.com.bemestar.service;

import br.com.bemestar.dao.DesabafoDAO;
import br.com.bemestar.dao.UsuarioDAO;
import br.com.bemestar.model.Desabafo;
import br.com.bemestar.model.Usuario;
import br.com.bemestar.util.HashUtil;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service para Desabafo
 * Contém lógica de negócio e anonimização
 */
public class DesabafoService {
    private DesabafoDAO desabafoDAO;
    private UsuarioDAO usuarioDAO;

    public DesabafoService() {
        this.desabafoDAO = new DesabafoDAO();
        this.usuarioDAO = new UsuarioDAO();
    }

    /**
     * Cria um novo desabafo anonimizado
     */
    public boolean criarDesabafo(Desabafo desabafo, Long usuarioId) throws SQLException {
        // Gerar ID anônimo
        if (desabafo.getId() == null) {
            String hashId = HashUtil.gerarHashAnonimo(usuarioId, System.currentTimeMillis());
            desabafo.setId(hashId);
        }
        
        // Definir dados do usuário (anonimizados)
        if (usuarioId != null) {
            Usuario usuario = usuarioDAO.buscarPorId(usuarioId);
            if (usuario != null) {
                desabafo.setUsuarioId(usuarioId);
                desabafo.setSessionHash(HashUtil.gerarSessionHash(usuarioId));
                
                // Apenas incluir departamento e faixa etária se houver > 5 pessoas
                // (lógica simplificada - em produção, verificar contagem)
                desabafo.setDepartamento(usuario.getDepartamento());
                desabafo.setFaixaEtaria(usuario.getFaixaEtaria());
            }
        }
        
        // Definir data de processamento
        if (desabafo.getDataProcessamento() == null) {
            desabafo.setDataProcessamento(LocalDate.now());
        }
        
        // Definir data de criação
        if (desabafo.getDataCriacao() == null) {
            desabafo.setDataCriacao(LocalDateTime.now());
        }
        
        return desabafoDAO.criar(desabafo);
    }

    /**
     * Busca desabafo por ID
     */
    public Desabafo buscarDesabafo(String id) throws SQLException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return desabafoDAO.buscarPorId(id);
    }

    /**
     * Lista todos os desabafos
     */
    public List<Desabafo> listarDesabafos() throws SQLException {
        return desabafoDAO.listarTodos();
    }

    /**
     * Busca desabafos por período
     */
    public List<Desabafo> buscarDesabafosPorPeriodo(int mes, int ano) throws SQLException {
        if (mes < 1 || mes > 12) {
            throw new IllegalArgumentException("Mês inválido!");
        }
        if (ano < 2000 || ano > 2100) {
            throw new IllegalArgumentException("Ano inválido!");
        }
        return desabafoDAO.buscarPorPeriodo(mes, ano);
    }

    /**
     * Busca desabafos por sentimento
     */
    public List<Desabafo> buscarDesabafosPorSentimento(Desabafo.SentimentoPrincipal sentimento) throws SQLException {
        if (sentimento == null) {
            throw new IllegalArgumentException("Sentimento inválido!");
        }
        return desabafoDAO.buscarPorSentimento(sentimento);
    }

    /**
     * Atualiza um desabafo
     */
    public boolean atualizarDesabafo(Desabafo desabafo) throws SQLException {
        if (desabafo.getId() == null) {
            throw new IllegalArgumentException("ID do desabafo é obrigatório!");
        }
        return desabafoDAO.atualizar(desabafo);
    }

    /**
     * Remove um desabafo
     */
    public boolean deletarDesabafo(String id) throws SQLException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return desabafoDAO.deletar(id);
    }
}

