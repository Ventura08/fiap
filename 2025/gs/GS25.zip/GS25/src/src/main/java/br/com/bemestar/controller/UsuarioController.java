package br.com.bemestar.controller;

import br.com.bemestar.model.Usuario;
import br.com.bemestar.service.UsuarioService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/usuarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class UsuarioController {

    private final UsuarioService usuarioService;

    public UsuarioController() {
        this.usuarioService = new UsuarioService();
    }

    @GET
    public Response listarUsuarios() {
        try {
            List<Usuario> usuarios = usuarioService.listarUsuarios();
            return Response.ok(usuarios).build();
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @GET
    @Path("/{param}")
    public Response buscarUsuario(@PathParam("param") String param) {
        try {
            if (param.contains("@")) {
                Usuario usuario = usuarioService.buscarUsuarioPorEmail(param);
                if (usuario != null) {
                    return Response.ok(usuario).build();
                }
            } else {
                try {
                    Long id = Long.parseLong(param);
                    Usuario usuario = usuarioService.buscarUsuario(id);
                    if (usuario != null) {
                        return Response.ok(usuario).build();
                    }
                } catch (NumberFormatException e) {
                     return createErrorResponse(Response.Status.BAD_REQUEST, "ID inválido");
                }
            }
            return createErrorResponse(Response.Status.NOT_FOUND, "Usuário não encontrado");
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @POST
    public Response criarUsuario(Usuario usuario) {
        try {
            Long id = usuarioService.criarUsuario(usuario);
            if (id != null) {
                usuario.setId(id);
                return Response.status(Response.Status.CREATED).entity(usuario).build();
            } else {
                return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao criar usuário");
            }
        } catch (IllegalArgumentException e) {
            return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @PUT
    public Response atualizarUsuario(Usuario usuario) {
        try {
            boolean sucesso = usuarioService.atualizarUsuario(usuario);
            if (sucesso) {
                return Response.ok(usuario).build();
            } else {
                 return createErrorResponse(Response.Status.NOT_FOUND, "Usuário não encontrado");
            }
        } catch (IllegalArgumentException e) {
             return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
             return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @PUT
    @Path("/{id}/perfil-neurocognitivo")
    public Response atualizarPerfilNeurocognitivo(@PathParam("id") Long id, Map<String, Object> perfilData) {
        try {
            Usuario usuario = usuarioService.buscarUsuario(id);
            if (usuario == null) {
                return createErrorResponse(Response.Status.NOT_FOUND, "Usuário não encontrado");
            }
            
            // O perfil neurocognitivo será armazenado como JSON no frontend (localStorage)
            // Aqui apenas validamos que o usuário existe
            // Em uma implementação futura, podemos adicionar um campo JSON no banco
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Perfil neurocognitivo atualizado com sucesso");
            response.put("usuarioId", id);
            
            return Response.ok(response).build();
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deletarUsuario(@PathParam("id") Long id) {
        try {
            boolean sucesso = usuarioService.deletarUsuario(id);
            if (sucesso) {
                 return createSuccessResponse("Usuário removido com sucesso");
            } else {
                 return createErrorResponse(Response.Status.NOT_FOUND, "Usuário não encontrado");
            }
        } catch (SQLException e) {
             return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @POST
    @Path("/login")
    public Response login(Map<String, String> credentials) {
        try {
            String email = credentials.get("email");
            String senha = credentials.get("senha");
            
            if (email == null || senha == null) {
                return createErrorResponse(Response.Status.BAD_REQUEST, "Email e senha são obrigatórios");
            }
            
            Usuario usuario = usuarioService.autenticar(email, senha);
            if (usuario != null) {
                // Não retornar a senha
                usuario.setSenha(null);
                Map<String, Object> response = new HashMap<>();
                response.put("usuario", usuario);
                response.put("success", true);
                return Response.ok(response).build();
            } else {
                return createErrorResponse(Response.Status.UNAUTHORIZED, "Email ou senha inválidos");
            }
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    private Response createErrorResponse(Response.Status status, String message) {
        Map<String, String> response = new HashMap<>();
        response.put("error", message);
        return Response.status(status).entity(response).build();
    }

    private Response createSuccessResponse(String message) {
        Map<String, String> response = new HashMap<>();
        response.put("success", message);
        return Response.ok(response).build();
    }
}
