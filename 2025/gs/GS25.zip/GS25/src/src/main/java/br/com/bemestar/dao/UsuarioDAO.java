package br.com.bemestar.dao;

import br.com.bemestar.model.Usuario;
import br.com.bemestar.util.ConexaoJDBC;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) para Usuario
 * Implementa operações CRUD usando JDBC
 */
public class UsuarioDAO {
    private ConexaoJDBC conexaoJDBC;

    public UsuarioDAO() {
        this.conexaoJDBC = ConexaoJDBC.getInstance();
    }

    /**
     * Cria um novo usuário (CREATE) - Oracle com trigger
     */
    public Long criar(Usuario usuario) throws SQLException {
        // Para Oracle com trigger, não incluímos o ID (será gerado pelo trigger)
        try (Connection conn = conexaoJDBC.getConnection()) {
            // Garantir que auto-commit está desabilitado para controle manual
            boolean originalAutoCommit = conn.getAutoCommit();
            try {
                conn.setAutoCommit(false);
                
                String sql = "INSERT INTO usuarios (nome, email, senha, telefone, cidade, estado, " +
                             "departamento, faixa_etaria, perfil, ativo, data_cadastro) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, usuario.getNome());
                    stmt.setString(2, usuario.getEmail());
                    stmt.setString(3, usuario.getSenha());
                    stmt.setString(4, usuario.getTelefone());
                    stmt.setString(5, usuario.getCidade());
                    stmt.setString(6, usuario.getEstado());
                    stmt.setString(7, usuario.getDepartamento());
                    stmt.setString(8, usuario.getFaixaEtaria());
                    stmt.setString(9, usuario.getPerfil().name());
                    // Oracle usa NUMBER(1) para boolean
                    stmt.setInt(10, usuario.getAtivo() ? 1 : 0);
                    stmt.setTimestamp(11, Timestamp.valueOf(
                        usuario.getDataCadastro() != null ? usuario.getDataCadastro() : java.time.LocalDateTime.now()));
                    
                    int rowsAffected = stmt.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        // Buscar o ID gerado pelo trigger usando CURRVAL da sequência
                        // IMPORTANTE: CURRVAL só funciona na mesma sessão/transação
                        Long id = null;
                        try (PreparedStatement stmtId = conn.prepareStatement("SELECT seq_usuarios.CURRVAL FROM DUAL")) {
                            try (ResultSet rs = stmtId.executeQuery()) {
                                if (rs.next()) {
                                    id = rs.getLong(1);
                                }
                            }
                        } catch (SQLException e) {
                            // Se CURRVAL falhar, buscar pelo email (único) após commit
                            // Silenciosamente tenta buscar por email
                        }
                        
                        // Fazer COMMIT explícito
                        conn.commit();
                        
                        // Se não conseguiu pelo CURRVAL, buscar por email após commit
                        if (id == null) {
                            Usuario criado = buscarPorEmail(usuario.getEmail());
                            if (criado != null) {
                                id = criado.getId();
                            }
                        }
                        
                        return id;
                    } else {
                        conn.rollback();
                        return null;
                    }
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                // Restaurar auto-commit original
                conn.setAutoCommit(originalAutoCommit);
            }
        }
    }

    /**
     * Busca um usuário por ID (READ)
     */
    public Usuario buscarPorId(Long id) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearResultSetParaUsuario(rs);
                }
            }
        }
        return null;
    }

    /**
     * Busca um usuário por email (READ)
     */
    public Usuario buscarPorEmail(String email) throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE email = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, email);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearResultSetParaUsuario(rs);
                }
            }
        }
        return null;
    }

    /**
     * Lista todos os usuários (READ)
     */
    public List<Usuario> listarTodos() throws SQLException {
        String sql = "SELECT * FROM usuarios WHERE ativo = 1 ORDER BY nome";
        List<Usuario> usuarios = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                usuarios.add(mapearResultSetParaUsuario(rs));
            }
        }
        return usuarios;
    }

    /**
     * Atualiza um usuário (UPDATE)
     */
    public boolean atualizar(Usuario usuario) throws SQLException {
        String sql = "UPDATE usuarios SET nome = ?, email = ?, senha = ?, telefone = ?, " +
                     "cidade = ?, estado = ?, departamento = ?, faixa_etaria = ?, " +
                     "perfil = ?, ativo = ? WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getEmail());
            stmt.setString(3, usuario.getSenha());
            stmt.setString(4, usuario.getTelefone());
            stmt.setString(5, usuario.getCidade());
            stmt.setString(6, usuario.getEstado());
            stmt.setString(7, usuario.getDepartamento());
            stmt.setString(8, usuario.getFaixaEtaria());
            stmt.setString(9, usuario.getPerfil().name());
            // Oracle usa NUMBER(1) para boolean
            stmt.setInt(10, usuario.getAtivo() ? 1 : 0);
            stmt.setLong(11, usuario.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Remove um usuário (DELETE - soft delete)
     */
    public boolean deletar(Long id) throws SQLException {
        String sql = "UPDATE usuarios SET ativo = 0 WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Mapeia ResultSet para objeto Usuario
     */
    private Usuario mapearResultSetParaUsuario(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setId(rs.getLong("id"));
        usuario.setNome(rs.getString("nome"));
        usuario.setEmail(rs.getString("email"));
        usuario.setSenha(rs.getString("senha"));
        usuario.setTelefone(rs.getString("telefone"));
        usuario.setCidade(rs.getString("cidade"));
        usuario.setEstado(rs.getString("estado"));
        usuario.setDepartamento(rs.getString("departamento"));
        usuario.setFaixaEtaria(rs.getString("faixa_etaria"));
        usuario.setPerfil(Usuario.PerfilUsuario.valueOf(rs.getString("perfil")));
            Timestamp dataCadastro = rs.getTimestamp("data_cadastro");
            if (dataCadastro != null) {
                usuario.setDataCadastro(dataCadastro.toLocalDateTime());
            }
            // Oracle usa NUMBER(1) para boolean (0 ou 1)
            int ativoInt = rs.getInt("ativo");
            usuario.setAtivo(ativoInt == 1);
        return usuario;
    }
}

