package br.com.bemestar.service;

import br.com.bemestar.dao.UsuarioDAO;
import br.com.bemestar.model.Usuario;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service para Usuario
 * Contém lógica de negócio e validações
 */
public class UsuarioService {
    private UsuarioDAO usuarioDAO;

    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    /**
     * Cria um novo usuário com validações
     */
    public Long criarUsuario(Usuario usuario) throws SQLException, IllegalArgumentException {
        validarUsuario(usuario);
        
        // Verificar se email já existe
        Usuario existente = usuarioDAO.buscarPorEmail(usuario.getEmail());
        if (existente != null) {
            throw new IllegalArgumentException("Email já cadastrado!");
        }
        
        // Definir data de cadastro
        if (usuario.getDataCadastro() == null) {
            usuario.setDataCadastro(LocalDateTime.now());
        }
        
        return usuarioDAO.criar(usuario);
    }

    /**
     * Busca usuário por ID
     */
    public Usuario buscarUsuario(Long id) throws SQLException {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return usuarioDAO.buscarPorId(id);
    }

    /**
     * Busca usuário por email
     */
    public Usuario buscarUsuarioPorEmail(String email) throws SQLException {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email inválido!");
        }
        return usuarioDAO.buscarPorEmail(email);
    }

    /**
     * Lista todos os usuários ativos
     */
    public List<Usuario> listarUsuarios() throws SQLException {
        return usuarioDAO.listarTodos();
    }

    /**
     * Atualiza um usuário
     */
    public boolean atualizarUsuario(Usuario usuario) throws SQLException, IllegalArgumentException {
        if (usuario.getId() == null) {
            throw new IllegalArgumentException("ID do usuário é obrigatório!");
        }
        validarUsuario(usuario);
        return usuarioDAO.atualizar(usuario);
    }

    /**
     * Remove um usuário (soft delete)
     */
    public boolean deletarUsuario(Long id) throws SQLException {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return usuarioDAO.deletar(id);
    }

    /**
     * Valida dados do usuário
     */
    private void validarUsuario(Usuario usuario) throws IllegalArgumentException {
        if (usuario.getNome() == null || usuario.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome é obrigatório!");
        }
        if (usuario.getEmail() == null || usuario.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email é obrigatório!");
        }
        if (!usuario.getEmail().contains("@")) {
            throw new IllegalArgumentException("Email inválido!");
        }
        if (usuario.getSenha() == null || usuario.getSenha().trim().isEmpty()) {
            throw new IllegalArgumentException("Senha é obrigatória!");
        }
        if (usuario.getSenha().length() < 6) {
            throw new IllegalArgumentException("Senha deve ter no mínimo 6 caracteres!");
        }
    }

    /**
     * Autentica um usuário
     */
    public Usuario autenticar(String email, String senha) throws SQLException {
        if (email == null || email.trim().isEmpty() || senha == null || senha.trim().isEmpty()) {
            return null;
        }
        
        Usuario usuario = usuarioDAO.buscarPorEmail(email);
        if (usuario != null && usuario.getSenha() != null && 
            usuario.getSenha().equals(senha) && usuario.getAtivo()) {
            return usuario;
        }
        return null;
    }
}

