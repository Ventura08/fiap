package br.com.bemestar.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Classe utilitária para gerenciar conexões JDBC
 * Implementa padrão Singleton para pool de conexões
 * Configurações são carregadas de variáveis de ambiente ou arquivo properties
 */
public class ConexaoJDBC {
    private static ConexaoJDBC instance;
    private String url;
    private String username;
    private String password;
    private String driver;

    private ConexaoJDBC() {
        carregarConfiguracao();
    }

    /**
     * Obtém instância única da classe (Singleton)
     */
    public static synchronized ConexaoJDBC getInstance() {
        if (instance == null) {
            instance = new ConexaoJDBC();
        }
        return instance;
    }

    /**
     * Carrega configurações de variáveis de ambiente
     * Fallback: arquivo database/db.properties
     */
    private void carregarConfiguracao() {
        try {
            // Tenta carregar de variáveis de ambiente primeiro
            this.driver = System.getenv("DB_DRIVER");
            this.url = System.getenv("DB_URL");
            this.username = System.getenv("DB_USERNAME");
            this.password = System.getenv("DB_PASSWORD");

            // Se URL não estiver definida, tenta carregar do arquivo de propriedades
            if (this.url == null || this.url.isEmpty()) {
                try (InputStream input = getClass().getClassLoader().getResourceAsStream("database/db.properties")) {
                    if (input != null) {
                        Properties prop = new Properties();
                        prop.load(input);

                        // Só sobrescreve se não veio do ambiente e existe no properties
                        if (this.driver == null) this.driver = prop.getProperty("db.driver");
                        if (this.url == null) this.url = prop.getProperty("db.url");
                        if (this.username == null) this.username = prop.getProperty("db.username");
                        if (this.password == null) this.password = prop.getProperty("db.password");
                    }
                } catch (IOException ex) {
                    System.err.println("Aviso: Não foi possível ler db.properties: " + ex.getMessage());
                }
            }

            // Validação final e padrões
            if (this.driver == null || this.driver.isEmpty()) {
                this.driver = "oracle.jdbc.OracleDriver"; // Valor padrão para Oracle
            }
            
            if (this.url == null || this.url.isEmpty()) {
                throw new RuntimeException("Configuração DB_URL não encontrada (nem ENV nem db.properties)!");
            }
            
            if (this.username == null || this.username.isEmpty()) {
                throw new RuntimeException("Configuração DB_USERNAME não encontrada!");
            }
            
            if (this.password == null) {
                 this.password = ""; // Permite senha vazia se definida explicitamente como tal ou não encontrada
            }
            
            // Carregar driver JDBC
            Class.forName(driver);
            
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver JDBC não encontrado: " + driver, e);
        } catch (RuntimeException e) {
            // Re-lançar RuntimeException sem modificar
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Erro ao carregar configurações do banco de dados: " + e.getMessage(), e);
        }
    }

    /**
     * Obtém uma conexão com o banco de dados
     */
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    /**
     * Fecha uma conexão
     */
    public void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Erro ao fechar conexão: " + e.getMessage());
            }
        }
    }
}

