package br.com.bemestar.controller;

import br.com.bemestar.model.Questionario;
import br.com.bemestar.service.QuestionarioService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/questionarios")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class QuestionarioController {

    private final QuestionarioService questionarioService;

    public QuestionarioController() {
        System.out.println("========================================");
        System.out.println("[QuestionarioController] Controller inicializado!");
        System.out.println("========================================");
        this.questionarioService = new QuestionarioService();
    }

    @GET
    public Response listarQuestionarios(@QueryParam("mes") Integer mes, 
                                      @QueryParam("ano") Integer ano) {
        try {
            List<Questionario> questionarios;
            if (mes != null && ano != null) {
                questionarios = questionarioService.buscarQuestionariosPorPeriodo(mes, ano);
            } else {
                questionarios = questionarioService.listarQuestionarios();
            }
            return Response.ok(questionarios).build();
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @GET
    @Path("/verificar")
    public Response verificarResposta(@QueryParam("usuarioId") Long usuarioId,
                                    @QueryParam("mes") Integer mes,
                                    @QueryParam("ano") Integer ano) {
         if (usuarioId != null && mes != null && ano != null) {
             try {
                 boolean jaRespondeu = questionarioService.jaRespondeuMes(usuarioId, mes, ano);
                 Map<String, Boolean> result = new HashMap<>();
                 result.put("jaRespondeu", jaRespondeu);
                 return Response.ok(result).build();
             } catch (SQLException e) {
                 return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
             }
         }
         return createErrorResponse(Response.Status.BAD_REQUEST, "Parâmetros incompletos");
    }

    @GET
    @Path("/{id}")
    public Response buscarQuestionario(@PathParam("id") String id) {
        try {
            Questionario questionario = questionarioService.buscarQuestionario(id);
            if (questionario != null) {
                return Response.ok(questionario).build();
            } else {
                return createErrorResponse(Response.Status.NOT_FOUND, "Questionário não encontrado");
            }
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @POST
    public Response criarQuestionario(Map<String, Object> data) {
        System.out.println("========================================");
        System.out.println("[QuestionarioController] MÉTODO criarQuestionario CHAMADO!");
        System.out.println("[QuestionarioController] Dados recebidos: " + data);
        System.out.println("========================================");
        try {
            
            Questionario questionario = new Questionario();
            
            // Definir mesAno se fornecido
            Object mesAnoObj = data.get("mesAno");
            if (mesAnoObj != null) {
                questionario.setMesAno(mesAnoObj.toString());
                System.out.println("[QuestionarioController] mesAno definido: " + mesAnoObj.toString());
            }
            
            Object respostasObj = data.get("respostas");
            if (respostasObj instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> respostas = (Map<String, Object>) respostasObj;
                System.out.println("[QuestionarioController] Respostas recebidas: " + respostas);
                
                questionario.setCargaTrabalho(getIntegerFromMap(respostas, "cargaTrabalho"));
                questionario.setReconhecimento(getIntegerFromMap(respostas, "reconhecimento"));
                questionario.setRelacionamentoInterpessoal(getIntegerFromMap(respostas, "relacionamentoInterpessoal"));
                questionario.setEquilibrioTrabalhoVida(getIntegerFromMap(respostas, "equilibrioTrabalhoVida"));
                questionario.setComunicacao(getIntegerFromMap(respostas, "comunicacao"));
                questionario.setAutonomia(getIntegerFromMap(respostas, "autonomia"));
                questionario.setDesenvolvimento(getIntegerFromMap(respostas, "desenvolvimento"));
                questionario.setAmbienteTrabalho(getIntegerFromMap(respostas, "ambienteTrabalho"));
                questionario.setSuporteLideranca(getIntegerFromMap(respostas, "suporteLideranca"));
                questionario.setSatisfacaoGeral(getIntegerFromMap(respostas, "satisfacaoGeral"));
            }
            
            Long usuarioId = null;
            Object usuarioIdObj = data.get("usuarioId");
            if (usuarioIdObj != null && usuarioIdObj instanceof Number) {
                usuarioId = ((Number) usuarioIdObj).longValue();
                System.out.println("[QuestionarioController] usuarioId: " + usuarioId);
            }
            
            System.out.println("[QuestionarioController] Chamando service para criar questionário...");
            boolean sucesso = questionarioService.criarQuestionario(questionario, usuarioId);
            System.out.println("[QuestionarioController] Resultado da criação: " + sucesso);
            
            if (sucesso) {
                System.out.println("[QuestionarioController] Questionário criado com sucesso. ID: " + questionario.getId());
                return Response.status(Response.Status.CREATED).entity(questionario).build();
            } else {
                System.err.println("[QuestionarioController] ERRO: Service retornou false ao criar questionário");
                return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao criar questionário");
            }
        } catch (IllegalArgumentException e) {
            System.err.println("[QuestionarioController] Erro de validação: " + e.getMessage());
            e.printStackTrace();
            return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
            System.err.println("[QuestionarioController] Erro SQL: " + e.getMessage());
            e.printStackTrace();
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("[QuestionarioController] Erro inesperado: " + e.getMessage());
            e.printStackTrace();
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro inesperado: " + e.getMessage());
        }
    }

    @PUT
    public Response atualizarQuestionario(Questionario questionario) {
        try {
            boolean sucesso = questionarioService.atualizarQuestionario(questionario);
            if (sucesso) {
                return Response.ok(questionario).build();
            } else {
                return createErrorResponse(Response.Status.NOT_FOUND, "Questionário não encontrado");
            }
        } catch (IllegalArgumentException e) {
            return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deletarQuestionario(@PathParam("id") String id) {
        try {
            boolean sucesso = questionarioService.deletarQuestionario(id);
            if (sucesso) {
                 return createSuccessResponse("Questionário removido com sucesso");
            } else {
                 return createErrorResponse(Response.Status.NOT_FOUND, "Questionário não encontrado");
            }
        } catch (SQLException e) {
             return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    private Integer getIntegerFromMap(Map<String, Object> map, String key) {
        Object value = map.get(key);
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return null;
    }

    private Response createErrorResponse(Response.Status status, String message) {
        Map<String, String> response = new HashMap<>();
        response.put("error", message);
        return Response.status(status).entity(response).build();
    }

    private Response createSuccessResponse(String message) {
        Map<String, String> response = new HashMap<>();
        response.put("success", message);
        return Response.ok(response).build();
    }
}
