package br.com.bemestar.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Classe utilitária para geração de hashes
 * Usada para anonimização de dados
 */
public class HashUtil {
    
    /**
     * Gera hash SHA-256 de uma string
     */
    public static String gerarHashSHA256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            
            return hexString.toString().substring(0, 32); // Primeiros 32 caracteres
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Erro ao gerar hash", e);
        }
    }

    /**
     * Gera hash anônimo para desabafos e questionários
     */
    public static String gerarHashAnonimo(Long userId, Long timestamp) {
        String input = userId + "_" + timestamp + "_" + System.currentTimeMillis();
        return gerarHashSHA256(input);
    }

    /**
     * Gera hash de sessão (por dia)
     */
    public static String gerarSessionHash(Long userId) {
        long timestamp = System.currentTimeMillis() / (1000 * 60 * 60 * 24); // Por dia
        String input = userId + "_" + timestamp;
        return gerarHashSHA256(input);
    }
}

