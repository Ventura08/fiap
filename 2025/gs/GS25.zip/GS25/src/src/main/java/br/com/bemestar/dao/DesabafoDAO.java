package br.com.bemestar.dao;

import br.com.bemestar.model.Desabafo;
import br.com.bemestar.util.ConexaoJDBC;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) para Desabafo
 * Implementa operações CRUD usando JDBC
 */
public class DesabafoDAO {
    private ConexaoJDBC conexaoJDBC;

    public DesabafoDAO() {
        this.conexaoJDBC = ConexaoJDBC.getInstance();
    }

    /**
     * Cria um novo desabafo (CREATE)
     */
    public boolean criar(Desabafo desabafo) throws SQLException {
        String sql = "INSERT INTO desabafos (id, usuario_id, data_processamento, sentimento_principal, " +
                     "topico_recorrente, intensidade_sentimento, departamento, faixa_etaria, " +
                     "session_hash, data_criacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, desabafo.getId());
            stmt.setObject(2, desabafo.getUsuarioId(), Types.BIGINT);
            stmt.setDate(3, Date.valueOf(desabafo.getDataProcessamento()));
            stmt.setString(4, desabafo.getSentimentoPrincipal().name());
            // Converter enum para formato do banco (com underscore)
            String topicoStr = desabafo.getTopicoRecorrente().name();
            stmt.setString(5, topicoStr);
            stmt.setInt(6, desabafo.getIntensidadeSentimento());
            stmt.setString(7, desabafo.getDepartamento());
            stmt.setString(8, desabafo.getFaixaEtaria());
            stmt.setString(9, desabafo.getSessionHash());
            stmt.setTimestamp(10, Timestamp.valueOf(
                desabafo.getDataCriacao() != null ? desabafo.getDataCriacao() : java.time.LocalDateTime.now()));
            
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Busca um desabafo por ID (READ)
     */
    public Desabafo buscarPorId(String id) throws SQLException {
        String sql = "SELECT * FROM desabafos WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearResultSetParaDesabafo(rs);
                }
            }
        }
        return null;
    }

    /**
     * Lista todos os desabafos (READ)
     */
    public List<Desabafo> listarTodos() throws SQLException {
        String sql = "SELECT * FROM desabafos ORDER BY data_processamento DESC";
        List<Desabafo> desabafos = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                desabafos.add(mapearResultSetParaDesabafo(rs));
            }
        }
        return desabafos;
    }

    /**
     * Busca desabafos por período (READ) - Oracle
     */
    public List<Desabafo> buscarPorPeriodo(int mes, int ano) throws SQLException {
        String sql = "SELECT * FROM desabafos WHERE EXTRACT(MONTH FROM data_processamento) = ? " +
                     "AND EXTRACT(YEAR FROM data_processamento) = ? ORDER BY data_processamento DESC";
        List<Desabafo> desabafos = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, mes);
            stmt.setInt(2, ano);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    desabafos.add(mapearResultSetParaDesabafo(rs));
                }
            }
        }
        return desabafos;
    }

    /**
     * Busca desabafos por sentimento (READ)
     */
    public List<Desabafo> buscarPorSentimento(Desabafo.SentimentoPrincipal sentimento) throws SQLException {
        String sql = "SELECT * FROM desabafos WHERE sentimento_principal = ? ORDER BY data_processamento DESC";
        List<Desabafo> desabafos = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, sentimento.name());
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    desabafos.add(mapearResultSetParaDesabafo(rs));
                }
            }
        }
        return desabafos;
    }

    /**
     * Atualiza um desabafo (UPDATE)
     */
    public boolean atualizar(Desabafo desabafo) throws SQLException {
        String sql = "UPDATE desabafos SET sentimento_principal = ?, topico_recorrente = ?, " +
                     "intensidade_sentimento = ?, departamento = ?, faixa_etaria = ? WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, desabafo.getSentimentoPrincipal().name());
            stmt.setString(2, desabafo.getTopicoRecorrente().name());
            stmt.setInt(3, desabafo.getIntensidadeSentimento());
            stmt.setString(4, desabafo.getDepartamento());
            stmt.setString(5, desabafo.getFaixaEtaria());
            stmt.setString(6, desabafo.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Remove um desabafo (DELETE)
     */
    public boolean deletar(String id) throws SQLException {
        String sql = "DELETE FROM desabafos WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Mapeia ResultSet para objeto Desabafo
     */
    private Desabafo mapearResultSetParaDesabafo(ResultSet rs) throws SQLException {
        Desabafo desabafo = new Desabafo();
        desabafo.setId(rs.getString("id"));
        
        Long usuarioId = rs.getLong("usuario_id");
        if (!rs.wasNull()) {
            desabafo.setUsuarioId(usuarioId);
        }
        
        desabafo.setDataProcessamento(rs.getDate("data_processamento").toLocalDate());
        
        // Converter sentimento do banco para enum
        String sentimentoStr = rs.getString("sentimento_principal");
        desabafo.setSentimentoPrincipal(Desabafo.SentimentoPrincipal.valueOf(sentimentoStr));
        
        // Converter tópico do banco (com underscore) para enum
        String topicoStr = rs.getString("topico_recorrente");
        if (topicoStr != null) {
            // Converter espaços para underscore para corresponder ao enum
            topicoStr = topicoStr.replace(" ", "_").replace("-", "_");
            desabafo.setTopicoRecorrente(Desabafo.TopicoRecorrente.valueOf(topicoStr));
        }
        desabafo.setIntensidadeSentimento(rs.getInt("intensidade_sentimento"));
        desabafo.setDepartamento(rs.getString("departamento"));
        desabafo.setFaixaEtaria(rs.getString("faixa_etaria"));
        desabafo.setSessionHash(rs.getString("session_hash"));
        
        Timestamp dataCriacao = rs.getTimestamp("data_criacao");
        if (dataCriacao != null) {
            desabafo.setDataCriacao(dataCriacao.toLocalDateTime());
        }
        
        return desabafo;
    }
}

