package br.com.bemestar.controller;

import br.com.bemestar.model.Desabafo;
import br.com.bemestar.service.DesabafoService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Path("/desabafos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class DesabafoController {

    private final DesabafoService desabafoService;

    public DesabafoController() {
        this.desabafoService = new DesabafoService();
    }

    @GET
    public Response listarDesabafos(@QueryParam("mes") Integer mes, 
                                  @QueryParam("ano") Integer ano, 
                                  @QueryParam("sentimento") String sentimento) {
        try {
            List<Desabafo> desabafos;
            if (mes != null && ano != null) {
                 desabafos = desabafoService.buscarDesabafosPorPeriodo(mes, ano);
            } else if (sentimento != null) {
                try {
                    Desabafo.SentimentoPrincipal sent = Desabafo.SentimentoPrincipal.valueOf(sentimento);
                    desabafos = desabafoService.buscarDesabafosPorSentimento(sent);
                } catch (IllegalArgumentException e) {
                    return createErrorResponse(Response.Status.BAD_REQUEST, "Sentimento inválido");
                }
            } else {
                desabafos = desabafoService.listarDesabafos();
            }
            return Response.ok(desabafos).build();
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @GET
    @Path("/{id}")
    public Response buscarDesabafo(@PathParam("id") String id) {
        try {
            Desabafo desabafo = desabafoService.buscarDesabafo(id);
            if (desabafo != null) {
                return Response.ok(desabafo).build();
            } else {
                return createErrorResponse(Response.Status.NOT_FOUND, "Desabafo não encontrado");
            }
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @POST
    public Response criarDesabafo(Map<String, Object> data) {
        try {
            Desabafo desabafo = new Desabafo();
            desabafo.setSentimentoPrincipal(Desabafo.SentimentoPrincipal.valueOf(
                (String) data.get("sentimentoPrincipal")));
            
            // Converter tópico do frontend (com espaços/hífens) para enum (com underscores)
            String topicoStr = (String) data.get("topicoRecorrente");
            if (topicoStr != null) {
                topicoStr = topicoStr.replace(" ", "_").replace("-", "_");
                desabafo.setTopicoRecorrente(Desabafo.TopicoRecorrente.valueOf(topicoStr));
            }
            
            Object intensidadeObj = data.get("intensidadeSentimento");
            if (intensidadeObj instanceof Number) {
                desabafo.setIntensidadeSentimento(((Number) intensidadeObj).intValue());
            }
            
            Long usuarioId = null;
            Object usuarioIdObj = data.get("usuarioId");
            if (usuarioIdObj != null && usuarioIdObj instanceof Number) {
                usuarioId = ((Number) usuarioIdObj).longValue();
            }
            
            boolean sucesso = desabafoService.criarDesabafo(desabafo, usuarioId);
            
            if (sucesso) {
                return Response.status(Response.Status.CREATED).entity(desabafo).build();
            } else {
                return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao criar desabafo");
            }
        } catch (IllegalArgumentException e) {
            return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
            return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @PUT
    public Response atualizarDesabafo(Map<String, Object> data) {
        try {
            Desabafo desabafo = new Desabafo();
            desabafo.setId((String) data.get("id"));
            desabafo.setSentimentoPrincipal(Desabafo.SentimentoPrincipal.valueOf(
                (String) data.get("sentimentoPrincipal")));
            
            // Converter tópico do frontend (com espaços/hífens) para enum (com underscores)
            String topicoStr = (String) data.get("topicoRecorrente");
            if (topicoStr != null) {
                topicoStr = topicoStr.replace(" ", "_").replace("-", "_");
                desabafo.setTopicoRecorrente(Desabafo.TopicoRecorrente.valueOf(topicoStr));
            }
            
            Object intensidadeObj = data.get("intensidadeSentimento");
            if (intensidadeObj instanceof Number) {
                desabafo.setIntensidadeSentimento(((Number) intensidadeObj).intValue());
            }
            
            boolean sucesso = desabafoService.atualizarDesabafo(desabafo);
            
            if (sucesso) {
                return Response.ok(desabafo).build();
            } else {
                return createErrorResponse(Response.Status.NOT_FOUND, "Desabafo não encontrado");
            }
        } catch (IllegalArgumentException e) {
             return createErrorResponse(Response.Status.BAD_REQUEST, e.getMessage());
        } catch (SQLException e) {
             return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    @DELETE
    @Path("/{id}")
    public Response deletarDesabafo(@PathParam("id") String id) {
        try {
            boolean sucesso = desabafoService.deletarDesabafo(id);
            if (sucesso) {
                 return createSuccessResponse("Desabafo removido com sucesso");
            } else {
                 return createErrorResponse(Response.Status.NOT_FOUND, "Desabafo não encontrado");
            }
        } catch (SQLException e) {
             return createErrorResponse(Response.Status.INTERNAL_SERVER_ERROR, "Erro ao processar requisição: " + e.getMessage());
        }
    }

    private Response createErrorResponse(Response.Status status, String message) {
        Map<String, String> response = new HashMap<>();
        response.put("error", message);
        return Response.status(status).entity(response).build();
    }

    private Response createSuccessResponse(String message) {
        Map<String, String> response = new HashMap<>();
        response.put("success", message);
        return Response.ok(response).build();
    }
}
