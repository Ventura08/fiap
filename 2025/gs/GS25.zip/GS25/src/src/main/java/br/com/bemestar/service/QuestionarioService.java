package br.com.bemestar.service;

import br.com.bemestar.dao.QuestionarioDAO;
import br.com.bemestar.dao.UsuarioDAO;
import br.com.bemestar.model.Questionario;
import br.com.bemestar.model.Usuario;
import br.com.bemestar.util.HashUtil;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service para Questionario
 * Contém lógica de negócio e validações
 */
public class QuestionarioService {
    private QuestionarioDAO questionarioDAO;
    private UsuarioDAO usuarioDAO;

    public QuestionarioService() {
        this.questionarioDAO = new QuestionarioDAO();
        this.usuarioDAO = new UsuarioDAO();
    }

    /**
     * Cria um novo questionário com validações
     */
    public boolean criarQuestionario(Questionario questionario, Long usuarioId) throws SQLException, IllegalArgumentException {
        System.out.println("[QuestionarioService] Iniciando criação de questionário. usuarioId: " + usuarioId);
        
        // Definir mesAno se não foi fornecido
        if (questionario.getMesAno() == null || questionario.getMesAno().trim().isEmpty()) {
            LocalDate hoje = LocalDate.now();
            String mesAno = String.format("%04d-%02d", hoje.getYear(), hoje.getMonthValue());
            questionario.setMesAno(mesAno);
            System.out.println("[QuestionarioService] mesAno gerado: " + mesAno);
        } else {
            System.out.println("[QuestionarioService] mesAno fornecido: " + questionario.getMesAno());
        }
        
        // Validar se usuário já respondeu este mês
        if (usuarioId != null) {
            boolean jaRespondeu = questionarioDAO.jaRespondeuMes(usuarioId, questionario.getMesAno());
            System.out.println("[QuestionarioService] Usuário já respondeu este mês? " + jaRespondeu);
            if (jaRespondeu) {
                throw new IllegalArgumentException("Você já respondeu o questionário deste mês!");
            }
        }
        
        // Gerar ID anônimo
        if (questionario.getId() == null || questionario.getId().trim().isEmpty()) {
            String hashId = HashUtil.gerarHashAnonimo(usuarioId != null ? usuarioId : 0L, System.currentTimeMillis());
            questionario.setId(hashId);
            System.out.println("[QuestionarioService] ID gerado: " + hashId);
        }
        
        // Definir dados do usuário (anonimizados)
        if (usuarioId != null) {
            Usuario usuario = usuarioDAO.buscarPorId(usuarioId);
            if (usuario != null) {
                questionario.setUsuarioId(usuarioId);
                questionario.setSessionHash(HashUtil.gerarSessionHash(usuarioId));
                questionario.setDepartamento(usuario.getDepartamento());
                questionario.setFaixaEtaria(usuario.getFaixaEtaria());
                System.out.println("[QuestionarioService] Dados do usuário definidos. Departamento: " + usuario.getDepartamento());
            } else {
                System.err.println("[QuestionarioService] AVISO: Usuário não encontrado para ID: " + usuarioId);
            }
        } else {
            // Se não tem usuário, gerar session hash anônimo
            if (questionario.getSessionHash() == null || questionario.getSessionHash().trim().isEmpty()) {
                questionario.setSessionHash(HashUtil.gerarSessionHash(0L));
                System.out.println("[QuestionarioService] Session hash anônimo gerado");
            }
        }
        
        // Definir data de resposta
        if (questionario.getDataResposta() == null) {
            questionario.setDataResposta(LocalDate.now());
        }
        
        // Definir data de criação
        if (questionario.getDataCriacao() == null) {
            questionario.setDataCriacao(LocalDateTime.now());
        }
        
        // Validar respostas (1-5)
        System.out.println("[QuestionarioService] Validando respostas...");
        validarRespostas(questionario);
        System.out.println("[QuestionarioService] Validação passou. Chamando DAO para inserir...");
        
        boolean resultado = questionarioDAO.criar(questionario);
        System.out.println("[QuestionarioService] Resultado do DAO: " + resultado);
        
        return resultado;
    }

    /**
     * Busca questionário por ID
     */
    public Questionario buscarQuestionario(String id) throws SQLException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return questionarioDAO.buscarPorId(id);
    }

    /**
     * Verifica se usuário já respondeu o questionário do mês
     */
    public boolean jaRespondeuMes(Long usuarioId, int mes, int ano) throws SQLException {
        if (usuarioId == null || usuarioId <= 0) {
            throw new IllegalArgumentException("ID de usuário inválido!");
        }
        String mesAno = String.format("%04d-%02d", ano, mes);
        return questionarioDAO.jaRespondeuMes(usuarioId, mesAno);
    }

    /**
     * Lista todos os questionários
     */
    public List<Questionario> listarQuestionarios() throws SQLException {
        return questionarioDAO.listarTodos();
    }

    /**
     * Busca questionários por período
     */
    public List<Questionario> buscarQuestionariosPorPeriodo(int mes, int ano) throws SQLException {
        if (mes < 1 || mes > 12) {
            throw new IllegalArgumentException("Mês inválido!");
        }
        if (ano < 2000 || ano > 2100) {
            throw new IllegalArgumentException("Ano inválido!");
        }
        return questionarioDAO.buscarPorPeriodo(mes, ano);
    }

    /**
     * Atualiza um questionário
     */
    public boolean atualizarQuestionario(Questionario questionario) throws SQLException {
        if (questionario.getId() == null) {
            throw new IllegalArgumentException("ID do questionário é obrigatório!");
        }
        validarRespostas(questionario);
        return questionarioDAO.atualizar(questionario);
    }

    /**
     * Remove um questionário
     */
    public boolean deletarQuestionario(String id) throws SQLException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID inválido!");
        }
        return questionarioDAO.deletar(id);
    }

    /**
     * Valida respostas do questionário (1-5)
     * Permite valores null (respostas opcionais)
     */
    private void validarRespostas(Questionario questionario) throws IllegalArgumentException {
        Integer[] respostas = {
            questionario.getCargaTrabalho(),
            questionario.getReconhecimento(),
            questionario.getRelacionamentoInterpessoal(),
            questionario.getEquilibrioTrabalhoVida(),
            questionario.getComunicacao(),
            questionario.getAutonomia(),
            questionario.getDesenvolvimento(),
            questionario.getAmbienteTrabalho(),
            questionario.getSuporteLideranca(),
            questionario.getSatisfacaoGeral()
        };
        
        // Verificar se pelo menos uma resposta foi fornecida
        boolean temResposta = false;
        for (Integer resposta : respostas) {
            if (resposta != null) {
                temResposta = true;
                if (resposta < 1 || resposta > 5) {
                    throw new IllegalArgumentException("Respostas devem estar entre 1 e 5!");
                }
            }
        }
        
        if (!temResposta) {
            throw new IllegalArgumentException("Pelo menos uma resposta deve ser fornecida!");
        }
    }
}

