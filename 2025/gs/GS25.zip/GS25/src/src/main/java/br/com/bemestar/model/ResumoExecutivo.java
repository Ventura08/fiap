package br.com.bemestar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Classe modelo para ResumoExecutivo
 * Representa um resumo executivo gerado pela IA para gestão
 */
public class ResumoExecutivo {
    private String id;
    private LocalDate periodoInicio;
    private LocalDate periodoFim;
    private LocalDateTime dataGeracao;
    private String top3FocosEstresse; // JSON
    private String solucoesEstruturais; // JSON
    private String metricasAgregadas; // JSON
    private String resumoTexto;
    private StatusResumo status;

    public enum StatusResumo {
        GERADO, EM_REVISAO, APROVADO, IMPLEMENTADO
    }

    // Construtores
    public ResumoExecutivo() {
        this.status = StatusResumo.GERADO;
        this.dataGeracao = LocalDateTime.now();
    }

    public ResumoExecutivo(String id, LocalDate periodoInicio, LocalDate periodoFim) {
        this();
        this.id = id;
        this.periodoInicio = periodoInicio;
        this.periodoFim = periodoFim;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LocalDate getPeriodoInicio() {
        return periodoInicio;
    }

    public void setPeriodoInicio(LocalDate periodoInicio) {
        this.periodoInicio = periodoInicio;
    }

    public LocalDate getPeriodoFim() {
        return periodoFim;
    }

    public void setPeriodoFim(LocalDate periodoFim) {
        this.periodoFim = periodoFim;
    }

    public LocalDateTime getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(LocalDateTime dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public String getTop3FocosEstresse() {
        return top3FocosEstresse;
    }

    public void setTop3FocosEstresse(String top3FocosEstresse) {
        this.top3FocosEstresse = top3FocosEstresse;
    }

    public String getSolucoesEstruturais() {
        return solucoesEstruturais;
    }

    public void setSolucoesEstruturais(String solucoesEstruturais) {
        this.solucoesEstruturais = solucoesEstruturais;
    }

    public String getMetricasAgregadas() {
        return metricasAgregadas;
    }

    public void setMetricasAgregadas(String metricasAgregadas) {
        this.metricasAgregadas = metricasAgregadas;
    }

    public String getResumoTexto() {
        return resumoTexto;
    }

    public void setResumoTexto(String resumoTexto) {
        this.resumoTexto = resumoTexto;
    }

    public StatusResumo getStatus() {
        return status;
    }

    public void setStatus(StatusResumo status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "ResumoExecutivo{" +
                "id='" + id + '\'' +
                ", periodoInicio=" + periodoInicio +
                ", periodoFim=" + periodoFim +
                ", status=" + status +
                '}';
    }
}

