package br.com.bemestar.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Classe modelo para Desabafo
 * Representa um desabafo anonimizado do sistema
 */
public class Desabafo {
    private String id;
    private Long usuarioId;
    private LocalDate dataProcessamento;
    private SentimentoPrincipal sentimentoPrincipal;
    private TopicoRecorrente topicoRecorrente;
    private Integer intensidadeSentimento;
    private String departamento;
    private String faixaEtaria;
    private String sessionHash;
    private LocalDateTime dataCriacao;

    public enum SentimentoPrincipal {
        Estresse, Ansiedade, Frustração, Sobrecarga, Conflito, Outro
    }

    public enum TopicoRecorrente {
        Carga_de_Trabalho, Liderança, Relacionamento_Interpessoal, 
        Equilíbrio_Trabalho_Vida, Reconhecimento, Comunicação, Outro
    }

    // Construtores
    public Desabafo() {
        this.dataProcessamento = LocalDate.now();
    }

    public Desabafo(String id, SentimentoPrincipal sentimento, TopicoRecorrente topico, Integer intensidade) {
        this();
        this.id = id;
        this.sentimentoPrincipal = sentimento;
        this.topicoRecorrente = topico;
        this.intensidadeSentimento = intensidade;
    }

    // Getters e Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public LocalDate getDataProcessamento() {
        return dataProcessamento;
    }

    public void setDataProcessamento(LocalDate dataProcessamento) {
        this.dataProcessamento = dataProcessamento;
    }

    public SentimentoPrincipal getSentimentoPrincipal() {
        return sentimentoPrincipal;
    }

    public void setSentimentoPrincipal(SentimentoPrincipal sentimentoPrincipal) {
        this.sentimentoPrincipal = sentimentoPrincipal;
    }

    public TopicoRecorrente getTopicoRecorrente() {
        return topicoRecorrente;
    }

    public void setTopicoRecorrente(TopicoRecorrente topicoRecorrente) {
        this.topicoRecorrente = topicoRecorrente;
    }

    public Integer getIntensidadeSentimento() {
        return intensidadeSentimento;
    }

    public void setIntensidadeSentimento(Integer intensidadeSentimento) {
        this.intensidadeSentimento = intensidadeSentimento;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getFaixaEtaria() {
        return faixaEtaria;
    }

    public void setFaixaEtaria(String faixaEtaria) {
        this.faixaEtaria = faixaEtaria;
    }

    public String getSessionHash() {
        return sessionHash;
    }

    public void setSessionHash(String sessionHash) {
        this.sessionHash = sessionHash;
    }

    public LocalDateTime getDataCriacao() {
        return dataCriacao;
    }

    public void setDataCriacao(LocalDateTime dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    @Override
    public String toString() {
        return "Desabafo{" +
                "id='" + id + '\'' +
                ", sentimento=" + sentimentoPrincipal +
                ", topico=" + topicoRecorrente +
                ", intensidade=" + intensidadeSentimento +
                ", dataProcessamento=" + dataProcessamento +
                '}';
    }
}

