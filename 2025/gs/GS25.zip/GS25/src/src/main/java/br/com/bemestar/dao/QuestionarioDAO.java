package br.com.bemestar.dao;

import br.com.bemestar.model.Questionario;
import br.com.bemestar.util.ConexaoJDBC;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO (Data Access Object) para Questionario
 * Implementa operações CRUD usando JDBC
 */
public class QuestionarioDAO {
    private ConexaoJDBC conexaoJDBC;

    public QuestionarioDAO() {
        this.conexaoJDBC = ConexaoJDBC.getInstance();
    }

    /**
     * Cria um novo questionário (CREATE)
     */
    public boolean criar(Questionario questionario) throws SQLException {
        String sql = "INSERT INTO questionarios (id, usuario_id, mes_ano, data_resposta, " +
                     "carga_trabalho, reconhecimento, relacionamento_interpessoal, " +
                     "equilibrio_trabalho_vida, comunicacao, autonomia, desenvolvimento, " +
                     "ambiente_trabalho, suporte_lideranca, satisfacao_geral, departamento, " +
                     "faixa_etaria, session_hash, data_criacao) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        Connection conn = null;
        try {
            conn = conexaoJDBC.getConnection();
            // Garantir que auto-commit está habilitado ou fazer commit manual
            boolean originalAutoCommit = conn.getAutoCommit();
            try {
                conn.setAutoCommit(false); // Desabilitar auto-commit para controle manual
                
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, questionario.getId());
                    stmt.setObject(2, questionario.getUsuarioId(), Types.BIGINT);
                    stmt.setString(3, questionario.getMesAno());
                    stmt.setDate(4, Date.valueOf(questionario.getDataResposta()));
                    stmt.setObject(5, questionario.getCargaTrabalho(), Types.INTEGER);
                    stmt.setObject(6, questionario.getReconhecimento(), Types.INTEGER);
                    stmt.setObject(7, questionario.getRelacionamentoInterpessoal(), Types.INTEGER);
                    stmt.setObject(8, questionario.getEquilibrioTrabalhoVida(), Types.INTEGER);
                    stmt.setObject(9, questionario.getComunicacao(), Types.INTEGER);
                    stmt.setObject(10, questionario.getAutonomia(), Types.INTEGER);
                    stmt.setObject(11, questionario.getDesenvolvimento(), Types.INTEGER);
                    stmt.setObject(12, questionario.getAmbienteTrabalho(), Types.INTEGER);
                    stmt.setObject(13, questionario.getSuporteLideranca(), Types.INTEGER);
                    stmt.setObject(14, questionario.getSatisfacaoGeral(), Types.INTEGER);
                    stmt.setString(15, questionario.getDepartamento());
                    stmt.setString(16, questionario.getFaixaEtaria());
                    stmt.setString(17, questionario.getSessionHash());
                    stmt.setTimestamp(18, Timestamp.valueOf(
                        questionario.getDataCriacao() != null ? questionario.getDataCriacao() : java.time.LocalDateTime.now()));
                    
                    int rowsAffected = stmt.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        conn.commit(); // Fazer commit explícito
                        return true;
                    } else {
                        conn.rollback();
                        return false;
                    }
                }
            } catch (SQLException e) {
                if (conn != null) {
                    conn.rollback();
                }
                throw e;
            } finally {
                // Restaurar auto-commit original
                if (conn != null) {
                    conn.setAutoCommit(originalAutoCommit);
                }
            }
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    System.err.println("Erro ao fechar conexão: " + e.getMessage());
                }
            }
        }
    }

    /**
     * Busca um questionário por ID (READ)
     */
    public Questionario buscarPorId(String id) throws SQLException {
        String sql = "SELECT * FROM questionarios WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearResultSetParaQuestionario(rs);
                }
            }
        }
        return null;
    }

    /**
     * Verifica se usuário já respondeu questionário do mês (READ)
     */
    public boolean jaRespondeuMes(Long usuarioId, String mesAno) throws SQLException {
        String sql = "SELECT COUNT(*) FROM questionarios WHERE usuario_id = ? AND mes_ano = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setLong(1, usuarioId);
            stmt.setString(2, mesAno);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }

    /**
     * Lista todos os questionários (READ)
     */
    public List<Questionario> listarTodos() throws SQLException {
        String sql = "SELECT * FROM questionarios ORDER BY data_resposta DESC";
        List<Questionario> questionarios = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                questionarios.add(mapearResultSetParaQuestionario(rs));
            }
        }
        return questionarios;
    }

    /**
     * Busca questionários por período (READ)
     */
    public List<Questionario> buscarPorPeriodo(int mes, int ano) throws SQLException {
        String mesAno = String.format("%04d-%02d", ano, mes);
        String sql = "SELECT * FROM questionarios WHERE mes_ano = ? ORDER BY data_resposta DESC";
        List<Questionario> questionarios = new ArrayList<>();
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, mesAno);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    questionarios.add(mapearResultSetParaQuestionario(rs));
                }
            }
        }
        return questionarios;
    }

    /**
     * Atualiza um questionário (UPDATE)
     */
    public boolean atualizar(Questionario questionario) throws SQLException {
        String sql = "UPDATE questionarios SET carga_trabalho = ?, reconhecimento = ?, " +
                     "relacionamento_interpessoal = ?, equilibrio_trabalho_vida = ?, " +
                     "comunicacao = ?, autonomia = ?, desenvolvimento = ?, ambiente_trabalho = ?, " +
                     "suporte_lideranca = ?, satisfacao_geral = ? WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setObject(1, questionario.getCargaTrabalho(), Types.INTEGER);
            stmt.setObject(2, questionario.getReconhecimento(), Types.INTEGER);
            stmt.setObject(3, questionario.getRelacionamentoInterpessoal(), Types.INTEGER);
            stmt.setObject(4, questionario.getEquilibrioTrabalhoVida(), Types.INTEGER);
            stmt.setObject(5, questionario.getComunicacao(), Types.INTEGER);
            stmt.setObject(6, questionario.getAutonomia(), Types.INTEGER);
            stmt.setObject(7, questionario.getDesenvolvimento(), Types.INTEGER);
            stmt.setObject(8, questionario.getAmbienteTrabalho(), Types.INTEGER);
            stmt.setObject(9, questionario.getSuporteLideranca(), Types.INTEGER);
            stmt.setObject(10, questionario.getSatisfacaoGeral(), Types.INTEGER);
            stmt.setString(11, questionario.getId());
            
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Remove um questionário (DELETE)
     */
    public boolean deletar(String id) throws SQLException {
        String sql = "DELETE FROM questionarios WHERE id = ?";
        
        try (Connection conn = conexaoJDBC.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    /**
     * Mapeia ResultSet para objeto Questionario
     */
    private Questionario mapearResultSetParaQuestionario(ResultSet rs) throws SQLException {
        Questionario questionario = new Questionario();
        questionario.setId(rs.getString("id"));
        
        Long usuarioId = rs.getLong("usuario_id");
        if (!rs.wasNull()) {
            questionario.setUsuarioId(usuarioId);
        }
        
        questionario.setMesAno(rs.getString("mes_ano"));
        questionario.setDataResposta(rs.getDate("data_resposta").toLocalDate());
        questionario.setCargaTrabalho(getIntegerOrNull(rs, "carga_trabalho"));
        questionario.setReconhecimento(getIntegerOrNull(rs, "reconhecimento"));
        questionario.setRelacionamentoInterpessoal(getIntegerOrNull(rs, "relacionamento_interpessoal"));
        questionario.setEquilibrioTrabalhoVida(getIntegerOrNull(rs, "equilibrio_trabalho_vida"));
        questionario.setComunicacao(getIntegerOrNull(rs, "comunicacao"));
        questionario.setAutonomia(getIntegerOrNull(rs, "autonomia"));
        questionario.setDesenvolvimento(getIntegerOrNull(rs, "desenvolvimento"));
        questionario.setAmbienteTrabalho(getIntegerOrNull(rs, "ambiente_trabalho"));
        questionario.setSuporteLideranca(getIntegerOrNull(rs, "suporte_lideranca"));
        questionario.setSatisfacaoGeral(getIntegerOrNull(rs, "satisfacao_geral"));
        questionario.setDepartamento(rs.getString("departamento"));
        questionario.setFaixaEtaria(rs.getString("faixa_etaria"));
        questionario.setSessionHash(rs.getString("session_hash"));
        
        Timestamp dataCriacao = rs.getTimestamp("data_criacao");
        if (dataCriacao != null) {
            questionario.setDataCriacao(dataCriacao.toLocalDateTime());
        }
        
        return questionario;
    }

    /**
     * Helper para obter Integer ou null do ResultSet
     */
    private Integer getIntegerOrNull(ResultSet rs, String columnName) throws SQLException {
        int value = rs.getInt(columnName);
        return rs.wasNull() ? null : value;
    }
}

