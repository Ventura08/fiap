INSERT INTO usuarios (nome, email, senha, telefone, cidade, estado, departamento, faixa_etaria, perfil) VALUES
('João Silva', 'joao@example.com', 'senha123', '(11) 99999-9999', 'São Paulo', 'SP', 'TI', '30-40', 'USUARIO'),
('Maria Santos', 'maria@example.com', 'senha123', '(11) 88888-8888', 'São Paulo', 'SP', 'TI', '25-30', 'USUARIO'),
('Pedro Oliveira', 'pedro@example.com', 'senha123', '(11) 77777-7777', 'Rio de Janeiro', 'RJ', 'RH', '35-45', 'GESTOR'),
('Ana Costa', 'ana@example.com', 'senha123', '(11) 66666-6666', 'Belo Horizonte', 'MG', 'RH', '28-35', 'RH'),
('Carlos Pereira', 'carlos@example.com', 'senha123', '(11) 55555-5555', 'São Paulo', 'SP', 'TI', '40-50', 'USUARIO');