BEGIN
    EXECUTE IMMEDIATE 'CREATE SEQUENCE seq_usuarios START WITH 1 INCREMENT BY 1';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; -- Sequência já existe
        ELSE RAISE;
        END IF;
END;
/

-- Tabela de Usuários
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE usuarios (
    id NUMBER(19) PRIMARY KEY,
    nome VARCHAR2(255) NOT NULL,
    email VARCHAR2(255) UNIQUE NOT NULL,
    senha VARCHAR2(255) NOT NULL,
    telefone VARCHAR2(20),
    cidade VARCHAR2(100),
    estado VARCHAR2(2),
    departamento VARCHAR2(100),
    faixa_etaria VARCHAR2(20),
    perfil VARCHAR2(50) DEFAULT ''USUARIO'' CHECK (perfil IN (''USUARIO'', ''GESTOR'', ''RH'')),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo NUMBER(1) DEFAULT 1 CHECK (ativo IN (0, 1))
)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; -- Tabela já existe
        ELSE RAISE;
        END IF;
END;
/

-- Trigger para auto-incremento do ID
CREATE OR REPLACE TRIGGER trg_usuarios_id
BEFORE INSERT ON usuarios
FOR EACH ROW
BEGIN
    IF :NEW.id IS NULL THEN
        SELECT seq_usuarios.NEXTVAL INTO :NEW.id FROM DUAL;
    END IF;
END;
/

-- Tabela de Desabafos (dados anonimizados)
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE desabafos (
    id VARCHAR2(64) PRIMARY KEY,
    usuario_id NUMBER(19),
    data_processamento DATE NOT NULL,
    sentimento_principal VARCHAR2(50) NOT NULL CHECK (sentimento_principal IN (''Estresse'', ''Ansiedade'', ''Frustração'', ''Sobrecarga'', ''Conflito'', ''Outro'')),
    topico_recorrente VARCHAR2(100) NOT NULL CHECK (topico_recorrente IN (''Carga_de_Trabalho'', ''Liderança'', ''Relacionamento_Interpessoal'', ''Equilíbrio_Trabalho_Vida'', ''Reconhecimento'', ''Comunicação'', ''Outro'')),
    intensidade_sentimento NUMBER(3) NOT NULL CHECK (intensidade_sentimento >= 1 AND intensidade_sentimento <= 10),
    departamento VARCHAR2(100),
    faixa_etaria VARCHAR2(20),
    session_hash VARCHAR2(64) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_desabafos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; -- Tabela já existe
        ELSE RAISE;
        END IF;
END;
/

-- Tabela de Questionários Mensais
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE questionarios (
    id VARCHAR2(64) PRIMARY KEY,
    usuario_id NUMBER(19),
    mes_ano VARCHAR2(7) NOT NULL,
    data_resposta DATE NOT NULL,
    carga_trabalho NUMBER(3) CHECK (carga_trabalho >= 1 AND carga_trabalho <= 5),
    reconhecimento NUMBER(3) CHECK (reconhecimento >= 1 AND reconhecimento <= 5),
    relacionamento_interpessoal NUMBER(3) CHECK (relacionamento_interpessoal >= 1 AND relacionamento_interpessoal <= 5),
    equilibrio_trabalho_vida NUMBER(3) CHECK (equilibrio_trabalho_vida >= 1 AND equilibrio_trabalho_vida <= 5),
    comunicacao NUMBER(3) CHECK (comunicacao >= 1 AND comunicacao <= 5),
    autonomia NUMBER(3) CHECK (autonomia >= 1 AND autonomia <= 5),
    desenvolvimento NUMBER(3) CHECK (desenvolvimento >= 1 AND desenvolvimento <= 5),
    ambiente_trabalho NUMBER(3) CHECK (ambiente_trabalho >= 1 AND ambiente_trabalho <= 5),
    suporte_lideranca NUMBER(3) CHECK (suporte_lideranca >= 1 AND suporte_lideranca <= 5),
    satisfacao_geral NUMBER(3) CHECK (satisfacao_geral >= 1 AND satisfacao_geral <= 5),
    departamento VARCHAR2(100),
    faixa_etaria VARCHAR2(20),
    session_hash VARCHAR2(64) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_questionarios_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL,
    CONSTRAINT unique_questionario_usuario_mes UNIQUE (usuario_id, mes_ano)
)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; -- Tabela já existe
        ELSE RAISE;
        END IF;
END;
/

-- Tabela de Resumos Executivos (gerados pela IA)
BEGIN
    EXECUTE IMMEDIATE 'CREATE TABLE resumos_executivos (
    id VARCHAR2(64) PRIMARY KEY,
    periodo_inicio DATE NOT NULL,
    periodo_fim DATE NOT NULL,
    data_geracao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    top3_focos_estresse CLOB,
    solucoes_estruturais CLOB,
    metricas_agregadas CLOB,
    resumo_texto CLOB,
    status VARCHAR2(50) DEFAULT ''GERADO'' CHECK (status IN (''GERADO'', ''EM_REVISAO'', ''APROVADO'', ''IMPLEMENTADO''))
)';
EXCEPTION
    WHEN OTHERS THEN
        IF SQLCODE = -955 THEN NULL; -- Tabela já existe
        ELSE RAISE;
        END IF;
END;
/

-- Índices para melhor performance
-- Nota: idx_usuarios_email não é necessário pois email já tem UNIQUE (cria índice automaticamente)

BEGIN
    -- Índice para desabafos por data
    BEGIN
        EXECUTE IMMEDIATE 'CREATE INDEX idx_desabafos_data ON desabafos(data_processamento)';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -955 THEN NULL; -- Índice já existe
            ELSE RAISE;
            END IF;
    END;
    
    -- Índice para desabafos por sentimento
    BEGIN
        EXECUTE IMMEDIATE 'CREATE INDEX idx_desabafos_sentimento ON desabafos(sentimento_principal)';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -955 THEN NULL;
            ELSE RAISE;
            END IF;
    END;
    
    -- Índice para questionários por mês/ano
    BEGIN
        EXECUTE IMMEDIATE 'CREATE INDEX idx_questionarios_mes_ano ON questionarios(mes_ano)';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -955 THEN NULL;
            ELSE RAISE;
            END IF;
    END;
    
    -- Índice para questionários por data
    BEGIN
        EXECUTE IMMEDIATE 'CREATE INDEX idx_questionarios_data ON questionarios(data_resposta)';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -955 THEN NULL;
            ELSE RAISE;
            END IF;
    END;
    
    -- Índice para usuários por departamento
    BEGIN
        EXECUTE IMMEDIATE 'CREATE INDEX idx_usuarios_departamento ON usuarios(departamento)';
    EXCEPTION
        WHEN OTHERS THEN
            IF SQLCODE = -955 THEN NULL;
            ELSE RAISE;
            END IF;
    END;
END;
/
