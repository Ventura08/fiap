// Módulo de Sincronização - Sincroniza dados do localStorage com o backend

// Sincronizar desabafos pendentes do localStorage com o backend
async function sincronizarDesabafos() {
    const desabafosPendentes = JSON.parse(localStorage.getItem('desabafosAnonimos') || '[]');
    
    if (desabafosPendentes.length === 0) {
        return { sucesso: true, sincronizados: 0 };
    }
    
    const desabafosSincronizados = [];
    const desabafosErro = [];
    
    for (const desabafo of desabafosPendentes) {
        try {
            // Converter formato do localStorage para formato do backend
            // Converter sentimento e tópico para formato enum do backend (underscores)
            const converterSentimento = (sent) => {
                const map = {
                    'Estresse': 'Estresse',
                    'Ansiedade': 'Ansiedade',
                    'Frustração': 'Frustração',
                    'Frustracao': 'Frustração',
                    'Sobrecarga': 'Sobrecarga',
                    'Conflito': 'Conflito',
                    'Outro': 'Outro'
                };
                return map[sent] || 'Outro';
            };
            
            const converterTopico = (top) => {
                const map = {
                    'Carga de Trabalho': 'Carga_de_Trabalho',
                    'Liderança': 'Liderança',
                    'Lideranca': 'Liderança',
                    'Relacionamento Interpessoal': 'Relacionamento_Interpessoal',
                    'Equilíbrio Trabalho-Vida': 'Equilíbrio_Trabalho_Vida',
                    'Equilibrio Trabalho-Vida': 'Equilíbrio_Trabalho_Vida',
                    'Reconhecimento': 'Reconhecimento',
                    'Comunicação': 'Comunicação',
                    'Comunicacao': 'Comunicação',
                    'Outro': 'Outro'
                };
                return map[top] || 'Outro';
            };
            
            const desabafoBackend = {
                sentimentoPrincipal: converterSentimento(desabafo.sentimentoPrincipal || 'Outro'),
                topicoRecorrente: converterTopico(desabafo.topicoRecorrente || 'Outro'),
                intensidadeSentimento: desabafo.intensidadeSentimento || 5,
                usuarioId: desabafo.usuarioId || null
            };
            
            const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.desabafos}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(desabafoBackend)
            });
            
            if (response.ok) {
                desabafosSincronizados.push(desabafo);
            } else {
                desabafosErro.push(desabafo);
            }
        } catch (error) {
            console.error('Erro ao sincronizar desabafo:', error);
            desabafosErro.push(desabafo);
        }
    }
    
    // Remover desabafos sincronizados do localStorage
    if (desabafosSincronizados.length > 0) {
        const desabafosRestantes = desabafosPendentes.filter(d => 
            !desabafosSincronizados.some(s => s.id === d.id)
        );
        localStorage.setItem('desabafosAnonimos', JSON.stringify(desabafosRestantes));
    }
    
    return {
        sucesso: desabafosErro.length === 0,
        sincronizados: desabafosSincronizados.length,
        erros: desabafosErro.length,
        total: desabafosPendentes.length
    };
}

// Sincronizar questionários pendentes do localStorage com o backend
async function sincronizarQuestionarios() {
    const questionariosPendentes = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');
    
    if (questionariosPendentes.length === 0) {
        return { sucesso: true, sincronizados: 0 };
    }
    
    const questionariosSincronizados = [];
    const questionariosErro = [];
    
    for (const questionario of questionariosPendentes) {
        try {
            // Converter formato do localStorage para formato do backend
            const questionarioBackend = {
                mesAno: questionario.mesAno || questionario.mes_ano,
                respostas: questionario.respostas || {},
                usuarioId: questionario.usuarioId || null,
                dataResposta: questionario.dataResposta || new Date().toISOString().split('T')[0],
                sessionHash: questionario.sessionHash || null,
                departamento: questionario.departamento || null,
                faixaEtaria: questionario.faixaEtaria || null
            };
            
            const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.questionarios}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(questionarioBackend)
            });
            
            if (response.ok) {
                questionariosSincronizados.push(questionario);
            } else {
                questionariosErro.push(questionario);
            }
        } catch (error) {
            console.error('Erro ao sincronizar questionário:', error);
            questionariosErro.push(questionario);
        }
    }
    
    // Remover questionários sincronizados do localStorage
    if (questionariosSincronizados.length > 0) {
        const questionariosRestantes = questionariosPendentes.filter(q => 
            !questionariosSincronizados.some(s => s.id === q.id)
        );
        localStorage.setItem('questionariosAnonimos', JSON.stringify(questionariosRestantes));
    }
    
    return {
        sucesso: questionariosErro.length === 0,
        sincronizados: questionariosSincronizados.length,
        erros: questionariosErro.length,
        total: questionariosPendentes.length
    };
}

// Sincronizar todos os dados pendentes
async function sincronizarTodos() {
    console.log('Iniciando sincronização de dados...');
    
    const resultadoDesabafos = await sincronizarDesabafos();
    const resultadoQuestionarios = await sincronizarQuestionarios();
    
    const resultado = {
        desabafos: resultadoDesabafos,
        questionarios: resultadoQuestionarios,
        totalSincronizados: resultadoDesabafos.sincronizados + resultadoQuestionarios.sincronizados,
        totalErros: resultadoDesabafos.erros + resultadoQuestionarios.erros
    };
    
    console.log('Sincronização concluída:', resultado);
    
    return resultado;
}

// Sincronizar automaticamente quando a página carregar
if (typeof window !== 'undefined') {
    // Aguardar um pouco para garantir que a página carregou
    window.addEventListener('load', () => {
        setTimeout(async () => {
            try {
                await sincronizarTodos();
            } catch (error) {
                console.error('Erro na sincronização automática:', error);
            }
        }, 2000);
    });
}

export { sincronizarDesabafos, sincronizarQuestionarios, sincronizarTodos };

