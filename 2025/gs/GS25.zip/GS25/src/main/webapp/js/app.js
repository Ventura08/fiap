// Configuração da API (será usada quando o backend estiver pronto)
const API_CONFIG = {
    baseURL: 'http://localhost:8080/api', // Ajustar quando backend estiver pronto
    endpoints: {
        usuarios: '/usuarios',
        desabafos: '/desabafos',
        questionarios: '/questionarios'
    },
};

// Tornar API_CONFIG disponível globalmente para módulos ES6
if (typeof window !== 'undefined') {
    window.API_CONFIG = API_CONFIG;
    console.log('[app.js] API_CONFIG disponibilizado globalmente:', API_CONFIG);
}


// Dados Mockados (será substituído quando o backend Java estiver pronto)
const MOCK_DATA = {
    usuarios: [
        {
            id: 1,
            nome: "João Silva",
            email: "joao@example.com",
            senha: "123456",
            telefone: "(11) 99999-9999",
            cidade: "São Paulo",
            estado: "SP"
        }
    ]
};

// Estado da aplicação
let currentUser = null;
let bemEstarRegistros = [];


// Calcular dias consecutivos de bem-estar
function calcularDiasConsecutivosBemEstar(registros) {
    if (registros.length === 0) return 0;
    
    // Ordena por data
    const ordenados = [...registros].sort((a, b) => 
        new Date(b.dataRegistro) - new Date(a.dataRegistro)
    );
    
    let consecutivos = 0;
    let dataEsperada = new Date();
    dataEsperada.setHours(0, 0, 0, 0);
    
    for (const registro of ordenados) {
        const dataRegistro = new Date(registro.dataRegistro + 'T00:00:00');
        const diffDias = Math.floor((dataEsperada - dataRegistro) / (1000 * 60 * 60 * 24));
        
        if (diffDias === 0) {
            consecutivos++;
            dataEsperada.setDate(dataEsperada.getDate() - 1);
        } else if (diffDias > 0) {
            break;
        }
    }
    
    return consecutivos;
}

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    initEventListeners();
    loadInitialData();
    setupRangeInputs();
    loadUserFromStorage();
});

// Carregar usuário do localStorage se existir
function loadUserFromStorage() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        try {
            currentUser = JSON.parse(savedUser);
            
            // Restaurar dados adicionais se existirem
            if (currentUser.perfilNeuroCognitivo) {
                // Perfil neurocognitivo será usado quando necessário
            }
            
            // Atualizar UI
            updateUIForUser();
            
            // Esconder botões de login/cadastro
            const btnLogin = document.getElementById('btnLogin');
            const btnRegister = document.getElementById('btnRegister');
            if (btnLogin) btnLogin.style.display = 'none';
            if (btnRegister) btnRegister.style.display = 'none';
            
            // Mostrar informações do usuário logado
            const userMenu = document.querySelector('.user-menu');
            if (userMenu && currentUser) {
                userMenu.innerHTML = `
                    <span style="margin-right: 1rem;">Olá, ${currentUser.nome}</span>
                    <button class="btn-logout" onclick="logout()">Sair</button>
                `;
            }
        } catch (error) {
            console.error('Erro ao carregar usuário do localStorage:', error);
            localStorage.removeItem('currentUser');
        }
    }
}

// Event Listeners
function initEventListeners() {
    // Modals
    const btnLogin = document.getElementById('btnLogin');
    const btnRegister = document.getElementById('btnRegister');
    
    if (btnLogin) {
        btnLogin.addEventListener('click', () => openModal('loginModal'));
    }
    if (btnRegister) {
        btnRegister.addEventListener('click', () => openModal('registerModal'));
    }
    
    document.querySelectorAll('.close').forEach(close => {
        close.addEventListener('click', (e) => {
            const modal = e.target.closest('.modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });
    
    // Fechar modal ao clicar fora
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });

    // Forms
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const bemestarForm = document.getElementById('bemestarForm');
    const perfilEmocionalForm = document.getElementById('perfilEmocionalForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
    if (bemestarForm) {
        bemestarForm.addEventListener('submit', handleBemEstar);
    }
    if (perfilEmocionalForm) {
        perfilEmocionalForm.addEventListener('submit', handlePerfilEmocional);
    }
    
    // Limitar interesses a 3
    document.querySelectorAll('input[name="interesses"]').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const checked = document.querySelectorAll('input[name="interesses"]:checked');
            if (checked.length > 3) {
                this.checked = false;
                showNotification('Selecione no máximo 3 interesses', 'warning');
            }
        });
    });

    // Filters
    document.querySelectorAll('.filter-btn').forEach(btn => {
        // Filtros removidos - funcionalidade de cursos removida
    });

    // Smooth scroll apenas para links âncora que não são do menu principal
    // Links do menu agora redirecionam para páginas separadas
    document.querySelectorAll('a[href^="#"]:not(.nav-link)').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
}

// Setup Range Inputs
function setupRangeInputs() {
    const estresseInput = document.getElementById('nivelEstresse');
    const satisfacaoInput = document.getElementById('nivelSatisfacao');
    const estresseValue = document.getElementById('estresseValue');
    const satisfacaoValue = document.getElementById('satisfacaoValue');
    
    if (estresseInput && estresseValue) {
        estresseInput.addEventListener('input', (e) => {
            estresseValue.textContent = e.target.value;
        });
    }
    
    if (satisfacaoInput && satisfacaoValue) {
        satisfacaoInput.addEventListener('input', (e) => {
            satisfacaoValue.textContent = e.target.value;
        });
    }
    
    // Adicionar efeito visual aos radio buttons de humor
    document.querySelectorAll('input[name="humor"]').forEach(radio => {
        radio.addEventListener('change', function() {
            // Remove seleção visual de todos
            document.querySelectorAll('input[name="humor"]').forEach(r => {
                const label = r.closest('label');
                if (label) {
                    label.style.borderColor = '#e2e8f0';
                    label.style.transform = 'scale(1)';
                }
            });
            
            // Adiciona seleção visual ao selecionado
            const label = this.closest('label');
            if (label) {
                label.style.borderColor = 'var(--primary-color)';
                label.style.borderWidth = '3px';
                label.style.transform = 'scale(1.05)';
            }
        });
    });
}

// Modal Functions
function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Scroll to Section
function scrollToSection(sectionId) {
    // Função mantida para compatibilidade com links âncora internos
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

function navigateToPage(page) {
    // Função para navegar para páginas
    window.location.href = page;
}

// Load Initial Data
function loadInitialData() {
    loadStats();
}

function loadStats() {
    const totalUsuarios = document.getElementById('totalUsuarios');
    
    if (totalUsuarios) totalUsuarios.textContent = MOCK_DATA.usuarios.length;
}

// Funções de dashboard e organizacional removidas


// User Actions
async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const senha = document.getElementById('loginSenha').value;

    // Validações básicas
    if (!email || !senha) {
        showNotification('Preencha todos os campos', 'error');
        return;
    }

    try {
        // Mostrar loading
        const submitButton = e.target.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Entrando...';

        // Fazer requisição para o backend
        const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.usuarios}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                senha: senha
            })
        });

        // Verificar se a resposta tem conteúdo antes de fazer parse
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            const text = await response.text();
            throw new Error(text || `Erro HTTP ${response.status}: ${response.statusText}`);
        }

        if (!response.ok) {
            // Erro do servidor
            const errorMessage = data.error || 'Email ou senha incorretos';
            showNotification(errorMessage, 'error');
            submitButton.disabled = false;
            submitButton.innerHTML = originalText;
            return;
        }

        // Sucesso!
        const usuarioLogado = data.usuario || data;
        
        // Salvar dados do usuário (sem senha) no localStorage
        const usuarioParaSalvar = {
            id: usuarioLogado.id,
            nome: usuarioLogado.nome,
            email: usuarioLogado.email,
            telefone: usuarioLogado.telefone,
            cidade: usuarioLogado.cidade,
            estado: usuarioLogado.estado,
            departamento: usuarioLogado.departamento,
            perfil: usuarioLogado.perfil,
            faixaEtaria: usuarioLogado.faixaEtaria
        };
        
        currentUser = usuarioParaSalvar;
        localStorage.setItem('currentUser', JSON.stringify(usuarioParaSalvar));
        
        // Restaurar perfil neurocognitivo se existir no localStorage
        const savedUser = localStorage.getItem('currentUser');
        if (savedUser) {
            const parsed = JSON.parse(savedUser);
            if (parsed.perfilNeuroCognitivo) {
                perfilNeuroCognitivo = parsed.perfilNeuroCognitivo;
                currentUser.perfilNeuroCognitivo = parsed.perfilNeuroCognitivo;
            }
            if (parsed.insigneas) {
                currentUser.insigneas = parsed.insigneas;
            }
            if (parsed.ajudas) {
                currentUser.ajudas = parsed.ajudas;
            }
        }
        
        // Limpar formulário
        e.target.reset();
        closeModal('loginModal');
        
        showNotification('Login realizado com sucesso!', 'success');
        
        // Atualizar interface do usuário (esconder botões de login/cadastro)
        const btnLogin = document.getElementById('btnLogin');
        const btnRegister = document.getElementById('btnRegister');
        if (btnLogin) btnLogin.style.display = 'none';
        if (btnRegister) btnRegister.style.display = 'none';
        
        // Mostrar informações do usuário logado
        const userMenu = document.querySelector('.user-menu');
        if (userMenu && usuarioLogado) {
            userMenu.innerHTML = `
                <span style="margin-right: 1rem;">Olá, ${usuarioLogado.nome}</span>
                <button class="btn-logout" onclick="logout()">Sair</button>
            `;
        }
        
        // Atualizar UI
        updateUIForUser();
        
    } catch (error) {
        console.error('Erro ao fazer login:', error);
        
        // Restaurar botão
        const submitButton = e.target.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = 'Entrar';
        }
        
        // Mostrar erro apropriado
        if (error.message && error.message.includes('fetch')) {
            showNotification('Erro ao conectar com o servidor. Verifique se o backend está rodando na porta 8080.', 'error');
        } else {
            showNotification('Erro ao fazer login: ' + (error.message || 'Erro desconhecido'), 'error');
        }
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    // Coletar dados do formulário
    const nome = document.getElementById('registerNome').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const senha = document.getElementById('registerSenha').value;
    const telefone = document.getElementById('registerTelefone').value.trim();
    const cidade = document.getElementById('registerCidade').value.trim();
    const estado = document.getElementById('registerEstado').value.trim().toUpperCase();
    const departamento = document.getElementById('registerArea').value;
    const faixaEtaria = document.getElementById('registerFaixaEtaria')?.value || null;
    
    // Validações básicas
    if (!nome || !email || !senha) {
        showNotification('Preencha todos os campos obrigatórios', 'error');
        return;
    }
    
    if (senha.length < 6) {
        showNotification('A senha deve ter no mínimo 6 caracteres', 'error');
        return;
    }
    
    // Coletar interesses selecionados (para uso futuro, não salva no banco ainda)
    const interessesSelecionados = Array.from(document.querySelectorAll('input[name="interesses"]:checked'))
        .map(cb => cb.value);
    
    // Validar área de atuação (campo obrigatório no HTML)
    if (!departamento) {
        showNotification('Selecione uma área de atuação', 'error');
        return;
    }
    
    // Preparar dados para o backend (remover campos vazios)
    const dadosUsuario = {
        nome: nome,
        email: email,
        senha: senha,
        perfil: 'USUARIO' // Padrão
    };
    
    // Adicionar campos opcionais apenas se preenchidos
    if (telefone) dadosUsuario.telefone = telefone;
    if (cidade) dadosUsuario.cidade = cidade;
    if (estado) dadosUsuario.estado = estado;
    if (departamento) dadosUsuario.departamento = departamento;
    if (faixaEtaria) dadosUsuario.faixaEtaria = faixaEtaria;
    
    try {
        // Mostrar loading
        const submitButton = e.target.querySelector('button[type="submit"]');
        const originalText = submitButton.innerHTML;
        submitButton.disabled = true;
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Cadastrando...';
        
        // Fazer requisição para o backend
        const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.usuarios}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dadosUsuario)
        });
        
        // Verificar se a resposta tem conteúdo antes de fazer parse
        let data;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            const text = await response.text();
            throw new Error(text || `Erro HTTP ${response.status}: ${response.statusText}`);
        }
        
        if (!response.ok) {
            // Erro do servidor
            const errorMessage = data.error || 'Erro ao cadastrar usuário';
            showNotification(errorMessage, 'error');
            submitButton.disabled = false;
            submitButton.innerHTML = originalText;
            return;
        }
        
        // Sucesso!
        const usuarioCriado = data;
        
        // Salvar dados do usuário (sem senha) no localStorage
        const usuarioParaSalvar = {
            id: usuarioCriado.id,
            nome: usuarioCriado.nome,
            email: usuarioCriado.email,
            telefone: usuarioCriado.telefone,
            cidade: usuarioCriado.cidade,
            estado: usuarioCriado.estado,
            departamento: usuarioCriado.departamento,
            perfil: usuarioCriado.perfil,
            interesses: interessesSelecionados, // Salvar localmente
            metas: document.getElementById('registerMetas').value // Salvar localmente
        };
        
        currentUser = usuarioParaSalvar;
        localStorage.setItem('currentUser', JSON.stringify(usuarioParaSalvar));
        
        // Limpar formulário
        e.target.reset();
        closeModal('registerModal');
        
        showNotification('Cadastro realizado com sucesso!', 'success');
        
        // Atualizar interface do usuário (esconder botões de login/cadastro)
        const btnLogin = document.getElementById('btnLogin');
        const btnRegister = document.getElementById('btnRegister');
        if (btnLogin) btnLogin.style.display = 'none';
        if (btnRegister) btnRegister.style.display = 'none';
        
        // Mostrar informações do usuário logado (se houver elemento para isso)
        const userMenu = document.querySelector('.user-menu');
        if (userMenu && usuarioCriado) {
            userMenu.innerHTML = `
                <span style="margin-right: 1rem;">Olá, ${usuarioCriado.nome}</span>
                <button class="btn-logout" onclick="logout()">Sair</button>
            `;
        }
        
        // Abrir questionário de perfil emocional após cadastro (opcional)
        setTimeout(() => {
            const abrirPerfil = confirm('Deseja responder o questionário de perfil emocional agora?');
            if (abrirPerfil) {
                openModal('perfilEmocionalModal');
            }
        }, 500);
        
        // Atualizar estatísticas
        if (typeof loadStats === 'function') {
            loadStats();
        }
        
    } catch (error) {
        console.error('Erro ao cadastrar:', error);
        
        // Restaurar botão
        const submitButton = e.target.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = 'Cadastrar';
        }
        
        // Mostrar erro apropriado
        if (error.message && error.message.includes('fetch')) {
            showNotification('Erro ao conectar com o servidor. Verifique se o backend está rodando na porta 8080.', 'error');
        } else {
            showNotification('Erro ao cadastrar: ' + (error.message || 'Erro desconhecido'), 'error');
        }
    }
}

// Processar Questionário de Perfil Emocional
async function handlePerfilEmocional(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Erro: usuário não encontrado', 'error');
        return;
    }
    
    const formData = new FormData(e.target);
    const respostas = {
        motivacao: parseInt(formData.get('motivacao')),
        trabalhoEquipe: parseInt(formData.get('trabalhoEquipe')),
        racionalCriativo: parseInt(formData.get('racionalCriativo')),
        equilibrioEmocional: parseInt(formData.get('equilibrioEmocional')),
        introvertidoExtrovertido: parseInt(formData.get('introvertidoExtrovertido'))
    };
    
    // Gerar perfil neurocognitivo usando IA
    perfilNeuroCognitivo = gerarPerfilNeuroCognitivo(currentUser, respostas);
    
    // Salvar perfil no usuário localmente
    currentUser.perfilNeuroCognitivo = perfilNeuroCognitivo;
    
    // Salvar no localStorage
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Salvar no backend
    try {
        const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.usuarios}/${currentUser.id}/perfil-neurocognitivo`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                perfilNeuroCognitivo: perfilNeuroCognitivo,
                respostas: respostas
            })
        });
        
        if (!response.ok) {
            console.warn('Aviso: Não foi possível salvar o perfil no backend, mas foi salvo localmente.');
        }
    } catch (error) {
        console.error('Erro ao salvar perfil no backend:', error);
        // Continua mesmo se falhar, pois já salvou localmente
    }
    
    closeModal('perfilEmocionalModal');
    showNotification('Perfil NeuroCognitivo gerado com sucesso! 🧠', 'success');
    
    // Atualizar UI
    updateUIForUser();
    
}

// IA para Gerar Perfil NeuroCognitivo
function gerarPerfilNeuroCognitivo(usuario, respostas) {
    // Eixo 1: Racional x Criativo
    // Valor 1-9: 1-4 = Racional, 5 = Equilibrado, 6-9 = Criativo
    const racionalCriativo = respostas.racionalCriativo;
    // Normaliza para 0-100%: 1=100% racional, 5=50/50, 9=100% criativo
    const percentualCriativo = ((racionalCriativo - 1) / 8) * 100;
    const percentualRacional = 100 - percentualCriativo;
    const eixoRacionalCriativo = {
        racional: Math.round(percentualRacional),
        criativo: Math.round(percentualCriativo),
        valor: racionalCriativo
    };
    
    // Eixo 2: Introvertido x Colaborativo
    // Combina introvertido/extrovertido com trabalho em equipe
    const introvertidoExtrovertido = respostas.introvertidoExtrovertido;
    const trabalhoEquipe = respostas.trabalhoEquipe;
    // Média ponderada: 60% personalidade, 40% preferência de trabalho
    const mediaColaboracao = (introvertidoExtrovertido * 0.6 + trabalhoEquipe * 0.4);
    // Normaliza para 0-100%: 1=100% introvertido, 5=50/50, 9=100% colaborativo
    const percentualColaborativo = ((mediaColaboracao - 1) / 8) * 100;
    const percentualIntrovertido = 100 - percentualColaborativo;
    const eixoIntrovertidoColaborativo = {
        introvertido: Math.round(percentualIntrovertido),
        colaborativo: Math.round(percentualColaborativo),
        valor: mediaColaboracao
    };
    
    // Eixo 3: Equilíbrio Emocional
    // Combina equilíbrio emocional com motivação
    const equilibrioEmocional = respostas.equilibrioEmocional;
    const motivacao = respostas.motivacao;
    const mediaEmocional = (equilibrioEmocional + motivacao) / 2;
    const eixoEquilibrioEmocional = {
        nivel: mediaEmocional,
        classificacao: mediaEmocional >= 7 ? 'Alto' : mediaEmocional >= 4 ? 'Moderado' : 'Baixo',
        valor: mediaEmocional
    };
    
    // Análise de perfil baseado em área e interesses
    let estiloAprendizado = 'Equilibrado';
    if (usuario.area === 'Tecnologia' && eixoRacionalCriativo.racional > 60) {
        estiloAprendizado = 'Analítico';
    } else if (eixoRacionalCriativo.criativo > 60) {
        estiloAprendizado = 'Criativo';
    } else if (eixoIntrovertidoColaborativo.colaborativo > 60) {
        estiloAprendizado = 'Colaborativo';
    } else if (eixoIntrovertidoColaborativo.introvertido > 60) {
        estiloAprendizado = 'Individual';
    }
    
    // Recomendações baseadas no perfil
    const recomendacoes = [];
    if (eixoEquilibrioEmocional.nivel < 5) {
        recomendacoes.push('Considere cursos de gestão de estresse e bem-estar');
    }
    if (eixoIntrovertidoColaborativo.introvertido > 70) {
        recomendacoes.push('Cursos de comunicação e trabalho em equipe podem ajudar');
    }
    if (usuario.metas && usuario.metas.toLowerCase().includes('transição')) {
        recomendacoes.push('Foque em cursos práticos e aplicáveis');
    }
    if (eixoRacionalCriativo.racional > 70 && usuario.area !== 'Tecnologia') {
        recomendacoes.push('Você tem perfil analítico - considere cursos de tecnologia e dados');
    }
    
    return {
        eixoRacionalCriativo,
        eixoIntrovertidoColaborativo,
        eixoEquilibrioEmocional,
        estiloAprendizado,
        recomendacoes,
        dataCriacao: new Date().toISOString()
    };
}


function handleBemEstar(e) {
    e.preventDefault();
    
    if (!currentUser) {
        showNotification('Por favor, faça login primeiro', 'warning');
        openModal('loginModal');
        return;
    }

    const hoje = new Date().toISOString().split('T')[0];
    
    // Verifica se já registrou hoje
    const jaRegistrouHoje = bemEstarRegistros.find(b => 
        b.usuarioId === currentUser.id && b.dataRegistro === hoje
    );
    
    if (jaRegistrouHoje) {
        showNotification('Você já registrou seu bem-estar hoje. Volte amanhã!', 'info');
        return;
    }

    // Captura humor do formulário
    const humorInput = document.querySelector('input[name="humor"]:checked');
    const humor = humorInput ? parseInt(humorInput.value) : 3;

    const bemEstar = {
        id: bemEstarRegistros.length + 1,
        usuarioId: currentUser.id,
        humor: humor,
        nivelEstresse: parseInt(document.getElementById('nivelEstresse').value),
        nivelSatisfacao: parseInt(document.getElementById('nivelSatisfacao').value),
        horasTrabalho: parseInt(document.getElementById('horasTrabalho').value),
        horasDescanso: parseInt(document.getElementById('horasDescanso').value),
        observacoes: document.getElementById('observacoes').value,
        dataRegistro: hoje
    };

    bemEstarRegistros.push(bemEstar);
    
    // Sistema de alertas baseado em padrões
    verificarAlertasBemEstar(bemEstar);
    
    showNotification('Bem-estar registrado com sucesso!', 'success');
    document.getElementById('bemestarForm').reset();
    document.getElementById('estresseValue').textContent = '5';
    document.getElementById('satisfacaoValue').textContent = '5';
    
    // Resetar seleção de humor
    document.querySelectorAll('input[name="humor"]').forEach(radio => {
        radio.checked = false;
    });
    
    loadBemEstarHistory();
    loadRecomendacoesBemEstar();
}

// Sistema de Alertas de Bem-Estar
function verificarAlertasBemEstar(novoRegistro) {
    const userBemEstar = bemEstarRegistros.filter(b => b.usuarioId === currentUser.id);
    
    // Alerta: Estresse alto
    if (novoRegistro.nivelEstresse >= 8) {
        showNotification('⚠️ Seu nível de estresse está alto. Considere fazer uma pausa ou praticar técnicas de relaxamento.', 'warning');
    }
    
    // Alerta: Desequilíbrio trabalho/descanso
    if (novoRegistro.horasTrabalho > 10 || novoRegistro.horasDescanso < 6) {
        showNotification('💤 Atenção: Seu equilíbrio trabalho/descanso pode estar afetando seu bem-estar.', 'warning');
    }
    
    // Alerta: Tendência de estresse crescente
    if (userBemEstar.length >= 3) {
        const ultimos3 = userBemEstar.slice(-3);
        const estresseCrescente = ultimos3.every((b, i) => 
            i === 0 || b.nivelEstresse >= ultimos3[i - 1].nivelEstresse
        );
        
        if (estresseCrescente && novoRegistro.nivelEstresse >= 7) {
            showNotification('📈 Detectamos uma tendência de aumento no estresse. Que tal explorar nossos cursos de gestão de estresse?', 'warning');
        }
    }
}

function loadBemEstarHistory() {
    if (!currentUser) return;

    const userBemEstar = bemEstarRegistros.filter(b => b.usuarioId === currentUser.id);
    renderBemEstarChart(userBemEstar);
}

// Recursos de Mindfulness
const recursosMindfulness = {
    pausas: [
        {
            id: 1,
            titulo: "Pausa de 5 minutos - Respiração Consciente",
            descricao: "Técnica simples de respiração para reduzir estresse e ansiedade",
            duracao: "5 min",
            tipo: "respiração",
            url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        },
        {
            id: 2,
            titulo: "Alongamento Rápido para Trabalho",
            descricao: "Exercícios de alongamento para fazer no escritório ou home office",
            duracao: "3 min",
            tipo: "exercício",
            url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        },
        {
            id: 3,
            titulo: "Meditação Guiada - Foco e Concentração",
            descricao: "Meditação curta para melhorar foco e produtividade",
            duracao: "10 min",
            tipo: "meditação",
            url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        }
    ],
    videos: [
        {
            id: 1,
            titulo: "Mindfulness para Iniciantes",
            descricao: "Aprenda os fundamentos da prática de mindfulness",
            duracao: "15 min",
            categoria: "mindfulness"
        },
        {
            id: 2,
            titulo: "Gestão de Estresse no Trabalho",
            descricao: "Estratégias práticas para lidar com estresse profissional",
            duracao: "20 min",
            categoria: "gestão de estresse"
        },
        {
            id: 3,
            titulo: "Yoga para Trabalhadores Remotos",
            descricao: "Sessão de yoga adaptada para quem trabalha em casa",
            duracao: "25 min",
            categoria: "yoga"
        }
    ]
};

// Gerar Recomendações Automáticas de Bem-Estar
function gerarRecomendacoesBemEstar(usuario) {
    if (!usuario) return [];
    
    const userBemEstar = bemEstarRegistros.filter(b => b.usuarioId === usuario.id);
    if (userBemEstar.length === 0) return [];
    
    const ultimoRegistro = userBemEstar[userBemEstar.length - 1];
    const recomendacoes = [];
    
    // Recomendação baseada em humor
    if (ultimoRegistro.humor <= 2) {
        recomendacoes.push({
            tipo: 'pausa',
            titulo: '💚 Recomendamos uma pausa',
            descricao: 'Seu humor está baixo hoje. Que tal fazer uma pausa para respirar?',
            recurso: recursosMindfulness.pausas[0],
            prioridade: 'alta'
        });
    }
    
    // Recomendação baseada em estresse
    if (ultimoRegistro.nivelEstresse >= 8) {
        recomendacoes.push({
            tipo: 'meditação',
            titulo: '🧘 Meditação para Reduzir Estresse',
            descricao: 'Seu nível de estresse está alto. Pratique esta meditação guiada.',
            recurso: recursosMindfulness.pausas[2],
            prioridade: 'alta'
        });
    }
    
    // Recomendação baseada em horas de trabalho
    if (ultimoRegistro.horasTrabalho > 10) {
        recomendacoes.push({
            tipo: 'pausa',
            titulo: '⏸️ Hora de uma Pausa',
            descricao: 'Você trabalhou muitas horas hoje. Faça uma pausa para alongar.',
            recurso: recursosMindfulness.pausas[1],
            prioridade: 'média'
        });
    }
    
    // Recomendação baseada em tendência de humor
    if (userBemEstar.length >= 3) {
        const ultimos3 = userBemEstar.slice(-3);
        const mediaHumor = ultimos3.reduce((sum, r) => sum + (r.humor || 3), 0) / 3;
        
        if (mediaHumor < 3) {
            recomendacoes.push({
                tipo: 'video',
                titulo: '📹 Vídeo: Mindfulness para Melhorar o Humor',
                descricao: 'Detectamos uma tendência de humor baixo. Este vídeo pode ajudar.',
                recurso: recursosMindfulness.videos[0],
                prioridade: 'alta'
            });
        }
    }
    
    // Recomendação baseada em desequilíbrio trabalho/descanso
    if (ultimoRegistro.horasDescanso < 6) {
        recomendacoes.push({
            tipo: 'video',
            titulo: '😴 Importante: Melhore seu Descanso',
            descricao: 'Você está descansando pouco. Veja técnicas para melhorar o sono.',
            recurso: recursosMindfulness.videos[1],
            prioridade: 'média'
        });
    }
    
    return recomendacoes.slice(0, 3); // Retorna até 3 recomendações
}

// Renderizar Gráficos de Bem-Estar
function renderBemEstarChart(registros) {
    const container = document.getElementById('bemestarChart');
    if (!container) return;
    
    if (!registros || registros.length === 0) {
        container.innerHTML = '<p>Nenhum registro de bem-estar ainda. Registre seu primeiro dia!</p>';
        return;
    }

    const recentes = registros.slice(-14).reverse(); // Últimos 14 dias
    const datas = recentes.map(r => {
        const d = new Date(r.dataRegistro + 'T00:00:00');
        return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    });
    
    // Dados para gráficos
    const humores = recentes.map(r => (r.humor || 3) * 20); // Normaliza para 0-100
    const estresses = recentes.map(r => (r.nivelEstresse || 5) * 10); // Normaliza para 0-100
    const satisfacoes = recentes.map(r => (r.nivelSatisfacao || 5) * 10); // Normaliza para 0-100
    const produtividades = recentes.map(r => {
        // Produtividade = satisfação - estresse (normalizado)
        const prod = ((r.nivelSatisfacao || 5) - (r.nivelEstresse || 5) + 10) * 5;
        return Math.max(0, Math.min(100, prod));
    });

    container.innerHTML = `
        <!-- Gráfico de Humor -->
        <div class="chart-container">
            <div class="chart-title">
                <i class="fas fa-smile"></i> Humor ao Longo do Tempo
            </div>
            <canvas id="chartHumor" class="chart-canvas"></canvas>
            <div class="chart-legend">
                <div class="chart-legend-item">
                    <div class="chart-legend-color" style="background: #10b981;"></div>
                    <span>Humor (1-5)</span>
                </div>
            </div>
        </div>

        <!-- Gráfico de Produtividade -->
        <div class="chart-container">
            <div class="chart-title">
                <i class="fas fa-chart-line"></i> Produtividade e Bem-Estar
            </div>
            <canvas id="chartProdutividade" class="chart-canvas"></canvas>
            <div class="chart-legend">
                <div class="chart-legend-item">
                    <div class="chart-legend-color" style="background: #6366f1;"></div>
                    <span>Satisfação</span>
                </div>
                <div class="chart-legend-item">
                    <div class="chart-legend-color" style="background: #ef4444;"></div>
                    <span>Estresse</span>
                </div>
                <div class="chart-legend-item">
                    <div class="chart-legend-color" style="background: #10b981;"></div>
                    <span>Produtividade</span>
                </div>
            </div>
        </div>

        <!-- Histórico Recente -->
        <div style="margin-top: 2rem;">
            <h4 style="margin-bottom: 1rem; color: #1e293b; font-size: 1rem;">
                <i class="fas fa-history"></i> Histórico Recente
            </h4>
            ${recentes.slice(0, 7).map(r => {
                const data = new Date(r.dataRegistro + 'T00:00:00');
                const emojiHumor = ['😢', '😕', '😐', '🙂', '😄'][(r.humor || 3) - 1];
                return `
                    <div style="padding: 1rem; background: #f8fafc; border-radius: 8px; margin-bottom: 0.75rem; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <p style="margin: 0; font-weight: 600; color: #1e293b;">
                                ${data.toLocaleDateString('pt-BR')} ${emojiHumor}
                            </p>
                            <p style="margin: 0.25rem 0 0 0; font-size: 0.875rem; color: #666;">
                                Estresse: ${r.nivelEstresse}/10 | Satisfação: ${r.nivelSatisfacao}/10 | 
                                Trabalho: ${r.horasTrabalho}h | Descanso: ${r.horasDescanso}h
                            </p>
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
    `;

    // Renderizar gráficos usando Canvas
    renderChart('chartHumor', datas, [humores], ['#10b981'], 'Humor');
    renderChart('chartProdutividade', datas, [satisfacoes, estresses, produtividades], ['#6366f1', '#ef4444', '#10b981'], 'Produtividade');
}

// Função para renderizar gráficos simples
function renderChart(canvasId, labels, datasets, colors, title) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = 200;
    
    // Limpar canvas
    ctx.clearRect(0, 0, width, height);
    
    // Configurações
    const padding = 40;
    const chartWidth = width - padding * 2;
    const chartHeight = height - padding * 2;
    const maxValue = 100;
    const stepX = chartWidth / (labels.length - 1);
    
    // Desenhar linhas de grade
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
        const y = padding + (chartHeight / 4) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
        ctx.stroke();
    }
    
    // Desenhar datasets
    datasets.forEach((data, index) => {
        ctx.strokeStyle = colors[index];
        ctx.lineWidth = 2;
        ctx.fillStyle = colors[index];
        ctx.beginPath();
        
        data.forEach((value, i) => {
            const x = padding + stepX * i;
            const y = padding + chartHeight - (value / maxValue) * chartHeight;
            
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
            
            // Desenhar ponto
            ctx.beginPath();
            ctx.arc(x, y, 4, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
        });
        
        ctx.stroke();
    });
    
    // Desenhar labels no eixo X
    ctx.fillStyle = '#666';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    labels.forEach((label, i) => {
        if (i % Math.ceil(labels.length / 5) === 0 || i === labels.length - 1) {
            const x = padding + stepX * i;
            ctx.fillText(label, x, height - 10);
        }
    });
}

// Carregar Recomendações de Bem-Estar
function loadRecomendacoesBemEstar() {
    const container = document.getElementById('recomendacoesBemEstar');
    if (!container) return;
    
    if (!currentUser) {
        container.innerHTML = '<p>Faça login para ver recomendações personalizadas.</p>';
        return;
    }
    
    const recomendacoes = gerarRecomendacoesBemEstar(currentUser);
    
    if (recomendacoes.length === 0) {
        container.innerHTML = `
            <div class="recomendacao-card">
                <h4><i class="fas fa-check-circle" style="color: #10b981;"></i> Você está bem!</h4>
                <p>Seus indicadores de bem-estar estão equilibrados. Continue mantendo esse cuidado consigo mesmo!</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = `
        <h4 style="margin-bottom: 1rem; color: #1e293b; font-size: 1rem;">
            <i class="fas fa-lightbulb"></i> Recomendações Personalizadas
        </h4>
        ${recomendacoes.map(rec => `
            <div class="recomendacao-card" style="border-left-color: ${rec.prioridade === 'alta' ? '#ef4444' : '#f59e0b'};">
                <h4>${rec.titulo}</h4>
                <p>${rec.descricao}</p>
                <div style="margin-top: 0.75rem; padding: 0.75rem; background: white; border-radius: 6px;">
                    <p style="margin: 0 0 0.5rem 0; font-weight: 600; color: #1e293b; font-size: 0.875rem;">
                        ${rec.recurso.titulo}
                    </p>
                    <p style="margin: 0 0 0.75rem 0; font-size: 0.8125rem; color: #666;">
                        ${rec.recurso.descricao}
                    </p>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.75rem; color: #666;">
                            <i class="fas fa-clock"></i> ${rec.recurso.duracao}
                        </span>
                        <a href="${rec.recurso.url || '#'}" target="_blank" class="recomendacao-link">
                            <i class="fas fa-play"></i> ${rec.tipo === 'video' ? 'Assistir' : 'Iniciar'}
                        </a>
                    </div>
                </div>
            </div>
        `).join('')}
    `;
}

function updateUIForUser() {
    if (currentUser) {
        const userMenu = document.querySelector('.user-menu');
        if (userMenu) {
            userMenu.innerHTML = `
                <span style="color: white; margin-right: 1rem;">Olá, ${currentUser.nome}</span>
                <button class="btn-login" onclick="logout()">Sair</button>
            `;
        }
        loadBemEstarHistory();
        loadRecomendacoesBemEstar();
    }
}

// Funções removidas - não utilizadas no projeto

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    location.reload();
}

// Notification System
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : '#6366f1'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
        z-index: 3000;
        animation: slideInRight 0.3s;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
