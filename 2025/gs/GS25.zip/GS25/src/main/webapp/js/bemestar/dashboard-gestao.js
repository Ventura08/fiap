// Dashboard de Gestão - Visualização de Soluções Estruturais

import { gerarResumoExecutivo } from './analytics.js';

// Carregar dashboard de gestão
async function carregarDashboardGestao(mes = null, ano = null) {
    try {
        const hoje = new Date();
        const mesAtual = mes || hoje.getMonth() + 1;
        const anoAtual = ano || hoje.getFullYear();

        console.log(`Carregando dashboard para ${mesAtual}/${anoAtual} do banco de dados...`);

        // Gerar resumo executivo (busca dados do banco via analytics.js)
        const resumo = await gerarResumoExecutivo(mesAtual, anoAtual);
        
        console.log('Dados carregados do banco:', {
            desabafos: resumo.metricasAgregadas.totalDesabafos,
            questionarios: resumo.metricasAgregadas.totalQuestionarios,
            focos: resumo.top3FocosEstresse.length
        });

        // Renderizar dashboard
        renderizarDashboard(resumo, mesAtual, anoAtual);

    } catch (error) {
        console.error('Erro em carregarDashboardGestao:', error);
        
        // Mostrar erro no dashboard
        const container = document.getElementById('dashboardGestao');
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; padding: 3rem; background: white; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 4rem; color: #ef4444; margin-bottom: 1rem;"></i>
                    <h2 style="color: #1e293b; margin-bottom: 1rem;">Erro ao Carregar Dados</h2>
                    <p style="color: #666; margin-bottom: 1.5rem;">
                        Não foi possível carregar os dados do banco de dados.<br>
                        <strong>Erro:</strong> ${error.message}
                    </p>
                    <p style="color: #666; font-size: 0.875rem; margin-bottom: 1.5rem;">
                        Verifique se:<br>
                        • O servidor backend está rodando na porta 8080<br>
                        • O banco de dados está configurado corretamente<br>
                        • A conexão com o banco está funcionando
                    </p>
                    <button onclick="location.reload()" class="btn-primary" style="margin-top: 1rem;">
                        <i class="fas fa-sync-alt"></i> Tentar Novamente
                    </button>
                </div>
            `;
        }
        
        throw error;
    }
}

// Renderizar dashboard completo
function renderizarDashboard(resumo, mes, ano) {
    const container = document.getElementById('dashboardGestao');
    if (!container) {
        console.error('Container dashboardGestao não encontrado!');
        return;
    }

    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                   'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

    container.innerHTML = `
        <div class="dashboard-gestao-header">
            <h2><i class="fas fa-chart-line"></i> Dashboard de Bem-Estar - Gestão/RH</h2>
            <div style="display: flex; gap: 1rem; align-items: center;">
                <label style="font-weight: 600; color: #1e293b;">Período:</label>
                <select id="seletorMes" style="padding: 0.5rem 1rem; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 1rem;">
                    ${Array.from({length: 12}, (_, i) => {
                        const mesNum = i + 1;
                        return `<option value="${mesNum}" ${mesNum === mes ? 'selected' : ''}>${meses[i]} ${ano}</option>`;
                    }).join('')}
                </select>
                <select id="seletorAno" style="padding: 0.5rem 1rem; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 1rem;">
                    ${Array.from({length: 3}, (_, i) => {
                        const anoNum = ano - 1 + i;
                        return `<option value="${anoNum}" ${anoNum === ano ? 'selected' : ''}>${anoNum}</option>`;
                    }).join('')}
                </select>
            </div>
        </div>

        <!-- Métricas Principais -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
            <div style="padding: 1.5rem; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="font-size: 0.875rem; color: #666; margin: 0;">Participação</h3>
                    <i class="fas fa-users" style="color: #6366f1; font-size: 1.5rem;"></i>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: #1e293b; margin: 0;">
                    ${(resumo.metricasAgregadas.taxaParticipacao * 100).toFixed(0)}%
                </p>
                <p style="font-size: 0.875rem; color: #666; margin: 0.25rem 0 0 0;">
                    ${resumo.metricasAgregadas.totalDesabafos} desabafos • ${resumo.metricasAgregadas.totalQuestionarios} questionários
                </p>
            </div>

            <div style="padding: 1.5rem; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="font-size: 0.875rem; color: #666; margin: 0;">Satisfação Média</h3>
                    <i class="fas fa-smile" style="color: #10b981; font-size: 1.5rem;"></i>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: #1e293b; margin: 0;">
                    ${resumo.metricasAgregadas.satisfacaoMedia.toFixed(1)}/5
                </p>
                <p style="font-size: 0.875rem; color: #666; margin: 0.25rem 0 0 0;">
                    Questionário mensal
                </p>
            </div>

            <div style="padding: 1.5rem; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.5rem;">
                    <h3 style="font-size: 0.875rem; color: #666; margin: 0;">Estresse Médio</h3>
                    <i class="fas fa-exclamation-triangle" style="color: #ef4444; font-size: 1.5rem;"></i>
                </div>
                <p style="font-size: 2rem; font-weight: 700; color: #1e293b; margin: 0;">
                    ${resumo.metricasAgregadas.sentimentoMedio.toFixed(1)}/10
                </p>
                <p style="font-size: 0.875rem; color: #666; margin: 0.25rem 0 0 0;">
                    Intensidade média
                </p>
            </div>
        </div>

        <!-- Soluções Estruturais -->
        <div style="margin-bottom: 2rem;">
            <h3 style="font-size: 1.5rem; color: #1e293b; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-lightbulb" style="color: var(--primary-color);"></i>
                Soluções Estruturais Recomendadas
            </h3>
            
            ${resumo.solucoesEstruturais.length === 0 ? `
                <div style="padding: 2rem; background: white; border-radius: 12px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                    <i class="fas fa-info-circle" style="font-size: 3rem; color: #6366f1; margin-bottom: 1rem;"></i>
                    <p style="color: #666; font-size: 1.125rem;">
                        Não há dados suficientes para gerar soluções estruturais neste período.
                    </p>
                </div>
            ` : resumo.solucoesEstruturais.map(solucao => `
                <div style="margin-bottom: 1.5rem; padding: 2rem; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 4px solid ${
                    solucao.prioridade === 'alta' ? '#ef4444' : 
                    solucao.prioridade === 'média' ? '#f59e0b' : '#10b981'
                };">
                    <div style="display: flex; align-items: start; justify-content: space-between; margin-bottom: 1rem;">
                        <div style="flex: 1;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <span style="padding: 0.25rem 0.75rem; background: ${
                                    solucao.prioridade === 'alta' ? '#fee2e2' : 
                                    solucao.prioridade === 'média' ? '#fef3c7' : '#d1fae5'
                                }; color: ${
                                    solucao.prioridade === 'alta' ? '#991b1b' : 
                                    solucao.prioridade === 'média' ? '#92400e' : '#065f46'
                                }; border-radius: 20px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase;">
                                    ${solucao.prioridade === 'alta' ? '🔴' : solucao.prioridade === 'média' ? '🟡' : '🟢'} Prioridade ${solucao.prioridade}
                                </span>
                            </div>
                            <h4 style="font-size: 1.25rem; color: #1e293b; margin: 0 0 0.5rem 0;">
                                ${solucao.titulo}
                            </h4>
                            <p style="color: #666; line-height: 1.6; margin: 0 0 1rem 0;">
                                ${solucao.descricao}
                            </p>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                        <div style="padding: 1rem; background: #f8fafc; border-radius: 8px;">
                            <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Impacto Esperado</p>
                            <p style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0;">
                                ${solucao.impactoEsperado}
                            </p>
                        </div>
                        <div style="padding: 1rem; background: #f8fafc; border-radius: 8px;">
                            <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Prazo Estimado</p>
                            <p style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0;">
                                <i class="fas fa-clock"></i> ${solucao.prazoEstimado}
                            </p>
                        </div>
                        <div style="padding: 1rem; background: #f8fafc; border-radius: 8px;">
                            <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Recursos Necessários</p>
                            <p style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0;">
                                <i class="fas fa-users"></i> ${solucao.recursosNecessarios.join(', ')}
                            </p>
                        </div>
                    </div>

                    <div style="margin-bottom: 1.5rem;">
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0 0 0.75rem 0;">
                            <i class="fas fa-check-circle"></i> Ações Concretas:
                        </h5>
                        <ul style="margin: 0; padding-left: 1.5rem; color: #666; line-height: 1.8;">
                            ${solucao.acoesConcretas.map(acao => `<li>${acao}</li>`).join('')}
                        </ul>
                    </div>

                    <div style="margin-bottom: 1.5rem; padding: 1rem; background: #f0f9ff; border-radius: 8px;">
                        <h5 style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0 0 0.75rem 0;">
                            <i class="fas fa-chart-line"></i> Métricas de Sucesso:
                        </h5>
                        <ul style="margin: 0; padding-left: 1.5rem; color: #666; line-height: 1.8;">
                            ${solucao.metricasSucesso.map(metrica => `<li>${metrica}</li>`).join('')}
                        </ul>
                    </div>

                    <div style="display: flex; gap: 1rem; flex-wrap: wrap;">
                        <button class="btn-secondary" onclick="exportarPlano('${solucao.id}')" style="padding: 0.75rem 1.5rem;">
                            <i class="fas fa-download"></i> Exportar Plano de Ação
                        </button>
                        <button class="btn-secondary" onclick="marcarIniciado('${solucao.id}')" style="padding: 0.75rem 1.5rem;">
                            <i class="fas fa-check"></i> Marcar como Iniciado
                        </button>
                    </div>
                </div>
            `).join('')}
        </div>

        <!-- Top 3 Focos de Estresse -->
        ${resumo.top3FocosEstresse.length > 0 ? `
            <div style="margin-bottom: 2rem;">
                <h3 style="font-size: 1.5rem; color: #1e293b; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.5rem;">
                    <i class="fas fa-exclamation-triangle" style="color: #ef4444;"></i>
                    Top 3 Focos de Estresse
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                    ${resumo.top3FocosEstresse.map((foco, index) => `
                        <div style="padding: 1.5rem; background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                <span style="width: 2rem; height: 2rem; background: var(--primary-color); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700;">
                                    ${index + 1}
                                </span>
                                <h4 style="font-size: 1.125rem; color: #1e293b; margin: 0;">
                                    ${foco.foco}
                                </h4>
                            </div>
                            <div style="margin-bottom: 0.75rem;">
                                <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Intensidade Média</p>
                                <p style="font-size: 1.5rem; font-weight: 700; color: #ef4444; margin: 0;">
                                    ${foco.intensidadeMedia}/10
                                </p>
                            </div>
                            <div style="margin-bottom: 0.75rem;">
                                <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Frequência</p>
                                <p style="font-size: 1.125rem; font-weight: 600; color: #1e293b; margin: 0;">
                                    ${foco.frequencia}%
                                </p>
                            </div>
                            <div>
                                <p style="font-size: 0.75rem; color: #666; margin: 0 0 0.25rem 0;">Tendência</p>
                                <p style="font-size: 0.875rem; font-weight: 600; color: #1e293b; margin: 0;">
                                    ${foco.tendencia === 'crescente' ? '📈 Crescente' : 
                                      foco.tendencia === 'decrescente' ? '📉 Decrescente' : 
                                      '➡️ Estável'}
                                </p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}

        <!-- Resumo Executivo -->
        <div style="padding: 2rem; background: linear-gradient(135deg, #f0f9ff, #e0f2fe); border-radius: 12px; margin-bottom: 2rem;">
            <h3 style="font-size: 1.5rem; color: #1e293b; margin-bottom: 1rem; display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-file-alt"></i>
                Resumo Executivo
            </h3>
            <p style="color: #666; line-height: 1.8; margin: 0;">
                ${resumo.resumoExecutivo}
            </p>
        </div>
    `;

    // Adicionar event listeners para seletores
    const seletorMes = document.getElementById('seletorMes');
    const seletorAno = document.getElementById('seletorAno');
    
    if (seletorMes && seletorAno) {
        const atualizarPeriodo = async () => {
            const novoMes = parseInt(seletorMes.value);
            const novoAno = parseInt(seletorAno.value);
            await carregarDashboardGestao(novoMes, novoAno);
        };
        
        seletorMes.addEventListener('change', atualizarPeriodo);
        seletorAno.addEventListener('change', atualizarPeriodo);
    }
}

// Funções auxiliares (podem ser implementadas futuramente)
function exportarPlano(solucaoId) {
    alert('Funcionalidade de exportação será implementada em breve.');
}

function marcarIniciado(solucaoId) {
    alert('Funcionalidade de marcação será implementada em breve.');
}

export { carregarDashboardGestao };

