// Módulo de Análise e Geração de Soluções Estruturais - Sistema de Bem-Estar

// Garantir acesso ao API_CONFIG (definido em app.js)
const getAPIConfig = () => {
    if (typeof API_CONFIG !== 'undefined') {
        return API_CONFIG;
    }
    // Fallback se API_CONFIG não estiver disponível
    return {
        baseURL: 'http://localhost:8080/api',
        endpoints: {
            desabafos: '/desabafos',
            questionarios: '/questionarios'
        }
    };
};

// Funções auxiliares para buscar dados do backend
async function buscarDesabafosPeriodo(mes, ano) {
    const apiConfig = getAPIConfig();
    
    try {
        // Tentar buscar do backend
        const response = await fetch(
            `${apiConfig.baseURL}${apiConfig.endpoints.desabafos}?mes=${mes}&ano=${ano}`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (response.ok) {
            const desabafos = await response.json();
            // Converter formato do backend para formato esperado
            // Converter enums com underscore para formato com espaços
            const converterTopico = (top) => {
                if (!top) return 'Outro';
                // Converter underscores para espaços e ajustar hífens
                return top.replace(/_/g, ' ').replace(/ Trabalho Vida/g, ' Trabalho-Vida');
            };
            
            return desabafos.map(d => ({
                id: d.id,
                dataProcessamento: d.dataProcessamento || d.data_processamento,
                sentimentoPrincipal: d.sentimentoPrincipal || d.sentimento_principal || 'Outro',
                topicoRecorrente: converterTopico(d.topicoRecorrente || d.topico_recorrente),
                intensidadeSentimento: d.intensidadeSentimento || d.intensidade_sentimento || 5,
                departamento: d.departamento,
                faixaEtaria: d.faixaEtaria || d.faixa_etaria,
                sessionHash: d.sessionHash || d.session_hash,
                usuarioId: d.usuarioId || d.usuario_id
            }));
        } else {
            // Fallback para localStorage
            const desabafos = JSON.parse(localStorage.getItem('desabafosAnonimos') || '[]');
            return desabafos.filter(d => {
                const data = new Date(d.dataProcessamento);
                return data.getMonth() + 1 === mes && data.getFullYear() === ano;
            });
        }
    } catch (error) {
        console.error('Erro ao buscar desabafos:', error);
        // Fallback para localStorage
        const desabafos = JSON.parse(localStorage.getItem('desabafosAnonimos') || '[]');
        return desabafos.filter(d => {
            const data = new Date(d.dataProcessamento);
            return data.getMonth() + 1 === mes && data.getFullYear() === ano;
        });
    }
}

async function buscarQuestionariosPeriodo(mes, ano) {
    const apiConfig = getAPIConfig();
    
    try {
        // Tentar buscar do backend
        const response = await fetch(
            `${apiConfig.baseURL}${apiConfig.endpoints.questionarios}?mes=${mes}&ano=${ano}`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (response.ok) {
            const questionarios = await response.json();
            // Converter formato do backend para formato esperado
            return questionarios.map(q => ({
                id: q.id,
                mesAno: q.mesAno || q.mes_ano,
                dataResposta: q.dataResposta || q.data_resposta,
                respostas: {
                    cargaTrabalho: q.cargaTrabalho || q.carga_trabalho,
                    reconhecimento: q.reconhecimento,
                    relacionamentoInterpessoal: q.relacionamentoInterpessoal || q.relacionamento_interpessoal,
                    equilibrioTrabalhoVida: q.equilibrioTrabalhoVida || q.equilibrio_trabalho_vida,
                    comunicacao: q.comunicacao,
                    autonomia: q.autonomia,
                    desenvolvimento: q.desenvolvimento,
                    ambienteTrabalho: q.ambienteTrabalho || q.ambiente_trabalho,
                    suporteLideranca: q.suporteLideranca || q.suporte_lideranca,
                    satisfacaoGeral: q.satisfacaoGeral || q.satisfacao_geral
                },
                departamento: q.departamento,
                faixaEtaria: q.faixaEtaria || q.faixa_etaria,
                sessionHash: q.sessionHash || q.session_hash,
                usuarioId: q.usuarioId || q.usuario_id
            }));
        } else {
            // Fallback para localStorage
            const questionarios = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');
            const mesAno = `${ano}-${String(mes).padStart(2, '0')}`;
            return questionarios.filter(q => q.mesAno === mesAno);
        }
    } catch (error) {
        console.error('Erro ao buscar questionários:', error);
        // Fallback para localStorage
        const questionarios = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');
        const mesAno = `${ano}-${String(mes).padStart(2, '0')}`;
        return questionarios.filter(q => q.mesAno === mesAno);
    }
}

function calcularMediasQuestionario(questionarios) {
    const PERGUNTAS_QUESTIONARIO = [
        { id: 'cargaTrabalho', dimensao: 'Carga de Trabalho' },
        { id: 'reconhecimento', dimensao: 'Reconhecimento' },
        { id: 'relacionamentoInterpessoal', dimensao: 'Relacionamento Interpessoal' },
        { id: 'equilibrioTrabalhoVida', dimensao: 'Equilíbrio Trabalho-Vida' },
        { id: 'comunicacao', dimensao: 'Comunicação' },
        { id: 'autonomia', dimensao: 'Autonomia' },
        { id: 'desenvolvimento', dimensao: 'Desenvolvimento' },
        { id: 'ambienteTrabalho', dimensao: 'Ambiente de Trabalho' },
        { id: 'suporteLideranca', dimensao: 'Suporte de Liderança' },
        { id: 'satisfacaoGeral', dimensao: 'Satisfação Geral' }
    ];
    
    if (questionarios.length === 0) return {};
    
    const medias = {};
    
    PERGUNTAS_QUESTIONARIO.forEach(pergunta => {
        const valores = questionarios
            .map(q => q.respostas[pergunta.id])
            .filter(v => v !== undefined && v !== null);
        
        if (valores.length > 0) {
            medias[pergunta.id] = {
                dimensao: pergunta.dimensao,
                media: valores.reduce((sum, v) => sum + v, 0) / valores.length,
                totalRespostas: valores.length
            };
        }
    });
    
    return medias;
}

// Gerar resumo executivo com soluções estruturais
async function gerarResumoExecutivo(mes, ano) {
    console.log(`[Analytics] Buscando dados do banco para ${mes}/${ano}...`);
    
    // Coletar dados agregados do backend (banco de dados)
    const desabafos = await buscarDesabafosPeriodo(mes, ano);
    const questionarios = await buscarQuestionariosPeriodo(mes, ano);
    
    console.log(`[Analytics] Dados recebidos: ${desabafos.length} desabafos, ${questionarios.length} questionários`);
    
    // Analisar dados
    const top3Focos = identificarTop3FocosEstresse(desabafos);
    const solucoes = gerarSolucoesEstruturais(top3Focos, desabafos, questionarios);
    const metricas = calcularMetricasAgregadas(desabafos, questionarios);
    
    return {
        id: `exec_summary_${ano}_${String(mes).padStart(2, '0')}`,
        periodo: {
            inicio: `${ano}-${String(mes).padStart(2, '0')}-01`,
            fim: `${ano}-${String(mes).padStart(2, '0')}-${new Date(ano, mes, 0).getDate()}`
        },
        dataGeracao: new Date().toISOString(),
        top3FocosEstresse: top3Focos,
        solucoesEstruturais: solucoes,
        metricasAgregadas: metricas,
        resumoExecutivo: gerarTextoResumo(top3Focos, solucoes, metricas)
    };
}

// Identificar Top 3 Focos de Estresse
function identificarTop3FocosEstresse(desabafos) {
    if (desabafos.length === 0) return [];
    
    // Agrupar por tópico
    const porTopico = {};
    desabafos.forEach(d => {
        const topico = d.topicoRecorrente;
        if (!porTopico[topico]) {
            porTopico[topico] = {
                topico: topico,
                intensidades: [],
                count: 0
            };
        }
        porTopico[topico].intensidades.push(d.intensidadeSentimento);
        porTopico[topico].count++;
    });
    
    // Calcular médias e frequências
    const focos = Object.values(porTopico).map(foco => {
        const intensidadeMedia = foco.intensidades.reduce((sum, i) => sum + i, 0) / foco.intensidades.length;
        const frequencia = (foco.count / desabafos.length) * 100;
        
        return {
            foco: foco.topico,
            intensidadeMedia: Math.round(intensidadeMedia * 10) / 10,
            frequencia: Math.round(frequencia),
            count: foco.count,
            tendencia: calcularTendencia(foco.intensidades)
        };
    });
    
    // Ordenar por intensidade e frequência (peso combinado)
    focos.sort((a, b) => {
        const scoreA = a.intensidadeMedia * 0.6 + a.frequencia * 0.4;
        const scoreB = b.intensidadeMedia * 0.6 + b.frequencia * 0.4;
        return scoreB - scoreA;
    });
    
    // Retornar top 3 com impacto
    return focos.slice(0, 3).map(foco => ({
        ...foco,
        impacto: foco.intensidadeMedia >= 8 ? 'alto' : foco.intensidadeMedia >= 6 ? 'médio' : 'baixo'
    }));
}

// Calcular tendência (simplificado - em produção, comparar com período anterior)
function calcularTendencia(intensidades) {
    if (intensidades.length < 2) return 'estável';
    
    const primeiraMetade = intensidades.slice(0, Math.floor(intensidades.length / 2));
    const segundaMetade = intensidades.slice(Math.floor(intensidades.length / 2));
    
    const mediaPrimeira = primeiraMetade.reduce((sum, i) => sum + i, 0) / primeiraMetade.length;
    const mediaSegunda = segundaMetade.reduce((sum, i) => sum + i, 0) / segundaMetade.length;
    
    const diferenca = mediaSegunda - mediaPrimeira;
    
    if (diferenca > 0.5) return 'crescente';
    if (diferenca < -0.5) return 'decrescente';
    return 'estável';
}

// Gerar soluções estruturais baseadas nos focos de estresse
function gerarSolucoesEstruturais(top3Focos, desabafos, questionarios) {
    const solucoes = [];
    
    top3Focos.forEach((foco, index) => {
        const solucao = gerarSolucaoParaFoco(foco, desabafos, questionarios);
        if (solucao) {
            solucoes.push({
                ...solucao,
                prioridade: index === 0 ? 'alta' : index === 1 ? 'média' : 'baixa'
            });
        }
    });
    
    return solucoes;
}

// Gerar solução específica para um foco de estresse
function gerarSolucaoParaFoco(foco, desabafos, questionarios) {
    const templateSolucoes = {
        'Carga de Trabalho': {
            titulo: 'Implementar Sistema de Balanceamento de Carga de Trabalho',
            descricao: 'Criar um sistema de distribuição equitativa de tarefas entre equipes, com monitoramento semanal e ajustes dinâmicos baseados em capacidade e disponibilidade.',
            prazoEstimado: '2-3 meses',
            recursosNecessarios: ['RH', 'Gestão de Projetos', 'TI'],
            acoesConcretas: [
                'Mapear carga atual de trabalho por equipe e indivíduo',
                'Definir critérios de distribuição equitativa',
                'Implementar ferramenta de monitoramento de carga',
                'Treinar gestores em técnicas de distribuição de tarefas',
                'Estabelecer revisões semanais de carga de trabalho'
            ],
            metricasSucesso: [
                'Redução de 25% na intensidade média de estresse relacionado a carga',
                'Aumento de 20% na satisfação com carga de trabalho',
                'Redução de 30% em horas extras não planejadas'
            ]
        },
        'Liderança': {
            titulo: 'Criar Programa de Desenvolvimento de Liderança',
            descricao: 'Implementar programa de mentoria e treinamento para gestores, focado em comunicação eficaz, feedback construtivo e gestão de equipes.',
            prazoEstimado: '3-4 meses',
            recursosNecessarios: ['RH', 'Desenvolvimento Organizacional'],
            acoesConcretas: [
                'Mapear necessidades de desenvolvimento dos gestores',
                'Criar programa de mentoria para novos gestores',
                'Implementar treinamentos em comunicação e feedback',
                'Estabelecer sistema de avaliação 360 graus',
                'Criar comunidade de prática para gestores'
            ],
            metricasSucesso: [
                'Aumento de 30% na satisfação com suporte de liderança',
                'Redução de 20% em conflitos relacionados a gestão',
                'Melhoria de 25% nas avaliações de liderança'
            ]
        },
        'Equilíbrio Trabalho-Vida': {
            titulo: 'Estabelecer Políticas de Equilíbrio Trabalho-Vida',
            descricao: 'Implementar políticas claras de desconexão digital, horários flexíveis e respeito a limites pessoais, com monitoramento e ajustes contínuos.',
            prazoEstimado: '1-2 meses',
            recursosNecessarios: ['RH', 'Gestão'],
            acoesConcretas: [
                'Definir política de desconexão digital após horário de trabalho',
                'Implementar horários flexíveis onde possível',
                'Comunicar e treinar equipes sobre limites e respeito',
                'Criar sistema de monitoramento de horas trabalhadas',
                'Estabelecer canais de feedback sobre políticas'
            ],
            metricasSucesso: [
                'Aumento de 35% na satisfação com equilíbrio trabalho-vida',
                'Redução de 40% em comunicações fora do horário de trabalho',
                'Melhoria de 25% no bem-estar geral'
            ]
        },
        'Relacionamento Interpessoal': {
            titulo: 'Fortalecer Cultura de Colaboração e Resolução de Conflitos',
            descricao: 'Criar programas de team building, workshops de comunicação não-violenta e processos claros de resolução de conflitos.',
            prazoEstimado: '2-3 meses',
            recursosNecessarios: ['RH', 'Desenvolvimento Organizacional'],
            acoesConcretas: [
                'Realizar workshops de comunicação e resolução de conflitos',
                'Implementar atividades de team building regulares',
                'Criar processo estruturado de mediação de conflitos',
                'Estabelecer espaços seguros para feedback entre pares',
                'Treinar facilitadores internos em resolução de conflitos'
            ],
            metricasSucesso: [
                'Redução de 30% em conflitos interpessoais reportados',
                'Aumento de 25% na satisfação com relacionamentos',
                'Melhoria de 20% no clima organizacional'
            ]
        },
        'Reconhecimento': {
            titulo: 'Implementar Sistema de Reconhecimento Estruturado',
            descricao: 'Criar programa formal de reconhecimento com múltiplas formas de valorização, incluindo feedback público, recompensas e oportunidades de desenvolvimento.',
            prazoEstimado: '2-3 meses',
            recursosNecessarios: ['RH', 'Gestão'],
            acoesConcretas: [
                'Criar programa de reconhecimento mensal e trimestral',
                'Implementar sistema de feedback público entre pares',
                'Estabelecer critérios claros e transparentes de reconhecimento',
                'Criar plataforma de valorização e agradecimentos',
                'Vincular reconhecimento a oportunidades de desenvolvimento'
            ],
            metricasSucesso: [
                'Aumento de 40% na percepção de reconhecimento',
                'Melhoria de 30% na retenção de talentos',
                'Aumento de 25% no engajamento'
            ]
        },
        'Comunicação': {
            titulo: 'Melhorar Canais e Processos de Comunicação',
            descricao: 'Revisar e otimizar canais de comunicação, estabelecer processos claros de disseminação de informações e criar espaços para feedback bidirecional.',
            prazoEstimado: '1-2 meses',
            recursosNecessarios: ['RH', 'Comunicação', 'TI'],
            acoesConcretas: [
                'Auditar canais de comunicação atuais',
                'Estabelecer processos claros de disseminação de informações',
                'Criar espaços para feedback e perguntas',
                'Implementar comunicação regular e transparente da gestão',
                'Treinar equipes em comunicação eficaz'
            ],
            metricasSucesso: [
                'Aumento de 30% na satisfação com comunicação',
                'Redução de 25% em mal-entendidos e retrabalho',
                'Melhoria de 20% na clareza de expectativas'
            ]
        }
    };
    
    const template = templateSolucoes[foco.foco];
    if (!template) return null;
    
    // Calcular impacto esperado baseado na intensidade
    const impactoPercentual = Math.round(foco.intensidadeMedia * 5);
    
    return {
        id: `sol_${foco.foco.replace(/\s+/g, '_').toLowerCase()}_${Date.now()}`,
        titulo: template.titulo,
        descricao: template.descricao,
        impactoEsperado: `Redução de ${impactoPercentual}% no estresse relacionado a ${foco.foco.toLowerCase()}`,
        prazoEstimado: template.prazoEstimado,
        recursosNecessarios: template.recursosNecessarios,
        metricasSucesso: template.metricasSucesso,
        acoesConcretas: template.acoesConcretas
    };
}

// Calcular métricas agregadas
function calcularMetricasAgregadas(desabafos, questionarios) {
    const totalDesabafos = desabafos.length;
    const totalQuestionarios = questionarios.length;
    
    // Calcular sentimento médio
    const sentimentoMedio = totalDesabafos > 0
        ? desabafos.reduce((sum, d) => sum + d.intensidadeSentimento, 0) / totalDesabafos
        : 0;
    
    // Calcular satisfação média do questionário
    const mediasQuestionario = calcularMediasQuestionario(questionarios);
    const satisfacaoMedia = mediasQuestionario.satisfacaoGeral
        ? mediasQuestionario.satisfacaoGeral.media
        : 0;
    
    // Calcular taxa de participação (estimativa - em produção, usar total de funcionários)
    const usuariosUnicos = new Set([
        ...desabafos.map(d => d.sessionHash),
        ...questionarios.map(q => q.sessionHash)
    ]).size;
    
    // Em produção, buscar total de funcionários do backend
    const totalFuncionarios = 60; // Mock
    const taxaParticipacao = totalFuncionarios > 0 ? usuariosUnicos / totalFuncionarios : 0;
    
    return {
        totalDesabafos,
        totalQuestionarios,
        taxaParticipacao: Math.round(taxaParticipacao * 100) / 100,
        sentimentoMedio: Math.round(sentimentoMedio * 10) / 10,
        satisfacaoMedia: Math.round(satisfacaoMedia * 10) / 10
    };
}

// Gerar texto resumo executivo
function gerarTextoResumo(top3Focos, solucoes, metricas) {
    let texto = `No período analisado, foram processados ${metricas.totalDesabafos} desabafos e ${metricas.totalQuestionarios} questionários mensais, `;
    texto += `representando uma taxa de participação de ${(metricas.taxaParticipacao * 100).toFixed(0)}%. `;
    
    if (top3Focos.length > 0) {
        texto += `Os principais focos de estresse identificados foram: ${top3Focos.map(f => f.foco).join(', ')}. `;
    }
    
    if (solucoes.length > 0) {
        texto += `Foram geradas ${solucoes.length} soluções estruturais prioritárias, `;
        texto += `com foco em ações de alto nível para a gestão, incluindo ${solucoes[0].titulo.toLowerCase()}. `;
    }
    
    texto += `Recomenda-se implementação imediata das soluções de prioridade alta para impacto máximo no bem-estar organizacional.`;
    
    return texto;
}

// Exportar funções para ES6 modules
export { gerarResumoExecutivo, identificarTop3FocosEstresse, gerarSolucoesEstruturais };

