// Módulo de Desabafo com IA - Sistema de Bem-Estar
// Garante anonimato total: texto original NUNCA é armazenado

// Armazenamento local de dados anônimos (em produção, usar backend)
let desabafosAnonimos = JSON.parse(localStorage.getItem('desabafosAnonimos') || '[]');
let questionariosAnonimos = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');

// Função para gerar hash anônimo (SHA-256 simplificado)
async function gerarHashAnonimo(userId, timestamp) {
    const texto = `${userId}_${timestamp}_${Math.random()}`;
    const encoder = new TextEncoder();
    const data = encoder.encode(texto);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
}

// Função para gerar hash de sessão
function gerarSessionHash(userId) {
    const timestamp = Math.floor(Date.now() / (1000 * 60 * 60 * 24)); // Hash por dia
    return btoa(`${userId}_${timestamp}`).replace(/[^a-zA-Z0-9]/g, '').substring(0, 32);
}

// Processar desabafo: resposta empática + extração anônima
async function processarDesabafo(textoOriginal, userId) {
    try {
        // ETAPA 1: Gerar resposta empática imediata
        const respostaEmpatica = await gerarRespostaEmpatica(textoOriginal);
        
        // ETAPA 2: Extrair dados anônimos (sem armazenar texto original)
        const dadosExtraidos = await extrairDadosAnonimos(textoOriginal);
        
        // ETAPA 3: Criar registro anônimo
        // Converter para formato do backend (enums com underscores)
        const converterSentimento = (sent) => {
            const map = {
                'estresse': 'Estresse',
                'ansiedade': 'Ansiedade',
                'frustração': 'Frustração',
                'frustracao': 'Frustração',
                'sobrecarga': 'Sobrecarga',
                'conflito': 'Conflito',
                'outro': 'Outro'
            };
            return map[sent?.toLowerCase()] || 'Outro';
        };
        
        const converterTopico = (top) => {
            const map = {
                'Carga de Trabalho': 'Carga_de_Trabalho',
                'Liderança': 'Liderança',
                'Lideranca': 'Liderança',
                'Relacionamento Interpessoal': 'Relacionamento_Interpessoal',
                'Equilíbrio Trabalho-Vida': 'Equilíbrio_Trabalho_Vida',
                'Equilibrio Trabalho-Vida': 'Equilíbrio_Trabalho_Vida',
                'Reconhecimento': 'Reconhecimento',
                'Comunicação': 'Comunicação',
                'Comunicacao': 'Comunicação',
                'Outro': 'Outro'
            };
            return map[top] || 'Outro';
        };
        
        const registroAnonimo = {
            sentimentoPrincipal: converterSentimento(dadosExtraidos.sentimentoPrincipal || 'Outro'),
            topicoRecorrente: converterTopico(dadosExtraidos.topicoRecorrente || 'Outro'),
            intensidadeSentimento: dadosExtraidos.intensidadeSentimento || 5,
            usuarioId: userId || null
        };
        
        // ETAPA 4: Armazenar APENAS dados agregados no backend (texto original já foi descartado)
        try {
            const response = await fetch(`${API_CONFIG.baseURL}${API_CONFIG.endpoints.desabafos}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(registroAnonimo)
            });
            
            if (!response.ok) {
                console.error('Erro ao salvar desabafo no backend:', response.status);
                // Fallback para localStorage
                const hashId = await gerarHashAnonimo(userId || 0, Date.now());
                registroAnonimo.id = hashId;
                registroAnonimo.dataProcessamento = new Date().toISOString().split('T')[0];
                registroAnonimo.sessionHash = gerarSessionHash(userId || 0);
                desabafosAnonimos.push(registroAnonimo);
                localStorage.setItem('desabafosAnonimos', JSON.stringify(desabafosAnonimos));
            }
        } catch (apiError) {
            console.error('Erro ao conectar com backend:', apiError);
            // Fallback para localStorage
            const hashId = await gerarHashAnonimo(userId || 0, Date.now());
            registroAnonimo.id = hashId;
            registroAnonimo.dataProcessamento = new Date().toISOString().split('T')[0];
            registroAnonimo.sessionHash = gerarSessionHash(userId || 0);
            desabafosAnonimos.push(registroAnonimo);
            localStorage.setItem('desabafosAnonimos', JSON.stringify(desabafosAnonimos));
        }
        
        // ETAPA 5: Retornar resposta empática
        return respostaEmpatica;
        
    } catch (error) {
        console.error('Erro ao processar desabafo:', error);
        return "Obrigado por compartilhar. Estou aqui para ouvir e apoiar você. 💙";
    }
}

// Gerar resposta empática usando IA simulada (sem conselhos ou soluções)
async function gerarRespostaEmpatica(texto) {
    // Simular delay de processamento (800-1500ms)
    await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 700));
    
    const textoLower = texto.toLowerCase();
    
    // Respostas empáticas contextualizadas baseadas no conteúdo
    const respostasEmpaticas = {
        // Saudações
        saudacao: [
            "Olá! É um prazer estar aqui com você. Como você está se sentindo hoje?",
            "Oi! Estou aqui para ouvir você. Pode compartilhar o que está sentindo?",
            "Olá! Fico feliz que você tenha vindo até aqui. Estou pronto para ouvir."
        ],
        // Estresse e sobrecarga
        estresse: [
            "Entendo que você está se sentindo sobrecarregado. É realmente difícil lidar com tudo isso. Seus sentimentos são completamente válidos.",
            "Reconheço que você está passando por um momento de muito estresse. É compreensível se sentir assim diante de tanta pressão. Estou aqui para ouvir.",
            "Vejo que você está enfrentando uma sobrecarga. É natural se sentir assim quando temos muitas responsabilidades. Você não está sozinho nisso."
        ],
        // Ansiedade e preocupação
        ansiedade: [
            "Compreendo que você está se sentindo ansioso. A ansiedade pode ser realmente difícil de lidar. Seus sentimentos são importantes e válidos.",
            "Reconheço que você está preocupado. É normal sentir ansiedade diante de situações incertas. Estou aqui para acolher você.",
            "Entendo que você está passando por um momento de ansiedade. Esses sentimentos podem ser muito intensos. Você não está sozinho."
        ],
        // Frustração e decepção
        frustracao: [
            "Vejo que você está se sentindo frustrado. É compreensível se sentir assim quando as coisas não saem como esperado. Seus sentimentos são válidos.",
            "Reconheço sua frustração. É difícil quando nos esforçamos e não obtemos os resultados que esperávamos. Estou aqui para ouvir você.",
            "Entendo que você está decepcionado. É natural sentir frustração quando algo não acontece como planejamos. Você não está sozinho nisso."
        ],
        // Cansaço e exaustão
        cansaco: [
            "Vejo que você está se sentindo muito cansado. É compreensível se sentir exausto quando estamos sobrecarregados. Seus sentimentos são válidos.",
            "Reconheço que você está exausto. O cansaço pode ser realmente esgotante. Estou aqui para acolher você.",
            "Entendo que você está se sentindo esgotado. É natural se sentir assim quando temos muito a fazer. Você não está sozinho."
        ],
        // Conflitos e relacionamentos
        conflito: [
            "Compreendo que você está passando por um conflito. Situações assim podem ser muito difíceis de lidar. Seus sentimentos são importantes.",
            "Reconheço que você está enfrentando dificuldades em um relacionamento. É compreensível se sentir assim. Estou aqui para ouvir você.",
            "Vejo que você está passando por um desentendimento. Essas situações podem ser muito desgastantes. Você não está sozinho nisso."
        ],
        // Trabalho e carga
        trabalho: [
            "Entendo que você está sobrecarregado com trabalho. É realmente difícil quando temos muitas responsabilidades. Seus sentimentos são válidos.",
            "Reconheço que a carga de trabalho está pesada para você. É compreensível se sentir assim. Estou aqui para acolher você.",
            "Vejo que o trabalho está sendo muito exigente. É natural se sentir sobrecarregado. Você não está sozinho nisso."
        ],
        // Padrão (genérico)
        padrao: [
            "Entendo que você está passando por um momento difícil. É corajoso da sua parte compartilhar isso. Estou aqui para ouvir você.",
            "Reconheço que você está se sentindo mal. Seus sentimentos são importantes e válidos. Você não está sozinho.",
            "Vejo que você está passando por algo difícil. É compreensível se sentir assim. Estou aqui para acolher você.",
            "Compreendo que você está enfrentando desafios. É natural ter esses sentimentos. Você não está sozinho nisso.",
            "Reconheço que você está passando por um momento complicado. Seus sentimentos são válidos. Estou aqui para ouvir."
        ]
    };
    
    // Detectar contexto da mensagem
    let categoria = 'padrao';
    
    if (textoLower.match(/\b(olá|oi|ola|bom dia|boa tarde|boa noite|hey|hi)\b/)) {
        categoria = 'saudacao';
    } else if (textoLower.match(/\b(estresse|estressado|sobrecarga|sobrecarregado|pressão|pressao|pressurizado|tensão|tensao)\b/)) {
        categoria = 'estresse';
    } else if (textoLower.match(/\b(ansiedade|ansioso|preocupado|preocupação|preocupacao|nervoso|nervosismo|inquieto|agitado)\b/)) {
        categoria = 'ansiedade';
    } else if (textoLower.match(/\b(frustração|frustrado|frustracao|decepcionado|decepção|decepcao|chateado|irritado)\b/)) {
        categoria = 'frustracao';
    } else if (textoLower.match(/\b(cansado|cansaço|canseco|exausto|esgotado|sem energia|sem forças)\b/)) {
        categoria = 'cansaco';
    } else if (textoLower.match(/\b(conflito|briga|discussão|discussao|desentendimento|problema com|brigando|discutindo)\b/)) {
        categoria = 'conflito';
    } else if (textoLower.match(/\b(trabalho|tarefa|projeto|prazo|deadline|muito trabalho|sobrecarga de trabalho|demanda)\b/)) {
        categoria = 'trabalho';
    }
    
    // Selecionar resposta aleatória da categoria
    const respostas = respostasEmpaticas[categoria];
    const respostaIndex = Math.floor(Math.random() * respostas.length);
    
    return respostas[respostaIndex];
}


// Extrair dados anônimos do texto (sem armazenar o texto original)
async function extrairDadosAnonimos(texto) {
    // Simular delay de processamento
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Usar extração básica melhorada
    return extrairDadosBasicos(texto);
}

// Extração básica de dados (análise inteligente do texto)
function extrairDadosBasicos(texto) {
    const textoLower = texto.toLowerCase();
    
    // Mapeamento de sentimentos (com mais palavras-chave)
    const sentimentos = {
        'estresse': ['estresse', 'estressado', 'sobrecarga', 'sobrecarregado', 'pressão', 'pressao', 'pressurizado', 'tensão', 'tensao'],
        'ansiedade': ['ansiedade', 'ansioso', 'preocupado', 'preocupação', 'preocupacao', 'nervoso', 'nervosismo', 'inquieto', 'agitado'],
        'frustração': ['frustração', 'frustrado', 'frustracao', 'decepcionado', 'decepção', 'decepcao', 'chateado', 'irritado'],
        'sobrecarga': ['sobrecarga', 'sobrecarregado', 'muito trabalho', 'excesso', 'demais', 'acúmulo', 'acumulo'],
        'conflito': ['conflito', 'briga', 'discussão', 'discussao', 'desentendimento', 'problema com', 'brigando', 'discutindo'],
        'outro': []
    };
    
    // Mapeamento de tópicos (mais abrangente)
    const topicos = {
        'Carga de Trabalho': ['trabalho', 'tarefa', 'projeto', 'prazo', 'deadline', 'muito trabalho', 'sobrecarga', 'demanda', 'atividade'],
        'Liderança': ['chefe', 'gestor', 'liderança', 'lideranca', 'supervisor', 'gerente', 'comando', 'direção', 'direcao'],
        'Relacionamento Interpessoal': ['colega', 'equipe', 'pessoa', 'relacionamento', 'conflito', 'briga', 'pessoas', 'gente', 'time'],
        'Equilíbrio Trabalho-Vida': ['horário', 'horario', 'tempo', 'família', 'familia', 'pessoal', 'descanso', 'equilíbrio', 'equilibrio', 'vida pessoal'],
        'Reconhecimento': ['reconhecimento', 'valorização', 'valorizacao', 'recompensa', 'elogio', 'mérito', 'merito', 'apreciação'],
        'Comunicação': ['comunicação', 'comunicacao', 'informação', 'informacao', 'mensagem', 'feedback', 'comunicar', 'falar'],
        'Outro': []
    };
    
    // Detectar sentimento (com pontuação)
    let sentimentoPrincipal = 'outro';
    let maxScore = 0;
    
    for (const [sentimento, palavras] of Object.entries(sentimentos)) {
        let score = 0;
        palavras.forEach(palavra => {
            if (textoLower.includes(palavra)) {
                score += 1;
                // Palavras mais longas têm mais peso
                if (palavra.length > 6) score += 0.5;
            }
        });
        if (score > maxScore) {
            maxScore = score;
            sentimentoPrincipal = sentimento;
        }
    }
    
    // Detectar tópico (com pontuação)
    let topicoRecorrente = 'Outro';
    maxScore = 0;
    
    for (const [topico, palavras] of Object.entries(topicos)) {
        let score = 0;
        palavras.forEach(palavra => {
            if (textoLower.includes(palavra)) {
                score += 1;
                // Palavras mais específicas têm mais peso
                if (palavra.length > 8) score += 0.5;
            }
        });
        if (score > maxScore) {
            maxScore = score;
            topicoRecorrente = topico;
        }
    }
    
    // Calcular intensidade (baseado em palavras de intensidade e contexto)
    const palavrasIntensidade = {
        'muito': 2, 'extremamente': 3, 'totalmente': 3, 'completamente': 3,
        'bastante': 2, 'demais': 3, 'insuportável': 4, 'insuportavel': 4, 
        'terrível': 4, 'terrivel': 4, 'horrível': 4, 'horrivel': 4,
        'impossível': 3, 'impossivel': 3, 'difícil': 1, 'dificil': 1
    };
    
    let intensidade = 5; // Padrão
    for (const [palavra, valor] of Object.entries(palavrasIntensidade)) {
        if (textoLower.includes(palavra)) {
            intensidade = Math.min(10, intensidade + valor);
        }
    }
    
    // Ajustar intensidade baseado no comprimento e emoção do texto
    if (texto.length > 100) intensidade = Math.min(10, intensidade + 1);
    if (texto.match(/[!]{2,}/)) intensidade = Math.min(10, intensidade + 1); // Múltiplos pontos de exclamação
    
    return {
        sentimentoPrincipal,
        topicoRecorrente,
        intensidadeSentimento: Math.max(1, Math.min(10, Math.round(intensidade)))
    };
}

// Buscar desabafos de um período (para análise)
async function buscarDesabafosPeriodo(mes, ano) {
    try {
        // Tentar buscar do backend
        const response = await fetch(
            `${API_CONFIG.baseURL}${API_CONFIG.endpoints.desabafos}?mes=${mes}&ano=${ano}`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (response.ok) {
            return await response.json();
        } else {
            // Fallback para localStorage
            return desabafosAnonimos.filter(d => {
                const data = new Date(d.dataProcessamento);
                return data.getMonth() + 1 === mes && data.getFullYear() === ano;
            });
        }
    } catch (error) {
        console.error('Erro ao buscar desabafos:', error);
        // Fallback para localStorage
        return desabafosAnonimos.filter(d => {
            const data = new Date(d.dataProcessamento);
            return data.getMonth() + 1 === mes && data.getFullYear() === ano;
        });
    }
}

// Exportar funções para ES6 modules
export { processarDesabafo, buscarDesabafosPeriodo };

// Também disponibilizar globalmente para fallback (se necessário)
if (typeof window !== 'undefined') {
    window.processarDesabafo = processarDesabafo;
    window.buscarDesabafosPeriodo = buscarDesabafosPeriodo;
}

