// Módulo de Questionário Mensal Anônimo - Sistema de Bem-Estar

// Armazenamento local (em produção, usar backend)
let questionariosAnonimos = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');

// Função para gerar hash anônimo
async function gerarHashAnonimo(userId, timestamp) {
    const texto = `${userId}_${timestamp}_${Math.random()}`;
    const encoder = new TextEncoder();
    const data = encoder.encode(texto);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
}

// Estrutura do questionário
const PERGUNTAS_QUESTIONARIO = [
    {
        id: 'cargaTrabalho',
        texto: 'Como você avalia sua carga de trabalho atual?',
        dimensao: 'Carga de Trabalho'
    },
    {
        id: 'reconhecimento',
        texto: 'Você se sente reconhecido pelo seu trabalho?',
        dimensao: 'Reconhecimento'
    },
    {
        id: 'relacionamentoInterpessoal',
        texto: 'Como você avalia seus relacionamentos interpessoais no trabalho?',
        dimensao: 'Relacionamento Interpessoal'
    },
    {
        id: 'equilibrioTrabalhoVida',
        texto: 'Você consegue manter um equilíbrio entre trabalho e vida pessoal?',
        dimensao: 'Equilíbrio Trabalho-Vida'
    },
    {
        id: 'comunicacao',
        texto: 'Como você avalia a comunicação na organização?',
        dimensao: 'Comunicação'
    },
    {
        id: 'autonomia',
        texto: 'Você tem autonomia suficiente para realizar seu trabalho?',
        dimensao: 'Autonomia'
    },
    {
        id: 'desenvolvimento',
        texto: 'Você sente que tem oportunidades de desenvolvimento?',
        dimensao: 'Desenvolvimento'
    },
    {
        id: 'ambienteTrabalho',
        texto: 'Como você avalia o ambiente de trabalho?',
        dimensao: 'Ambiente de Trabalho'
    },
    {
        id: 'suporteLideranca',
        texto: 'Você recebe suporte adequado da liderança?',
        dimensao: 'Suporte de Liderança'
    },
    {
        id: 'satisfacaoGeral',
        texto: 'Em geral, como você avalia sua satisfação no trabalho?',
        dimensao: 'Satisfação Geral'
    }
];

// Gerar hash de sessão (mesma função do desabafo.js)
function gerarSessionHash(userId) {
    const timestamp = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
    return btoa(`${userId}_${timestamp}`).replace(/[^a-zA-Z0-9]/g, '').substring(0, 32);
}

// Verificar se usuário já respondeu o questionário do mês
async function jaRespondeuQuestionarioMes(userId, mes, ano) {
    if (!userId) return false;
    
    try {
        // Tentar verificar no backend
        const response = await fetch(
            `${API_CONFIG.baseURL}${API_CONFIG.endpoints.questionarios}/verificar?usuarioId=${userId}&mes=${mes}&ano=${ano}`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (response.ok) {
            const data = await response.json();
            return data.jaRespondeu || false;
        }
    } catch (error) {
        console.error('Erro ao verificar questionário:', error);
    }
    
    // Fallback para localStorage
    const questionarios = JSON.parse(localStorage.getItem('questionariosAnonimos') || '[]');
    const sessionHash = gerarSessionHash(userId);
    return questionarios.some(q => {
        const data = new Date(q.dataResposta);
        return q.sessionHash === sessionHash && 
               data.getMonth() + 1 === mes && 
               data.getFullYear() === ano;
    });
}

// Salvar resposta do questionário (anônima)
async function salvarRespostaQuestionario(respostas, userId) {
    console.log('[questionario.js] salvarRespostaQuestionario chamado');
    console.log('[questionario.js] respostas:', respostas);
    console.log('[questionario.js] userId:', userId);
    
    const hoje = new Date();
    const mes = hoje.getMonth() + 1;
    const ano = hoje.getFullYear();
    
    // Verificar se já respondeu este mês
    console.log('[questionario.js] Verificando se já respondeu este mês...');
    if (await jaRespondeuQuestionarioMes(userId, mes, ano)) {
        throw new Error('Você já respondeu o questionário deste mês.');
    }
    
    // Validar que há respostas
    if (!respostas || Object.keys(respostas).length === 0) {
        throw new Error('Nenhuma resposta foi fornecida.');
    }
    
    // Garantir que API_CONFIG está disponível
    let apiConfig;
    if (typeof API_CONFIG !== 'undefined') {
        apiConfig = API_CONFIG;
        console.log('[questionario.js] API_CONFIG encontrado:', apiConfig);
    } else if (typeof window !== 'undefined' && window.API_CONFIG) {
        apiConfig = window.API_CONFIG;
        console.log('[questionario.js] API_CONFIG encontrado em window:', apiConfig);
    } else {
        apiConfig = {
            baseURL: 'http://localhost:8080/api',
            endpoints: {
                questionarios: '/questionarios'
            }
        };
        console.warn('[questionario.js] API_CONFIG não encontrado, usando padrão:', apiConfig);
    }
    
    // Criar registro anônimo
    const registro = {
        mesAno: `${ano}-${String(mes).padStart(2, '0')}`,
        respostas: respostas,
        usuarioId: userId || null
    };
    
    console.log('[questionario.js] Registro preparado:', registro);
    console.log('[questionario.js] URL completa:', `${apiConfig.baseURL}${apiConfig.endpoints.questionarios}`);
    
    // Armazenar no backend
    try {
        console.log('[questionario.js] Enviando requisição POST para o backend...');
        
        const url = `${apiConfig.baseURL}${apiConfig.endpoints.questionarios}`;
        console.log('[questionario.js] URL:', url);
        console.log('[questionario.js] Body:', JSON.stringify(registro));
        
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(registro)
        });
        
        console.log('[questionario.js] Resposta recebida. Status:', response.status);
        console.log('[questionario.js] Headers:', response.headers);
        
        const contentType = response.headers.get('content-type');
        let errorData = null;
        
        if (contentType && contentType.includes('application/json')) {
            try {
                errorData = await response.json();
                console.log('[questionario.js] Resposta JSON:', errorData);
            } catch (e) {
                console.error('[questionario.js] Erro ao fazer parse do JSON:', e);
            }
        } else {
            const textResponse = await response.text();
            console.log('[questionario.js] Resposta texto:', textResponse);
        }
        
        if (response.ok) {
            const questionarioSalvo = errorData || await response.json();
            console.log('[questionario.js] Questionário salvo com sucesso:', questionarioSalvo);
            return questionarioSalvo;
        } else {
            const errorMessage = errorData?.error || `Erro HTTP ${response.status}: ${response.statusText}`;
            console.error('[questionario.js] Erro ao salvar questionário:', errorMessage);
            console.error('[questionario.js] Detalhes do erro:', errorData);
            throw new Error(errorMessage);
        }
    } catch (apiError) {
        console.error('[questionario.js] Erro ao conectar com backend:', apiError);
        console.error('[questionario.js] Stack trace:', apiError.stack);
        
        // Se for erro de rede, tentar fallback para localStorage
        if (apiError.message && (apiError.message.includes('fetch') || apiError.message.includes('Failed to fetch'))) {
            console.warn('[questionario.js] Backend não disponível, salvando no localStorage como fallback');
            const id = await gerarHashAnonimo(userId || 0, Date.now());
            registro.id = id;
            registro.dataResposta = hoje.toISOString().split('T')[0];
            registro.sessionHash = gerarSessionHash(userId || 0);
            questionariosAnonimos.push(registro);
            localStorage.setItem('questionariosAnonimos', JSON.stringify(questionariosAnonimos));
            return registro;
        }
        
        // Se for outro tipo de erro, relançar
        throw apiError;
    }
}

// Buscar questionários de um período
async function buscarQuestionariosPeriodo(mes, ano) {
    try {
        // Tentar buscar do backend
        const response = await fetch(
            `${API_CONFIG.baseURL}${API_CONFIG.endpoints.questionarios}?mes=${mes}&ano=${ano}`,
            {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            }
        );
        
        if (response.ok) {
            return await response.json();
        } else {
            // Fallback para localStorage
            const mesAno = `${ano}-${String(mes).padStart(2, '0')}`;
            return questionariosAnonimos.filter(q => q.mesAno === mesAno);
        }
    } catch (error) {
        console.error('Erro ao buscar questionários:', error);
        // Fallback para localStorage
        const mesAno = `${ano}-${String(mes).padStart(2, '0')}`;
        return questionariosAnonimos.filter(q => q.mesAno === mesAno);
    }
}

// Calcular médias por dimensão
function calcularMediasQuestionario(questionarios) {
    if (questionarios.length === 0) return {};
    
    const medias = {};
    
    PERGUNTAS_QUESTIONARIO.forEach(pergunta => {
        const valores = questionarios
            .map(q => q.respostas[pergunta.id])
            .filter(v => v !== undefined && v !== null);
        
        if (valores.length > 0) {
            medias[pergunta.id] = {
                dimensao: pergunta.dimensao,
                media: valores.reduce((sum, v) => sum + v, 0) / valores.length,
                totalRespostas: valores.length
            };
        }
    });
    
    return medias;
}

// Gerar hash anônimo (mesma função do desabafo.js)
async function gerarHashAnonimo(userId, timestamp) {
    const texto = `${userId}_${timestamp}_${Math.random()}`;
    const encoder = new TextEncoder();
    const data = encoder.encode(texto);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
}

// Exportar funções para ES6 modules
export { 
    PERGUNTAS_QUESTIONARIO, 
    salvarRespostaQuestionario, 
    buscarQuestionariosPeriodo, 
    calcularMediasQuestionario, 
    jaRespondeuQuestionarioMes 
};

// Também disponibilizar globalmente para fallback (se necessário)
if (typeof window !== 'undefined') {
    window.PERGUNTAS_QUESTIONARIO = PERGUNTAS_QUESTIONARIO;
    window.salvarRespostaQuestionario = salvarRespostaQuestionario;
    window.buscarQuestionariosPeriodo = buscarQuestionariosPeriodo;
    window.calcularMediasQuestionario = calcularMediasQuestionario;
    window.jaRespondeuQuestionarioMes = jaRespondeuQuestionarioMes;
}

